<!-- image -->

WPENS-CPR(18) 20318

G Dovidio et al.

## Accident analysis with MELCOR-fusion code for DONES lithium loop and accelerator

Preprint of Paper to be submitted for publication in Proceeding of 30th Symposium on Fusion Technology (SOFT)

<!-- image -->

This work has been carried out within the framework of the EUROfusion Consortium and has received funding from the Euratom research and training programme 2014-2018 under grant agreement No 633053. The views and opinions expressed herein do not necessarily reflect those of the European Commission.

This document is intended for publication in the open literature. It is made available on the clear understanding that it may not be further circulated and extracts or references may not be published prior to publication of the original when applicable, or without the consent of the Publications Officer, EUROfusion Programme Management Unit, Culham Science Centre, Abingdon, Oxon, OX14 3DB, UK or e-mail Publications.Officer@euro-fusion.org

Enquiries about Copyright and reproduction should be addressed to the Publications Officer, EUROfusion Programme Management Unit, Culham Science Centre, Abingdon, Oxon, OX14 3DB, UK or e-mail Publications.Officer@euro-fusion.org

The contents of this preprint and all other EUROfusion Preprints, Reports and Conference Papers are available to view online free at http://www.euro-fusionscipub.org. This site has full search facilities and e-mail alert options. In the JET specific papers the diagrams contained within the PDFs on this site are hyperlinked

## Accident analysis with MELCOR-fusion code for DONES lithium loop and accelerator

G. D'Ovidio, F. Martín-Fuertes

CIEMAT, Fusion Technology Division, Avda. Complutense 40, 28040 Madrid, SPAIN

Safety assessment is a key issue for the licensing of DONES facility, the DEMO-Oriented Neutron Source. A first phase of the safety assessment includes Failure Mode Analyses of systems to identify postulated initiating events (PIEs), while deterministic accident analyses are lately performed to estimate source terms in radiological hazards. In addition, the deterministic analyses are also the basis to identify safety class systems and components, and to establish the operational range of system parameters as well as the actuation of the protection system. In this paper two accident scenarios, previously identified as PIEs, have been simulated with the fusion version of the MELCOR 1.8.6 code. A loss of flow (LOFA) in the lithium loop due to the trip of the electromagnetic pump and a loss of vacuum (LOVA) in the accelerator beam duct due to containment rupture have been studied to provide a preliminary estimation of the available actuation time for detection and mitigation systems with a particular focus on the beam shutdown system and isolation of the vacuum duct.

Keywords: DONES Safety, Accident Analysis, MELCOR

## 1. Introduction

A neutron source facility, like the DEMO-Oriented Neutron Source (DONES), is needed to carry out irradiation campaigns on materials under highly demanding conditions of neutron flux damage expected in the prototype fusion plant DEMO. A safe design for DONES plant is a prerequisite for its licensing since a quite relevant radioactive inventory is involved during the operation lifetime of the facility. First safety studies have been focused on identifying postulated initiating events (PIEs), characterizing radiological and conventional hazards, and defining prevention, detection and mitigation measures. The present orientation of DONES safety assessment aims at performing a deterministic analysis which allows identifying safety class systems and components (SSCs), estimating the potential release of radiological contaminants in the facility and in the outer environment, and evaluating the operational range of operational parameters and actuation time of safety systems.

In this paper, two accident scenarios, previously recognized as PIEs by Failure Mode Analyses (FMEAs), have been studied: a loss of flow accident (LOFA) event in the lithium loop due to trip of the electromagnetic pump (EMP) and a loss of vacuum accident (LOVA) event in the accelerator beam duct due to containment rupture [1,2]. Models for DONES lithium loop, accelerator and associated systems have been developed using MELCOR 1.8.6 for fusion applications [3] to provide a preliminary deterministic assessment of the two accident scenarios.

## 2. Design of DONES lithium loop and accelerator

DONES lithium loop has the purpose to provide a stable lithium target and to remove the thermal power produced during the beam-target interaction in the heat exchanger [4,5]. From the inlet pipe, a flow straightener is used to smooth the lithium flow suppressing non-

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

uniformities in flow velocity. In the Target Vacuum Chamber (TVC) a double reducer nozzle generates a lithium flow which circulates at high velocity (10-15 m/s) over a concave channel in a small thickness (25 mm) to remove the high local power of 5 MW. Then, lithium enters the outlet channel to the Quench Tank (QT) located downstream the TVC where it decelerates and achieves a uniform temperature distribution. Finally, it flows through the heat exchanger (HX) where the thermal power is removed by the Heat Removal System. The overall lithium circulation inside the loop is provided by the EMP.

The goal of DONES accelerator is to produce a 40 MeV deuteron beam in continuous wave able to generate the required neutron flux by deuterium-lithium stripping reactions [6]. It consists of different systems: the injector, the Low Energy Beam Transport (LEBT) line, the Radio Frequency Quadrupole (RFQ) system, the Medium Energy Beam Transport (MEBT) line, the Superconductive Radiofrequency (SRF) linac and the High Energy Beam Transport (HEBT) line.

## 3. LOFA scenario

In DONES, some of the most critical accident scenarios, from the radiological point of view, involve the degradation of the main lithium loop. A loss of flow in the loop may induce the backplate thermal overload and consequent rupture if the accelerator beam is not promptly stopped by the fast beam shutdown system. A leak or a break in the same loop may also lead to the release of liquid metal into the Target Test Cell or into the Lithium Loop Cell. Furthermore, if inert atmosphere in the latter rooms is not guaranteed, lithium-air exothermic reactions may occur.

## 3.1 MELCOR modeling, assumptions and results

The schematic of the MELCOR model for DONES lithium loop is presented in Fig.1. The model comprises 8

control volumes: the boundary volume (CV050), the last beam duct section (CV150), the straightener-nozzle (CV100), the target (CV200), the QT (CV300), the EMP (CV350), the HX (CV400) and the inlet pipe (CV450). In the present DONES design, vacuum inside the target (CV200) and QT (CV300) is guaranteed by vacuum pumps located in the last section of the accelerator beam duct (CV150). In MELCOR model, a boundary volume (CV050) with a very low pressure value (10 -5 Pa) and a time dependent flow path (FL050) have been implemented to simulate the real vacuum pump system. An arbitrary air venting speed for FL050 has been chosen to obtain a pressure of about ~100 Pa in the target when reaching the stationary state. An additional flow path (FL070), connecting the QT to the target, has been considered to simulate vacuum conditions also in the first component (CV300). Numerical errors due to the low resolution of equations of state (EOS) for lithium at very low pressures (&lt;100 Pa) have been found during MELCOR simulations.

The flow straightener and the reducer nozzle have been modeled as a single control volume (CV100) with a flow path (FL100) whose cross section is equal to that of the real nozzle outlet. In MELCOR model, the target (CV200) simulates the volume of the TVC and of the outlet channel connecting the TVC with the QT. The thermal power of 5 MW is directly injected in the liquid metal by defining an equivalent energy source. The simulation of the liquid slide has been particularly demanding due to the intrinsic limits of a 1D code to reproduce its complex 3D geometry and phenomenology. The solution, present in this work, consists of coupling mass flow rates of FL100 and FL200 by means of a control function. Thus, velocity in FL200 is calculated by imposing the equality between mass flow rates.

The EMP pressure source has been simulated using the "QUICK-CF model" , implemented in MELCOR, for flow path FL300 [7]. The volume of the EMP has been considered in CV350. Since there was no available information about EMP characteristic curves for DONES lithium loop, the pump trip has been simulated by assuming a linear ramp for pressure head which scales from the nominal value to zero in 10 seconds. In this simulation, it is also assumed that the beam is shutdown in 100 ms, either when lithium mass flow rate reaches the 70% of its nominal value in FL300 (35 kg/s) or when the thickness of the lithium target goes down below the limit value for interlock signal (22.5 mm).

Presently, MELCOR does not allow considering two different working fluids (i.e., lithium and oil) thermally connected in a heat exchanger and, therefore, the analysis of primary and secondary sides must be decoupled. The temperature of heat structure HS40001, associated to the HX (CV400), has been adjusted so that the power extracted from HX is equal to the power injected in the target when reaching the stationary state.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Figure 1: Schematic of the MELCOR model for DONES lithium loop

<!-- image -->

A steady state initialization has been run before the LOFA event. As shown in Table 1, steady state results obtained with the MELCOR code generally agree very well with the reference design parameters [4].

Table 1: Steady-state results obtained with MELCOR compared with the reference design parameters

̴

| Parameter  MELCOR Reference  Pressure target (Pa)  100  1E-3  Total circuit pressure loss (Pa)  2.5E5  2.4E5  Total Li mass flow rate (kg/s)  49.6  49.7  Velocity at nozzle exit (m/s)  14.9  15  Li temperature in HX (°C)  249.8  250.0  Li temperature in QT (°C)  274.0  274.0  Total Li volume in the loop (m3)  8.45  8.44   |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

During the transient, when pump trip occurs and void fraction in FL200 is different from zero (velocity in FL100 is almost zero), a control function activates FL250 and closes FL200 to allow the lithium circulation to the QT until the TG is fully drained. As depicted in Fig. 2, due to the EMP trip (1500-1510 s), Li mass contents inside CV100 and CV200 eventually start to decrease until they are completely emptied at 1515 s.

Figure 2: Lithium mass contents as functions of time in the target (CV100) and QT (CV200)

<!-- image -->

On the other hand, lithium mass flow rate, provided by the pump, achieves the critical value (35 kg/s) for the actuation of the beam shutdown signal about 4.6 s after the accident initiator.

## 4. LOVA scenario

A loss of vacuum accident in DONES accelerator due to water coolant ingress inside the beam duct could cause violent exothermic reactions, with potential release of tritium and activation products, if water in liquid or vapor form propagates along the beam line until reaching the lithium target. In addition, water-lithium reaction can generate hydrogen which could lead to overpressurization and risk of explosion in the accelerator duct with further damages to the surrounding structures. The break in the cooling loop serving the final collimator, embedded in the wall between the Target Interface Room (TIR) and the Radiation Interface Room (RIR), is considered as the most severe initiator event for this type of accident scenario due to its proximity to the liquid target.

## 4.1 MELCOR modeling, assumptions and results

The schematic of MELCOR model for DONES accelerator is shown in Fig.3. This model consists of several control volumes which simulate the injector and LEBT line (CV001), the RFQ system (CV002), the MEBT line (CV003), the SRF linac (CV004-CV008), the HEBT line (CV009-CV010) and the final segment of the beam duct (CV011-CV150). The volumes related to the atmospheres of the target and QT have been modeled by means of CV200 and CV300. Furthermore, cylindrical heat structures have been implemented to simulate the beam duct walls and the energy transfer across their boundary surfaces into control volumes.

The initiator event for the LOVA sequence is a rupture in the collimator wall and in the associated cooling loop. The water ingress inside the beam duct has been simulated by means of a flow path FL014, connecting the collimator cooling loop (CV400) with the pipe section, located in the TIR (CV011), where the leakage is produced. CV400 has been modeled as a single volume of 1 m3 with a void fraction of 0.99. A flow path area of 1.0E-3 m2 has been assumed for FL014.

MELCOR flashing model has been conservatively used for FL014 since it maximizes the production of liquid water droplets suspended in the atmosphere of control volumes, which could be potentially mobilized towards the lithium target. It is possible, in fact, that in the first instants, following the beginning of the accident, water vaporizes because of the initial ultra-high vacuum conditions inside the beam (10 -4 ÷10 -8 Pa); hence, vapor could reach the target faster than liquid water.

The mitigation action performed by the fast isolation valve (FIV), which is located in the beam duct segment corresponding to TIR (FL011), has been investigated. First, a nominal mitigated case (NOM \_ MIT) with FIV actuation has been studied. This sequence starts with a short steady state (0-1s) with an initial pressure of 100 Pa inside the beam line. This pressure value has been chosen to avoid numerical errors similar to those encountered in the previous scenario. Valve in FL014 opens at time 1 s to simulate the water ingress, while FIV complete closure occurs 100 ms after the beginning of the accident initiator. A parametric study has been performed by changing the FIV actuation time (cases MIT1, MIT2) with the purpose to calculate the amount of water which flows through the FIV until its closure. This latter parameter could be used to estimate the heat and hydrogen production from lithium-water reaction.

Table 2 shows the integral water mass (liquid, fog, vapor) flowing through FIV towards the target before its complete closure. It is interesting to observe that the total amount of water foreseen in the mitigated cases MIT1 and MIT2 increases by two orders of magnitudes with respect to the same quantity in the nominal case.

Table 2: Mobilized water predicted by MELCOR for the studied cases

| NOM  \_  MIT MIT1 MIT2  FIV actuation time (s)  0.1  0.5  1.0  Mobilized water (FL011)  Liquid (g)  20.0  1070.9  3462.7  Fog (g)  20.1  53.1  72.9  Vapor (g)  3.9  10.9  15.6  Total (g)  44.0  1134.9  3551.2   |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

Figure 3: Schematic of the MELCOR model for DONES accelerator

<!-- image -->

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

In the first seconds of the transient sequence (0-350 s), several oscillations in temperature and pressure, shown in Figs. 4 and 5, suggest ice formation in cryomodules (CV004-CV008) predicted by the water freezing model implemented in the fusion version of MELCOR 1.8.6. This effect is further demonstrated by the fact that temperature inside cryomodule CV005 raises from the initial value of 4.4 K up to a value of 273 K which is kept during a significant part of the computed sequence (290-700 s). On the other hand, pressure inside CV400 drops quite fast until reaching a quasi-steady state value of 4 KPa at the end of the simulation (1000 s).

Figure 4: Temperature transient inside the accelerator beam duct predicted by MELCOR

<!-- image -->

Figure 5: Pressure transient inside the accelerator beam duct predicted by MELCOR

<!-- image -->

## 5. Summary and conclusions

A first deterministic analysis on two accident sequences involving DONES lithium loop and accelerator has been carried out. Preliminary models for both systems have been developed using the fusion version of MELCOR 1.8.6 and first results have been obtained for the selected accident scenarios. Good agreement between MELCOR steady-state predictions and reference design requirements has been achieved for the lithium loop modeling. A first simulation of a LOFA scenario confirms the need for a very reliable beam shutdown system which can prevent further

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

consequences expected in this type of accident. Since this transient is highly dependent on the pump trip curve, it is desirable to explore, in the future, different pump coastdown curves in order to delay the fast disappearance of the lithium layer flowing in the TVC. Concerning the LOVA sequence with water ingress inside the accelerator beam duct, the analysis highlighted the importance of the safety role performed by the FIV in mitigating the accident event. However, the same safety component does not fully prevent some amount of water to potentially reach the lithium target even with a closure time of 100 ms. During MELCOR calculations of both scenarios, numerical problems due to the low resolution of EOS at very low pressures have been experienced. Phenomenology and uncertainties involved in these scenarios should be further explored to refine and upgrade the available models. Overall, accident analysis performed on DONES systems represents a continuous and iterative activity which is relevant for the future development of DONES plant design.

## Acknowledgements

This work has been carried out within the framework of the EUROfusion Consortium and has received funding from the Euratom research and training programme 2014-2018 under grant agreement No 633053. The views and opinions expressed herein do not necessarily reflect those of the European Commission. The support from the EUROfusion Engineering Grant programme under the task agreement AWP17-EEGCIEMAT/D'Ovidio is gratefully acknowledged.

## References

- [1] T. Pinna. Safety issues from the Failure Mode and Effect Analysis of the Lithium Facility and Test Facility. Technical Report, EFDA \_ D \_ 2MDT46, Dec. 2016.
- [2] T. Pinna. Safety issues from the Failure Mode and Effect Analysis of the Accelerator Systems. Technical Report, EFDA D 2MYRTW, Dec. 2017.

\_

\_

- [3] B.J. Merrill, et al. Recent development and application of a new safety analysis code for fusion reactors. Fusion Eng. Des., 109-111 (2016), pp. 970-974
- [4] F. S. Nitti. IFMIF-DONES Design Description Document (DDD) of Heat Removal Systems. Technical Report, EFDA \_ D \_ 2MMYWH, Sep. 2017.
- [5] D. Bernardi. IFMIF-DONES Target System Design Description Document (DDD). Technical Report, EFDA D 2N74W4, Oct. 2017.

\_

\_

- [6] DONES Plant Description Document (Preliminary Engineering Design Report). EFDA \_ D \_ 2MP8HQ v1.2, May 2018.
- [7] MELCOR Computer Code Manuals. Volume 2: Reference Manuals. Version 1.8.6 September 2005. NUREG/CR-6119, Vol.2, Rev.3. SAND 2005-5713