## Abstract

The IFMIF-DONES (International Fusion Material Irradiation Facility- DEMO Oriented Neutron Source) facility, currently under construction in Granada (Spain), is dedicated to testing materials under neutron irradiation, as part of advanced materials research for next-generation fusion reactors. The superconducting linear accelerator of the facility is intended to deliver a continuous-wave deuteron beam with an energy of 40MeV and an unprecedent average deuteron current of 125mA. The production of neutrons is then achieved by driving the 5 MW beam into a liquid lithium target. Beam diagnostics play a critical role in the IFMIF-DONES accelerator due to several unique challenges. These include the extremely high beam power, the harsh environment due to neutron and gamma radiation, and the required operational availability of the accelerator. Moreover, the accelerator may operate in pulsed and continuous wave for commissioning and standard operation, respectively. This work presents an overview of the main beam diagnostic techniques and strategies needed to address these challenges, the prototyping works that have been already achieved, and those to be still developed.

## INTRODUCTION

The strong global demand for sustainable, low-carbon electricity, particularly from reliable base-load power, has driven extensive research into fusion energy. Fusion is one of the few technologies that has the potential to meet this demand. However, achieving it involves complex, interrelated scientific and engineering challenges. One of the challenges to address is the study of materials that can withstand the extremely high radiation dose in fusion reactors. Within this framework, the IFMIF-DONES [1] project plays a crucial role by providing the material testing infrastructure essential for the development and qualification of fusion reactor components. To achieve this, IFMIF-DONES will generate fusion-reactor-like neutrons (up to 1017 55MeV neutrons per second). This neutron flux is produced by directing a continuous-wave 125 mA deuteron beam accelerated up to

∗ aurora.ortega@ifmif-dones.es

## BEAM DIAGNOSTICS FOR IFMIF-DONES: ADDRESSING THE CHALLENGES OF HIGH-POWER IRRADIATION FACILITIES

A.Ortega Moral∗ , IFMIF-DONES, Granada, Spain

J. Herranz, A. Ibarra, I.Podadera, C. Torregosa-Martin 1 , IFMIF-DONES, Granada, Spain

P. Cara, Fusion for Energy, Barcelona, Spain

C. de la Morena, D. Jiménez-Rey, C. Oliver, D. Regidor, A.Rodríguez Páramo, V. Villamayor CIEMAT, Madrid, Spain

F. Benedetti, J. Marroncle, Université Paris-Saclay, France

D. Cosic, T. Tadic, K. Tomic-Luketic, RBI, Zagreb, Croatia

L. Macia, IREC, Barcelona, Spain

J. F. Valenzuela Valdés, UGR, Granada, Spain

40MeV onto a lithium target. From a technological point of view, the facility is composed of three main elements, a deuteron accelerator, a liquid lithium target and irradiation modules to host the material samples for irradiation. In the last 20 years, prototypes of these three elements have been developed and operated in the context of the IFMIF EVEDA (Engineering Validation and Engineering Design Activities) project [2]. Notable examples include the Linear IFMIF Prototype Accelerator (LIPAc) in Rokkasho (Japan) [3], the EVEDA lithium test loop in Oarai [4], the Li loop (Lifus6) in Brasimone [5] as well of irradiation prototypes in the Belgian BR2 test reactor [6, 7]. Furthermore, in the last decade, significant integration efforts have been made during the engineering phase of the future facility and its three different parts [8]. These efforts have taken place within the framework of the EUROfusion Consortium (Work Package Early Neutron Source, WPENS) in close collaboration with the Fusion for Energy organization [9]. The IFMIF-DONES infrastructure is currently under construction, with the various systems of the facility also entering their respective construction phases [10, 11]. In the present work, only the former topic-related to the Accelerator System (AS) -is addressed, with a focus on its specific features and the beam diagnostic techniques required to properly tune, characterize, and monitor the accelerated beam.

## DONES ACCELERATOR AND BEAM DIAGNOSTICS STRATEGY

The AS system can be divided into the following components, as shown in a conceptual form in Fig. 1:

- Injector: composed by a source and extraction subsystem for extraction and acceleration of deuteron and protons up to 100 keV and a Low Energy Beam Transport (LEBT) line to guide the low-energy ions to the Radio-Frequency Quadrupole (RFQ).
- RFQ: provides deuteron/proton acceleration from 100 keV to 5 MeV.
- MEBT: Medium Energy Beam Transport Line shaping the beam in both transverse and longitudinal directions for a proper transport and matching of the beam from

Figure 1: DONES Accelerator System conceptual design.

<!-- image -->

RFQ into the SRF (Super Conducting Radio Frequency) Linac.

- SRF LINAC: aims to accelerate the deuteron beam from 5MeV to 40MeV, by directing it through a set of superconducting cavities and focusing superconducting solenoids.
- HEBT: The High Energy Beam Transport line guides and shapes the beam towards the lithium target. The final section of the main beam line, known as the Target Interface Room (TIR), is dedicated to last-stage beam diagnostics before the beam reaches the target, making it a critical component of the system. The HEBT also includes a dedicated secondary line to be used during commissioning in which the beam is transported towards a high-power beam dump.

## Accelerator Main Features

Some of the key aspects and challenges of the IFMIFDONES AS are the following:

- Unprecedented deuteron average current (125mA) at 40 MeV energy.
- Achieving the irradiation goals, which determines an inherent availability of 87% during 20 years, implying the use of high reliability components and very short limited maintenance periods.
- Harsh environment, due to the high flux of emitted neutrons and 𝛾 rays (from interactions with pipes and components), even stronger close to the target because of backscattering radiation from the interaction of the beamwith the target.
- Different modes of operation for commissioning and operation, proton and deuteron beams in pulsed and continuous wave.

## Implications for Beam Diagnostics

These key aspects of IFMIF-DONES presented above had some common implications for the IFMIF-DONES beam diagnostics strategy:

- The techniques for beam diagnostics in IFMIF-DONES shall be compatible with the high current, avoiding any interceptive methods in nominal beam power operation.
- Detection devices along the beamline should be highreliable and robust enough to monitor continuously during long periods without maintenance. Self-calibration processes are foreseen for the main diagnostics, avoiding possible drifts over time and achieving a beam operation with minimal interruptions.
- Detector devices shall be radiation-hard and must account for background signal contributions, which can affect measurement accuracy.
- Beam diagnostics strategy for IFMIF-DONES shall be able to characterize the beam under different operating modes: continuous wave, pulsed operation, and varying duty cycles, for both deuteron and proton beams. Detectors that can operate in both modes must be able to cover a wide dynamic range. When dual mode operation is not feasible, interceptive diagnostics are required to perform measurements in commissioning phase.

## MAIN BEAM DIAGNOSTICS DEVICES CHOSEN FOR IFMIF

Efforts have focused on implementing standardized detection devices along the AS. The following subsections present the general technologies chosen for measuring beam current, beam position, beam profile, and beam losses. Any exceptions related to specific accelerator sections will be addressed when discussing the beam diagnostics layout along the AS in next section.

## Current Detectors

Several types of current detectors are planned to be installed along the beamline, including ACCT (Alternating Current Current Transformer) and FCT (Fast Current Transformer) for pulsed mode and DCCT (Direct Current Current Transformer) and CWCT (Continuous Wave Current Tranformer) detectors for continuous-wave mode. Although these instruments are based on well-established technologies, the IFMIF-DONES case presents specific challenges. In particular, space constraints require the combined use of ACCT and CWCT devices in certain sections of the accelerator, and customized on-air current detectors are needed at the end of the beamline, where the beam size exceeds the range of commercial options.

## Beam Position Monitors

Non-interceptive beam position monitors (short stripline type,except those in the SRF-LINAC, as explained in the following section), are planned to be installed for IFMIFDONES. Short stripline BPM (Beam Position Monitor) have been successfully proved and characterized at LIPAc [12,13] for both transverse beam position and phase measurement for beam mean energy determination. These devices must operate in both CW and pulsed modes, requiring a dynamic range exceeding 60 dB (from 125mA during nominal operation down to 10-100 µA during early commissioning). Fast sampling capability is also essential to capture transient signals without distortion during commissioning. In addition, customized BPM solutions will be required in the final section of the AS, where the large beam aperture and debunching effects must be properly accounted for, particularly important in the last 30mwhere the deuterons travel at maximum energy.

## Beam Profile Detectors

Several non-interceptive beam profile detectors have been studied and tested for IFMIF-DONEs over the years. These include luminescence-based profile monitors, such as Fluorescence Profile Monitors (FPM) using PMT arrays or CID cameras as detection systems [14, 15] and those based on ionization processes such as Ionization Profile Monitors (IPM) [16, 17]. Among these options, Fluorescence Profile Monitors with PMT arrays demonstrated the best performance during the last LIPAc commissioning phase [13, 18] and are thus the ones to be installed in the IFMIF-DONES AS. Interceptive methods remain essential in the commissioning stage, both to characterize the beam and to provide cross-checks between interceptive and non-interceptive techniques. SEM grid technology is (at the current stage) foreseen for this purpose. As in the case of current detector, due to space limitation in some of the accelerator parts, both techniques are planned to be integrated in a single vessel, denominated Beam Profile Chamber (BPC).

## Beam Losses Detectors

Beam loss detection, especially in the case of high-power machines, must have two different functionalities: triggering the Machine Protection System (MPS) in the case of a fatal beam loss, which means having a response time below 1 μs and monitoring small losses over time down to 1W/m. These requirements can be met by using electronics with variable integration time.

Beam Loss Monitors (BLMs) based on ionization chambers (LHC type) are for the moment a first alternative for beam loss monitoring along the AS. BLM based on ionization chamber have been successfully proven for LHC, yet in the case of IFMIF-DONES, only neutrons and 𝛾 can traverse the beam pipes. In this sense, neutron detection is of crucial importance, particularly for distinguishing beaminduced signals from background. To address this, other alternatives are under study as neutron beam-loss detectors (nBLM) based on Micromegas technology. These detectors are specifically designed to provide high sensitivity to neutrons while maintaining very low efficiency for 𝛾-rays and X-rays. In specific locations, other beam loss monitor devices are foreseen, as discussed in the following section.

## DIAGNOSTICS LAYOUT AND SPECIFIC FEATURES ALONG THE BEAMLINE

Beam diagnostics must be distributed across the AS for tuning, characterization and monitoring of the accelerated beam. In this section, the overall diagnostics layout in the main beam line is presented. Specific features associated with each part of the machine are also highlighted, with an emphasis on particularities relative to the diagnostics described in the previous section. The different diagnostics devices are graphically represented as indicated in Fig. 2 along the figures in this section.

Figure 2: Beam diagnostics representation.

<!-- image -->

<!-- image -->

Figure 3: Injector diagnostics layout.

<!-- image -->

## Injector

A faraday cup and ACCT detector are installed in the low energy transport line, together with a beam profile chamber (BPC) in a beam diagnostics chamber. Other beam characteristics must be measured, as the beam species (doppler shift analyzer) and the beam emittance, also installed in the beam diagnostics chamber as shown in Fig. 3. A second beam diagnostics chamber is also foreseen during the injector commissioning phase.

## Diagnostics in RFQ

Only beam loss monitors are foreseen in this section of the AS, and the final number will depend on the chosen BLM size and technology.

## Diagnostics in MEBT

In the Medium Energy Beam Transport (MEBT) line, space is highly constrained. A combination of ACCT and CWCT current transformer is planned to be installed close to the injector, and four beam position monitors will be integrated into magnetic elements (quadrupole and dipole structures), as shown in Fig. 4. During the commissioning phase, further diagnostics are planned to be installed in a movable structure named DPLATE (Diagnostics-Plate) [19] in which the beam will be fully characterized before the installation of the SRF-LINAC.

## Diagnostics in SRF-LINAC

The detection devices installed in this section must operate at cryogenic temperatures. The BPMs installed in this section are based on RF pickups (following the LHC design), whose performance under cryogenic conditions has already been successfully demonstrated. They are planned to be installed in each solenoid and between cryomodules (warm sections) together with interceptive profile measurements (SEM grids), as shown in Figs. 5 and 6.

Figure 4: MEBT diagnostics layout.

<!-- image -->

Figure 5: SRF-LINAC diagnostics layout.

<!-- image -->

Figure 6: Cryomodule diagnostics layout.

<!-- image -->

Since cryomodules are highly sensitive to radiation, accurate beam lossmeasurements are essential. In each cryomodule (a total of five for SRF-LINAC), two beam loss monitors per cavity and three μBLMs per solenoid are planned to be integrated, as shown in Fig. 6. The latter are based on solid-state ionization chambers, as gaseous detectors are no longer suitable for cryogenic environments. For the μBLMs, CVD diamond detectors are currently the best option, as they provide higher sensitivity to fast neutrons compared to gamma and X-rays, thereby reducing the impact of background signals.

Figure 7: HEBT diagnostics layout different sections. Section 1 (a), Section 2 (b), Section 3 (c), HEBT TIR (d).

<!-- image -->

## Diagnostics in HEBT

A total of 14 current monitors will be installed along the HEBT main line to measure beam current in both continuous and pulsed modes. These include 6 ACCTs, 1 FCT, 2 CWCTs, and 5 DCCTs. In addition, 18 Beam Position Monitors (BPMs) and 12 Beam Profile Chambers (BPCs) will be distributed throughout this section. The precise locations of these devices are defined based on beam dynamics studies and shown in Fig. 7. Beam loss detectors are also planned, with their exact number depending on the final design choices and the overall BLM size.

## Diagnostics in HEBT-TIR

Special considerations are required at the end of the beam line, where diagnostic devices are exposed to backscattering radiation resulting from beam-target interactions. Radiationhard solutions must be implemented to minimize the need for frequent device replacement. More importantly, the performance of these detectors in such a harsh environment requires further study, particularly for FPMs and BLMs, where background signals may significantly affect measurement accuracy. The precise location of the devices in this last part of the acceleration system has been further studied in Ref. [20] and is shown in Fig. 7(d). Monitoring the beam in this final region near the target is critical for safe and successful machine operation. For this reason, the installation of a novel 8-pickup BPM, capable of detecting changes in the beam shape fast enough so they can be used for machine protection, is currently under study. Additionally, the deployment of a target beam profile device based on Optical Transition Radiation (OTR) to continuously monitor the beam footprint is also being considered.

## VALIDATION STATUS AND FURTHER EXPERIMENTAL CAMPAIGNS

## Validation Achievements

Many of the detection devices addressed in this work have already been tested at LIPAc during the commissioning phases [13, 18], such as current detectors for pulse mode, stripline beam position detectors, fluorescence beam profile monitors and LHC-type BLM. Other detectors have been tested in different facilities in order to validate their use for IFMIF-DONES:

- μBLM (CVD) test at RBI, Zagreb, Croatia [21].
- Neutron Beam Loss Monitor (nBLM) experimental campaings at CEA, Paris-Saclay France [22] .
- FPM electronic irradiation experiments at CIEMAT , Madrid, Spain.

Simulations regarding 8 RF pickups beam position monitor and OTR beam profile monitor located at the end of the acceleration line (TIR) are currently being conducted by the IFMIF-DONES joint team. For the latest, an experimental campaign will be conducted in 2026 aiming to vaporize lithium and exciting the resulting vapor via electron beam impact to study the feasibility of the device to monitor the beam footprint.

## Next Steps

Despite significant progress in beam diagnostics over the years, further studies are still required. The main steps for validating the diagnostic techniques in IFMIF-DONES, outlined below, are essential for achieving the project's objectives.

- Test of diagnostics working at continuous wave
- Test of μBLM in SRF-LINAC
- Test of devices working at final energy ranges
- Study of influence of background signals in operation conditions
- Further study of beam loss detectors suitable in each part of the AS according to the beam energy
- Study of performance of detectors located at the highirradiation zone at the final part of the Accelerator

## CONCLUSIONS

Significant progress has been achieved towards the IFMIFDONES beam diagnostics strategy, for which unique features of the accelerator have to be taken into account (beam intensity, harsh environment, availability and operation modes). The main beam diagnostics technologies chosen for IFMIFDONES regarding current (ACCT, FCT, CWCT, DCCT), position (short-stripline BPM), profile (FPM, SEM) and beam losses (ionization LHC-type) are stated in this work. The diagnostics layout along the beamline is discussed, adding some particularities:

- The coupling of several devices in one due to space limitation in some section of the accelerator
- The use of cryogenic-compatible devices in the SRFLINAC (RF BPM, solid-state ionization chamber for BLM)
- The special considerations required for the diagnostics devices at the end of the beam line due to the harsh environment (accuracy of measurements and radiation hard-solutions)
- The novel techniques under study for the characterization of the beam footprint (OTR profile measurements) and the fast detection of changes in the beam shape right before interaction with the target.

Although most devices have already been tested in various experimental campaigns, additional steps have been identified in this work that are crucial for achieving full validation for IFMIF-DONES.

## ACKNOWLEDGMENTS

This work has been carried out within the framework of the EUROfusion Consortium, funded by the European Union via the Euratom Research and Training Programme (Grant Agreement No 101 052 200 - EUROfusion). Views and opinions expressed are however those of the author(s) only and do not necessarily reflect those of the European Union or the European Commission. Neither the European Union nor the European Commission can be held responsible for them.

## REFERENCES

- [1] W. Królas et al., "The IFMIF-DONES fusion oriented neutron source: evolution of the design", Nucl. Fusion, vol. 61, 2021. doi:10.1088/1741-4326/ac318f
- [2] J. Knaster et al., "IFMIF: overview of the validation activities", Nucl. Fusion, vol. 53, no. 11, p. 116001, 2013. doi:10.1088/0029-5515/53/11/116001
- [3] K. Atsushi et al., "Commissioning status of linear IFMIF prototype accelerator (LIPAc)", in Proc. HB'18, Daejeon, South Korea, 2018.

[doi:10.18429/JACoW-HB2018-THP1WB01](https://doi.org/10.18429/JACoW-HB2018-THP1WB01)

- [4] H. Kondo et al., "The start-up and observation of the Li target in the EVEDA Li test loop", Fusion Eng. Des., vol. 89, no. 7, pp. 1688-1693, 2014.

[doi:10.1016/j.fusengdes.2014.02.022](https://doi.org/10.1016/j.fusengdes.2014.02.022)

- [5] A. Aiello et al., "Lifus (lithium for fusion) 6 loop design and construction", Fusion Eng. Des., vol. 88, no. 6, pp. 769-773, 2013. doi:10.1016/j.fusengdes.2013.02.129
- [6] F. Arbeiter et al., "Design description and validation results for the IFMIF High Flux Test Module as outcome of the EVEDA phase", Nucl. Mater. Energy, vol. 9, pp. 59-65, 2016. doi:10.1016/j.nme.2016.04.013
- [7] F. Arbeiter, et al., "The accomplishments of lithium target and test facility validation activities in the IFMIF/EVEDA phase", Nucl. Fusion, vol. 58, no. 1, p. 015001, 2017. doi:10.1088/1741-4326/aa8ba5
- [8] W. Królas et al., "The IFMIF-DONES fusion oriented neutron source: evolution of the design", Nucl. Fusion, vol. 61, p. 125002, 2021. 2021 doi:10.1088/1741-4326/ac318f
- [9] A. Ibarra et al., The IFMIF-DONES project: preliminary engineering design, Nucl.Fusion, vol. 58, no. 10, p. 105002, 2018, doi:10.1088/1741-4326/aad91f
- [10] I. Podadera et al., "Overview and current status of the IFMIFDONES Accelerator Systems", Nucl. Fusion, 2025. doi:10.1088/1741-4326/ade267
- [11] S. Becerril et al., "Update on the status of the IFMIF-DONES Test Systems", Nucl. Fusion, 2025. doi:10.1088/1741-4326/ade9dd
- [12] I. Podadera et al., "Commisioning of Beam Position and Phase Monitors for LIPAc", in Proc. IBIC'16, Barcelona, Spain, Sep. 2016, pp. 326-328. doi:10.18429/JACoW-IBIC2016-TUPG07
- [13] S. Kwon et al., "High Beam Current Operation with Beam Diagnostics at LIPAc", in Proc. HB'23, Geneva, Switzerland, Oct. 2023, pp. 649-655.
10. [doi:10.18429/JACoW-HB2023-FRC1I2](https://doi.org/10.18429/JACoW-HB2023-FRC1I2)
- [14] J. M. Carmona et al., "First Measurements of NonInterceptive Beam Profile Monitor Prototypes for Medium
12. to High Current Hadron Accelerators", in Proc. HB'10, Morschach, Switzerland, Sep.-Oct. 2010, paper WEO1C04, pp. 502-505.
- [15] J.M. Carmona et al., "Measurements of noninterceptive fluorescence profile monitor prototypes using 9 MeV deuterons", Phys. Rev. Spec. Top. Accel. Beams, vol. 15, p. 072801, 2012. doi:10.1103/PhysRevSTAB.15.072801
- [16] P. Abbon et al., "Beam Transverse Profile Monitor Prototype for IFMIF-EVEDA Accelerator", in Proc. BIW'08, Lake Tahoe, CA, USA, May 2008, paper TUPTPF064, pp. 268-269.
- [17] J. Marroncle, P. Abbon, F. Jeanneau, J.-Ph. Mols, and J. Pancin, "Beam Transverse Profile Monitor based on Residual Gas Ionization for IFMIF-EVEDA Accelerator", in Proc. DIPAC'09, Basel, Switzerland, May 2009, paper TUPD34, pp. 375-377.
- [18] T. Akagi et al., "Completion of Phase B+ beam commissioning of Linear IFMIF Prototype Accelerator (LIPAc)", in Proc. LINAC'24, Chicago, IL, USA, Aug. 2024, pp. 705-708. doi:10.18429/JACoW-LINAC2024-THPB036
- [19] I. Podadera Aliseda et al., "ADiagnostics Plate for the IFMIFEVEDAAccelerator", in Proc. EPAC'08, Genoa, Italy, Jun. 2008, paper TUPC083, pp. 1248-1250.
- [20] L.Macia et al., "Engineering status of IFMIF-DONES High Energy Beam Transport line and Beam Dump system inside the TIR and RIZ", Fusion Eng. Des., vol. 202, p. 114312, 2024. doi:10.1016/j.fusengdes.2024.114312
- [21] D. Cosic et al., "Charge collection efficiency of scCVD diamond detectors at low temperatures", Diam. Relat. Mater., vol. 127, p. 109184, 2022.
20. [doi:10.1016/j.diamond.2022.109184](https://doi.org/10.1016/j.diamond.2022.109184)
- [22] Thomas Papaevangelou et al., "ESS nBLM: Beam Loss Monitors based on fast neutron detection", in Proc. HB'18, Daejeon, South Korea, Jun 2018. doi:10.18429/JACoW-HB2018-THA1WE04