## Abstract

IFMIF-DONES (International Fusion Materials Irradiation Facility - DEMO Oriented Neutron Source) is devoted to the irradiation of fusion materials, based on a high energy linear accelerator and a lithium-deuteron stripping reaction, creating the high intensity neutron source which simulates the damage on the first wall of the future fusion reactors.

The core of the facility are the Accelerator, Lithium and Test Systems hosted inside IFMIF-DONES Facility, within the so-called Main Building (MB). The detailed design of this building was first initiated during the IFMIF-EVEDA (Engineering Validation and Engineering Design Activities) phase in the framework of the Broader Approach (European Union - Japan Bilateral Agreement) and pursued within EUROfusion for the development of an Early Neutron Source.

The design of the MB has evolved around the rooms where the fundamental equipment is located, as it is the case of the Accelerator Vault (AV) or the Test Cell (TC).

These are the main areas in terms of neutronics shielding, where nuclear reactions occur and where the samples are irradiated.

The floors arrangement and the structural concept are highly determined by the location and dimensions of those most restricting rooms.

In this work, it is presented the status of the integration into the design of the MB structure of the safety requirements from the definition of the radiation maps, neutronics studies and the capabilities of the constructive solutions.

## MANUSCRIPT

MB Structure Safety Requirements

The IFMIF-DONES facility is classified as a first category radioactive scientific facility, according to the national regulatory council. Therefore, the applicable regulations are not directly nuclear standards, but rather a justified adaptation of them [1].

The MB supporting structure shall comply not only with the basic function of supporting the equipment and the activity inside, but also with safety related functions:

- Accomplishment of the seismic requirements, considering the site of Escúzar (Granada) and the soil characteristics, described in [2].
- Radiation Protection (RP), according to the radiation maps, the dose rates per room must be limited during

## CONCRETE STRUCTURE AND SHIELDING IN THE IFMIF-DONES MAIN BUILDING

M. Luque 1 , S. Becerril 1 , Á. Ibarra 1 , J. Maestre 1 , F. Martín-Fuertes 1 , I. Podadera 1 ,

C. Torregrosa-Martín 1 , M.J. Martínez-Echevarría 2 , Y. Qiu 3 , T. Piotrowski 4 1 IFMIF-DONES España Consortium, Granada, Spain 2 ETSICCP University of Granada, Spain 3 Karlsruhe Institute of Technology (KIT), Germany 4 Warsaw University of Technology, Poland

expected occupation depending on the considered mode: beam-on operation or maintenance. In addition, accident conditions are considered for the design development. The general safety approach assigns the MB the safety functions of "providing confinement of radioactivity" and "providing limitation of radioactive exposure" [1], i.e., shielding and access control. The radiological hazards produced during the operation of IFMIF-DONES are the neutral radiation beams (neutrons and gamma), tritium diffused from components, as well as some Activation Products (AP's), and Activated Corrosion Products (ACP's), generated and trapped in the lithium loops.

Structural and other materials receiving neutrons and deuterons lead to the AP's contribution, which in normal operation is mostly not mobilizable due to their strong fixation in the structural matrix, while some amount of gases can also occur. Adequate shielding and atmosphere control shall be provided in order to avoid non acceptable levels of external and internal exposure to high radiation levels, confining the radiation within the defined controlled areas.

- Structural integrity in the event of an aircraft impact [3].

Regarding confinement, the rooms classification is under assessment as the design of the components progresses. From the point of view of neutronics simulations and the implementation of the safety regulations, emerge the MB radiation maps, and the classification of the contamination areas and the working areas.

The qualitative criteria for defining the following contamination areas are summarized in Table 1 (alfa contamination not relevant; only for definition), based on [4]:

- CZ1: Areas free from radioactive contamination, whether surface or airborne.
- CZ2: Areas with very low probability of surface and/or airborne contamination.
- CZ3: Areas in which some surface contamination could be present but it is normally free from it.
- CZ4: Areas in which permanent, as well as occasional, contamination levels are so high that there is normally no access permitted for personnel, except with appropriate protective equipment.
- CZ5: Areas in which the operations of handling and manipulating of the highest irradiation components are carried out.

Table 1: Qualitative Classification of Contamination Areas

| Contamination  Zone (CZ)  Surface contamination  (Bq/cm 2 )  Average in 300 cm 2  Airborne contamination  (%DACL)*  CZ1  Not detectable  No risk of airborne  contamination  CZ2  &lt; 4 (β-ɣ &lt; 0.4 (α)  &lt; 10  CZ3  &lt; 40 (β-ɣ) &lt; 4 (α)  &lt; 100  CZ4  &lt; 400 (β-ɣ) &lt; 40 (α)  &lt; 1000  CZ5  ≥ 400 (β-ɣ) ≥ 40 (α)  ≥ 1000   |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

*Derived Air Concentration Limit

Figure 1 shows the contamination areas in the first floor.

In the centre of the image, it is seen the Target Interface Room (TIR) and the TC, both in red colour for a forbidden access. The last part of the Linear Accelerator, called High Energy Beam Transport (HEBT) line section, is located inside the Target Interface Room (TIR). The TC is where the neutron source is confined for the material samples irradiation.

Figure 1: Layout of the contamination classification of the rooms surrounding the TC.

<!-- image -->

The design of the MB rooms also applies the ALARA (As Low As Reasonably Achievable) principle in order to minimize as possible the exposure to radiation below the legal limits.

Following this principle, the rooms are classified according to whether the permanence is permitted or forbidden, in Table 2, according to the Spanish Regulation [5]:

Table 2: Radiation Protection Working Areas Class

| RP Working Area Contamination  Zone  Effective Dose  Rate  Supervised Area  CZ1  &lt; 3 µSv/h  Controlled  Free Permanence  CZ2  &lt; 10 µSv/h  Limited Permanence  CZ3  &lt; 1 mSv/h  Specially Regulated  CZ4  &lt; 100 mSv/h  Forbidden  CZ5  ≥ 100 mSv/h   |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

## Main Building Layout

The MB is a 159 m length, four storeys concrete volume. The rooms where the neutron source is produced are located in the first floor.

The main equipment of the Accelerator Systems (AS) is located in a 94 m length and 7.5 m height AV. At the end of the AV, the TC hosts the lithium target and the main equipment of the Test Systems (TS) where the neutron source is confined for the irradiation of the modules. This TC is 9 m depth and is highly shielded by primary surrounding shielding walls, made of heavy concrete: the so-called

Removable Biological Shielding Blocks or RBSBs; the Lower Shielding Plug; and the Upper Shielding Plug [6]. These are composed of heavy concrete which provides attenuation of gamma rays and neutrons radiation [7]. To be conservative, the reference concrete density is &gt;3.4 g/cm 3 taken from ITER case. IFMIF-DONES are developing a magnetite concrete &gt;3.9 g/cm 3 density, characterized by mechanical and radiation shielding properties superior to those of the reference one. Additionally, the MB structure offers extra shielding made of wide ordinary concrete walls, 2.5 g/cm 3 density. These rooms are highlighted in Fig. 2 and confronted with the neutronics simulation for the AV case in Fig. 3.

<!-- image -->

Figure 2: Layout of the MB first floor. Around the Accelerator Systems, walls are ranged between 1.5 m in the AV and 2.5 m in the TIR. Regarding the TC, walls are 3 m width downstream, and 4 m width upstream the beamline.

<!-- image -->

Figure 3: Biological dose (mSv/h) during operation of the accelerator in the AS room and in the TC. Radiation maps from neutronics studies [8].

<!-- image -->

The TC and the last part of the AS, housing the modules located in the TIR, shall be remotely maintained. For this purpose, an Access Cell (AC) is designed, located above the TC. It is provided with 15 m height, and a set of remote handling bridge cranes. This room is highlighted in Fig. 4. The walls are made of ordinary concrete, 1 m width.

Figure 4: Layout of the MB second floor.

<!-- image -->

Apart from the neutronic shielding function, other walls comply with other safety functions mentioned above.

In Fig. 5 it is highlighted the area dedicated to the solid radioactive materials treatment systems in the first floor and in the ground floor in Fig. 6.

Figure 5: Layout of the Radioactive materials treatment area on the first floor.

<!-- image -->

The ground floor also houses the lithium loop in charge of providing the liquid lithium jet target where the deuteron beam impinges to create the neutron source. The perimetral walls act as confinement barrier of the lithium in case of an accidental leakage.

Figure 6: Layout of the Radioactive materials treatment area on top, the Lithium Loop Cell in the centre, and the temporary waste storage on the ground floor.

<!-- image -->

The MB has been designed as a robust ordinary concrete volume. Appropriate wall thicknesses are designed in compliance with Radiation Protection room classification to protect the workers, as well as also to minimize the dose rate at the facility fence, which is the third line of defence.

The construction method shall guarantee no cracks, gaps nor stream paths in the shielding walls. An exceptional case is the TC, depicted in Fig. 7. Its design [6] contributes to its constructability. The ordinary concrete shielding wall (the so-called bucket) attaches a steel liner, providing separation between permanent and RBSBs made of heavy concrete.

Apart from the walls and slabs, local shielding are foreseen for the most activated components to attenuate the resulting radiation from some processes, which translates sometimes in an enlargement of the walls in local areas as it is the case of the beam dump on the Radiation Isolation Room of the AV, or the reinforcement of the walls of the room for Complementary Experiments behind the TC.

Furthermore, some of the rooms whose walls have a confinement barrier safety function, incorporates a steel liner as a previous confinement barrier. It is the case of the Lithium Loop Cell.

Figure 7: Layout of the Radioactive materials treatment area on the first floor.

<!-- image -->

## REFERENCES

- [1] C. Torregrosa et al., "Safety Engineering Approach and Licensing Strategy of IFMIF-DONES", submitted to Nuclear Fusion, 2025.
- [2] M. Ruiz et al., "Seismic safety strategy for IFMIF-DONES", Nucl. Fusion, vol. 19, no.5, p. 05065, Jan. 2025. doi 10.1088/1741-4326/ada8bc
- [3] F. Martín-Fuertes et al., "Implementation of Safety Aspects in IFMIF-DONES Design", J. Nucl. Eng., vol. 3, no. 4, pp. 373-384, Nov. 2022. doi:10.3390/jne3040024
- [4] ISO 17873:2004 "Nuclear facilities: Criteria for the design and operation of ventilation systems for nuclear installations other than nuclear reactors".
- [5] CSN Safety Guide 7.6, Rev. 1 "Contents of radiation protection Manuals of Nuclear and Radioactive Installations involved in the nuclear fuel cycle". Issue date: Apr. 2016.
- [6] A. Zsákai et al., "Evolution of IFMIF-DONES' heart: System overview of the Test Cell," J. Nucl. Mater., vol. 598, p. 155185, Sep. 2024.
7. doi:10.1016/j.jnucmat.2024.155185
- [7] T. Piotrowski et al., "Optimization and evaluation of structural and shielding concrete for IFMIF-DONES", Nucl. Mater. Energy, vol. 38, p. 101597, Mar. 2024. doi:10.1016/j.nme.2024.101597
- [8] Y. Qiu et al., "Overview of recent advancements in IFMIFDONES neutronics activities", Fusion Eng. Des., vol. 201, p. 114242, Apr. 2024.

doi:10.1016/j.fusengdes.2024.114242