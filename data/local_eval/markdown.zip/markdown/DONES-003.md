<!-- image -->

WPENS-CPR(17) 17514

P Arena et al.

## Preliminary engineering design of DONES Target Assembly

Preprint of Paper to be submitted for publication in Proceeding of 13th International Symposium on Fusion Nuclear Technology (ISFNT)

<!-- image -->

This work has been carried out within the framework of the EUROfusion Consortium and has received funding from the Euratom research and training programme 2014-2018 under grant agreement No 633053. The views and opinions expressed herein do not necessarily reflect those of the European Commission.

This document is intended for publication in the open literature. It is made available on the clear understanding that it may not be further circulated and extracts or references may not be published prior to publication of the original when applicable, or without the consent of the Publications Officer, EUROfusion Programme Management Unit, Culham Science Centre, Abingdon, Oxon, OX14 3DB, UK or e-mail Publications.Officer@euro-fusion.org

Enquiries about Copyright and reproduction should be addressed to the Publications Officer, EUROfusion Programme Management Unit, Culham Science Centre, Abingdon, Oxon, OX14 3DB, UK or e-mail Publications.Officer@euro-fusion.org

The contents of this preprint and all other EUROfusion Preprints, Reports and Conference Papers are available to view online free at http://www.euro-fusionscipub.org. This site has full search facilities and e-mail alert options. In the JET specific papers the diagrams contained within the PDFs on this site are hyperlinked

## Preliminary engineering design of DONES Target Assembly

P. Arena a , D. Bernardi b , G. Bongiovì a , P. A. Di Maio a , G. Miccichè b , F. S. Nitti b , M. L. Richiusa a

a Dipartimento di Energia, Ingegneria dell'Informazione e Modelli Matematici, Università di Palermo, Viale delle Scienze, I-90128 Palermo, ITALY b ENEA C.R. Brasimone, I-40032 Camugnano (BO), ITALY

The design of the Demo Oriented NEutron Source (DONES) is the main objective of the Work Package Early Neutron Source (WPENS) of EUROfusion Power Plant Physics and Technology (PPPT) programme. DONES is an IFMIF-based neutron source with the goal of testing and qualifying candidate materials to be used in DEMO and future fusion power plants.

In the framework of these activities, a research campaign has been carried out at the University of Palermo, in close cooperation with ENEA labs, in order to assess the thermomechanical performances of the DONES target system, endowed with an integrated Target Assembly (TA) when it undergoes the thermomechanical loads typical of its nominal operating scenario. The effects on TA behaviour of two possible different configurations for the accelerator beam foot-print have been investigated, considering an entire (20x5 cm²) or a halved (10x5 cm²) beam foot-print area with respect to that of IFMIF.

The study has been carried out following a theoretical-numerical approach, based on the Finite Element Method (FEM), and adopting the qualified ABAQUS v. 6.14 commercial FEM code.

The obtained thermomechanical results have been assessed in order to check whether the BP deformation field is such to prevent the contact of the BP itself with the High Flux Test Module, as well as to verify their compliance with the design criteria foreseen for the structural material. To this purpose, a stress linearization procedure has been performed along the most critical paths located within the BP, in order to check the fulfilment of the rules prescribed by the ITER structural design code SDC-IC. The obtained results are herewith presented and critically discussed.

Keywords: Keywords: DONES, IFMIF, Target Assembly, thermomechanics, FEM analysis

## 1. Introduction

The availability of an intense neutron flux is mandatory for the development, test and qualification of materials candidate to be used as structural materials in future fusion nuclear reactors. To this purpose, the international community has decided to develop the International Fusion Irradiation Materials Facility (IFMIF), an intense neutron source able to produce a neutron flux of ~10 18 n·m -2 ·s -1 [1].

It is in the framework of these activities that the Work Package (WP) Early Neutron Source (ENS) of the EUROfusion action finds its place [2]. The main objective of this WP is the development of the Demo Oriented NEutron Source (DONES), a deuteron-driven neutron source, where a 125 mA deuteron (D + ) ion beam at the energy of 40 MeV will strike a lithium flowing film in order to generate an intense neutron flux.

Among the different R&amp;D activities nowadays ongoing on DONES, the design of the Target Assembly (TA) plays a key-role, since this component will host the lithium flow and the interaction with deuterons. It is then fundamental to assess the thermomechanical behaviour of the DONES TA, in order to assure that the thermal, stress and displacement fields arising within it do not lead the TA to the structural crisis.

A campaign of thermomechanical analyses has been therefore launched at the Department of Energy, Mathematical Models and Information engineering

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

(DEIM) of the University of Palermo, that is from longtime involved in the research activities on IFMIF and DONES [3-8], in order to investigate the thermomechanical performances of the DONES TA when it undergoes the loads and boundary conditions typical of the nominal operating scenario.

The study has been conducted adopting a theoreticalnumerical approach and using the quoted Finite Element Method (FEM) code Abaqus v.6-14.

The obtained results are herewith reported and critically discussed.

## 2. DONES target system

The DONES target system (Fig. 1) is that group of components deputed to circulate the lithium inside the Test Cell (TC) and host the interactions between the deuteron beam and the lithium jet. This latter function will be addressed to the Target Assembly (TA) that represents, for this reason, the core of the whole target system. Moreover, the target system takes into account the lithium inlet and outlet pipes, the TA support structure, the beam duct and the Quench Tank (QT).

The TA, composed of the inlet and outlet nozzles, the target chamber and the back-plate, is entirely made of EUROFER steel, is welded to the lithium inlet pipe and it is supported by the target chamber arms laying on the support structure, directly fixed to the ground by means of a proper bolt system. Both the target chamber and the outlet nozzle are connected with the beam duct and the QT, respectively, by means of bellows. Concerning the lithium inlet pipe, it can be divided in two regions connected by means of a Fast Disconnecting System (FDS). The former, represented in yellow in Fig. 1, is made of EUROFER steel and will be removed with the TA, whereas the latter, coloured in green, is made of AISI 316L steel and it will not be replaced during the TA maintenance and/or replacement operations.

Figure 1. DONES target system.

<!-- image -->

This new design of the target system complies with the last changes made on the DONES design, such as the QT located inside the TC, a shorter outlet nozzle in order to reduce lithium instabilities and a TA endowed with an integrated Back-Plate (BP) instead of the replaceable bayonet-BP concept adopted until now.

## 3. Thermomechanical analyses

The numerical analysis has been aimed at assessing the thermomechanical behaviour of the DONES target system under the steady state nominal operating scenario, in order to verify whether its components might safely withstand the thermomechanical loads it undergoes without incurring in significant deformations, which may cause interferences with the High Flux Test Module (HFTM) or generate an excessive misalignment between the deuteron beam and lithium foot-print. The influence of an alternative foot-print section on the DONES TA thermomechanical performances has been assessed as well and a stress linearization procedure has been performed along some particularly loaded paths in order to check the fulfilment of the SDC-IC design criteria [9].

## 3.1 FEM model

A realistic 3D FEM model of the DONES target system has been developed. It reproduces the TA integrated with its support structure and the entire lithium inlet pipe. The QT with its lithium outlet pipe have not been taken into account in the FEM model since they are connected with the rest of the structure by means of a bellow that allows mechanical effects on the TA to be decoupled. Also the FDS connecting the EUROFER section of the lithium inlet pipe with the AISI 316L one has not been directly modelled being the two flanges considered as tied. Finally, although the beam duct has not been directly modelled, its thermomechanical effect on the whole TA has been properly simulated.

Concerning the lithium, only the flow domain flowing through the BP and the outlet nozzle has been directly modelled, even though its thermo-mechanical effects on the target system have been properly taken into account.

A 3D mesh consisting of ~500k nodes, connected in ~930k both tetrahedral and hexahedral linear elements (max element size ~1 cm) has been set-up as the best solution to obtain grid-independent results saving calculation time (Fig. 2).

Figure 2. FEM model - Detail of the TA.

<!-- image -->

Temperature-dependent material properties of EUROFER and AISI 316L steels, as well as lithium ones have been implemented in the FEM model.

## 3.2 Loads and boundary conditions

In order to realistically reproduce the DONES steady-state nominal operative scenario a set of thermomechanical interactions, loads and boundary conditions has been applied to the 3D FEM model.

From the thermal point of view two loading scenarios, differing in the beam foot-print size, have been investigated. In Scenario 1, the 5 MW D + beam power has been supposed to interact with a foot-print area of 20x5 cm² (like in IFMIF), while an halved section (10x5 cm²) has been taken into account in case of Scenario 2. Concerning the volumetric density of nuclear heat power deposited by neutrons and γ rays, the spatial distribution calculated in previous studies has been adopted for the TA [10]. A spatial distribution assuming a 1/r² dependence has been extrapolated for the lithium inlet pipe and the support structure, since no data have been calculated for them.

A set of boundary conditions taking into account both radiative and convective heat transfer have been imposed to all un-insulated surfaces of the model (Fig. 3). In particular, radiation towards the inner TC walls at 50 °C and with an emissivity value of 0.3, as well as the natural convection with TC atmosphere (helium @ 50 °C and 5kPa) have been considered, respectively. Moreover, with regards to the BP surfaces facing the HFTM, a pure diffusive heat transfer due to the narrow thickness of their helium gap has been modelled. It is characterized by a sink temperature of 50 °C and a heat transfer coefficient calculated as the helium conductivity (λ) divided by the gap thickness (d). Finally, radiation occurring internally to the TA has been taken into account as well.

Figure 3. Target system un-insulated surfaces.

<!-- image -->

Thermal interactions between components in contact have been simulated imposing a thermal conductance of 2000 W/m² °C [11], whereas the thermal effects of the beam duct have been taken into account adopting for the target chamber surface a contact model characterized by a thermal conductance of 15.8 W/m² °C [11] and a sink temperature depending on the temperature of each node of the flange, purposely calculated by means of a simplified 1D model [12].

Finally, the forced convection occurring between lithium and its wetted surfaces has been simulated imposing a heat transfer coefficient of 34000 W/m² °C [13] and a bulk temperature of 250 °C to lithium inlet pipe and inlet nozzle surfaces. A contact model with the lithium flow domain, characterized by a thermal conductance of 34000 W/m² °C [13], has been imposed to BP and outlet nozzle lithium wetted surfaces.

As far as mechanical interactions are concerned, the contacts between TA and its support structure, considered as dry lubricated, as well as between lithium inlet pipe and the Inlet Interface Shield Plug (IISP) have been simulated by mechanical contact models envisaging Coulombian friction interactions characterized by a uniform friction factor of 0.03 and 0.74, respectively.

Thermal deformations, arising as a consequence of the thermal expansion tensor and the non-uniform thermal fields coming from the two thermal loading scenarios, have been taken into account as well.

A pressure of 5kPa has been applied to all external surfaces of the model, while a non-uniform distribution of internal pressures has been applied onto lithium wetted surfaces, as calculated in [14].

Concerning mechanical restraints, in order to simulate the effect of the pins devoted to avoid gap openings between the TA and its support structure, displacements along Z direction have been prevented to nodes highlighted in red in Fig. 4a. Moreover, in order to properly take into account the mechanical effect of the system devoted to connect the target chamber to the beam duct, displacements along Y and Z directions of the nodes highlighted in yellow and blue in Fig. 4b, respectively, have been prevented.

Figure 4. Target chamber constraints.

<!-- image -->

Finally, all displacements (ux, uy, uz) have been prevented to nodes laying on bottom surfaces of support structure feet and IISP, as well as to nodes of the lithium inlet pipe flange (the red circle in Fig. 1), since they are supposed to be a fixed point.

## 3.3 Results

Un-coupled steady state analyses have been launched in order to assess the thermomechanical behaviour of the DONES TA, equipped with its support structure and lithium inlet pipe, under two possible nominal operating scenarios.

Results obtained from both the thermal analyses have shown that the maximum temperature reached within the structure is always well below the maximum EUROFER allowable temperature of 550 °C (Fig. 5). In particular, the maximum temperature of 339.7 °C is predicted to be reached, for both scenarios, within the TA domain, in correspondence of the lithium channel guides. Concerning the BP (Fig. 6), a higher temperature value is predicted in case of Scenario 2 (~310 °C vs. ~300 °C), probably due to the higher volumetric deposited heat power within the lithium jet. As far as lithium inlet pipe and support structure are concerned, a uniform temperature distribution is foreseen for the former, whereas a maximum temperature value of ~70 °C is predicted for the latter in both the assessed scenarios.

Figure 5. Thermal field - Scenario 1.

<!-- image -->

Figure 6. Thermal field - Detail of the BP.

<!-- image -->

From the mechanical point of view an acceptable stress field is generally predicted within the structure in both scenarios investigated (Fig. 7). Anyway, it has to be highlighted that very high von Mises stress values are calculated, but uniquely in those regions where too conservative boundary conditions have been imposed (i.e. fixed points in correspondence of lithium inlet pipe and IISP flanges). Focussing the attention on the TA, and particularly on its BP, it can be observed that the von Mises stress distribution is quite similar to that obtained in analogous analyses performed on the TA equipped with the removable bayonet-BP, but von Mises stress values result to be significantly lower with respect to those calculated in [8], with maximum stress values of ~160 MPa in Scenario 1 and ~210 MPa achieved in Scenario 2 (Fig. 8).

Figure 7. Von Mises stress field and paths - Scenario 2.

<!-- image -->

Figure 8. Von Mises stress field and paths - Detail of the BP.

<!-- image -->

A stress linearization procedure has been performed along four significantly loaded paths, three located in the middle plane of the BP lithium channel and one in the most loaded bend region of the inlet pipe (Figs. 7-8). The SDC-IC design criteria have been successfully verified in all paths in both scenarios with the exception of the one against the immediate plastic flow localisation in path 3 - Scenario 2 (Tab. 1).

Table 1. Verification of the SDC-IC design criteria.

| Pm/Sm (Pm+Pb)/KeffSm (P+Q)m/Se  Scenario 1  Path 1  0.021  0.015  0.243  Path 2  0.013  0.009  0.759  Path 3  0.021  0.014  0.384  Path 4  0.018  0.015  0.291  Scenario 2  Path 1  0.021  0.014  0.682  Path 2  0.013  0.009  0.743  Path 3  0.021  0.014  1.029  Path 4  0.018  0.015  0.291   |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

As far as displacement field is concerned, obtained results allow to exclude both a significant lithium beam foot-print misalignment and the overlapping between BP and HFTM. Moreover, values coherent with applied loads and boundary conditions are observed, with maximum displacement of ~2 cm reached in the bend region of the lithium inlet pipe, whereas a maximum displacement of ~1.5 mm is predicted for the support structure.

## 4. Conclusions

A campaign of theoretical-numerical analyses has been conducted at the DEIM of the University of Palermo, in close collaboration with C.R. ENEABrasimone, to assess the thermomechanical behaviour of the DONES target system under two possible steady state nominal operating loading scenarios.

Thermal results obtained from two scenarios, differing in beam foot-print area, have shown that the maximum temperature reached within EUROFER is 339.7 °C, well below the limit value of 550 °C. From the mechanical point of view, von Mises stress fields show high values only where conservative boundary conditions have been applied, while values lower than 200 MPa are predicted almost everywhere. Concerning the stress field arising within BP, Scenario 2 seems to be the most demanding, since a maximum stress of ~210 MPa is predicted. This is confirmed also by the SDC-IC design criteria verification, since the criterion against immediate plastic flow localization (the one taking into account thermal stresses) is not fulfilled in the most stressed part of the BP.

## Acknowledgments

This work has been carried out within the framework of the EUROfusion Consortium and has received funding from the Euratom research and training programme 2014-2018 under grant agreement No 633053. The views and opinions expressed herein do not necessarily reflect those of the European Commission.

## References

- [1] P. Garin, M. Sugimoto, Main baseline of IFMIF/EVEDA project, Fus. Eng. Des. 84 (2009) 259-264.
- [2] G. Federici et al., Overview of the design approach and prioritization of R&amp;D activities towards an EU DEMO,. Fus Eng Des 109-111 (2016) 1464-1474.
- [3] P.A. Di Maio et al., On thermo-mechanical issues induced by irradiation swelling inside the back-plate of the IFMIF target assembly, Fus Eng Des 86 (2011) 2597-2601.
- [4] P.A. Di Maio et al., Study of the thermo-mechanical performances of the IFMIF-EVEDA Lithium Test Loop target assembly, Fus Eng Des 87 (2012) 822-827.
- [5] P. Arena et al., On the thermomechanical behavior of the European target assembly design of IFMIF-EVEDA lithium test loop under start-up transient scenarios, Fus Eng Des 88 (2013) 774-777.
- [6] D. Bernardi et al., Start-up and shutdown thermomechanical transient analyses of the IFMIF European lithium target system, Fus Eng Des 89 (2014) 1913-1922.
- [7] D. Bernardi et al. Analysis of the thermomechanical behavior of the IFMIF bayonet target assembly under design loading scenarios, Fus Eng Des 96-97 (2015) 217221.
- [8] G. Bongiovì et al., Thermo-mechanical analysis of irradiation swelling and design optimization of the IFMIF target assembly with bayonet backplate, article in press. doi: http://dx.doi.org/10.1016/j.fusengdes.2017.01.038
- [9] ITER Structural Design Criteria for In-vessel Components (SDC-IC) code, ITER IDM G 74 MA 8 R0.1 2004.
- [10] M. Frisoni et al., Nuclear analysis of the IFMIF European lithium target assembly system, Fus Eng Des 89 (2014) 1959-1963.
- [11] A. Tincani, D., Bernardi, G. Miccichè, Engineering design report of the EVEDA bayonet concept Back-Plate, ENEA Report IM-M-R-002, 04/02/2010.
- [12] P.A. Di Maio et al., Analysis of the thermo-mechanical behaviour of IFMIF target assembly, Report of the research activity of the consulting contract ENEA/2013/20303/UTIS.
- [13] N. Uda et al., Forced Convection Heat Transfer and Temperature Fluctuations of Lithium under Transverse Magnetic Fields, Journal of Nuclear Science and Technology 38 (2001) 936-943.
- [14] D. Bernardi, Target assembly with bayonet backplate - DDD-III\_ED03EU, IFMIF DMS BA\_D\_22W67Z, 2013.