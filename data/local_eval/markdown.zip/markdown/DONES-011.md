<!-- image -->

WPENS-CPR(18) 20346

M Mittwollen et al.

## Maintenance Logistics for IFMIF-DONES

Preprint of Paper to be submitted for publication in Proceeding of 30th Symposium on Fusion Technology (SOFT)

<!-- image -->

This work has been carried out within the framework of the EUROfusion Consortium and has received funding from the Euratom research and training programme 2014-2018 under grant agreement No 633053. The views and opinions expressed herein do not necessarily reflect those of the European Commission.

This document is intended for publication in the open literature. It is made available on the clear understanding that it may not be further circulated and extracts or references may not be published prior to publication of the original when applicable, or without the consent of the Publications Officer, EUROfusion Programme Management Unit, Culham Science Centre, Abingdon, Oxon, OX14 3DB, UK or e-mail Publications.Officer@euro-fusion.org

Enquiries about Copyright and reproduction should be addressed to the Publications Officer, EUROfusion Programme Management Unit, Culham Science Centre, Abingdon, Oxon, OX14 3DB, UK or e-mail Publications.Officer@euro-fusion.org

The contents of this preprint and all other EUROfusion Preprints, Reports and Conference Papers are available to view online free at http://www.euro-fusionscipub.org. This site has full search facilities and e-mail alert options. In the JET specific papers the diagrams contained within the PDFs on this site are hyperlinked

## Maintenance Logistics for IFMIF-DONES

Martin Mittwollen a , Georg Fischer a , Paolo Pagani a , Christoph Kunert a , Jan Oellerich a , Timo Lehmann a , Gioacchino Micciche b , Angel Ibarra c ,

a Karlsruhe Institute of Technology, Institute of Materials Handling and Logistics, Karlsruhe, Germany b ENEA C. R. Brasimone, 40032 Camugnano, Bologna, Italy c CIEMAT, Fusion Technology Division, Madrid, Spain

The DEMO Oriented NEutron Source (DONES) is the dedicated facility for testing and enabling of the qualification for different materials to be utilized in the future fusion reactor DEMO. The neutron irradiation damages not only the material samples to be tested but also impacts the plant hardware in and around the Test Cell which makes regular maintenance mandatory.

In order to keep the plant availability high, a short as possible downtime for maintenance is the overarching goal. Logistics helps enabling this with analyzing the flow of parts and components with special emphasis on the building layout, suggest improvements and optimization potentials. Transportation processes are then modeled and simulated to find an optimum. Taking into account warehouse locations and spare part policy, realization may lead to an optimum Availabilityto-Cost-Ratio from the logistics point of view.

In this paper an overview on the different methods of logistics optimization, the individual approaches and goals as well as on their interdependencies is given. Input and output data, boundary conditions, description of the process of integration complement the paper.

Keywords: IFMIF-DONES, Logistics, Maintenance, Availability, Simulation

## 1. Motivation

Due to partly very high neutron flux (over 1e10n/cm²/s) [1] and Gamma irradiation matter that is used in the TTC (Target and Test Cell) and also in some of the related subsystems as e.g. Accelerator System, Lithium Loop is deeply impacted and damaged in its structural integrity. For that reason, preventive and predictive maintenance activities must be scheduled regularly to avoid critical failures during the neutron irradiation tests.

In order to keep the availability high [2], the overarching goal is a short as possible downtime.

First the Flow of Material has to be carefully analyzed considering all related boundary conditions of parts and components like sizes, shapes, weights and etc. with the aim for an optimum plant layout.

Secondly the transportation processes have to be modelled and subsequently can be simulated in order to find the optimum arrangement of transportation processes.

Thirdly the previous results are taken into account in order to design a maintenance management plan described herein by the two example aspects of finding an optimum warehouse location and optimum spare part policy. The latter helps e.g. avoiding stock-outs by optimizing aspects of safety stock level, reorder points, replenishment processes and etc.

These three major aspects are enlightened herein and concluded in an integrated manner that may lead to an

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

optimum Availability-to-Cost-Ratio from the logistics point of view.

## 2. Flow of Materials and Components

During maintenance phases scores of parts and components have to be replaced, which causes a dense and complex flow of irradiated and non-irradiated materials.

The Flow of Materials (FOM) can be described by means of flow charts. In these flow charts the complete transportation path through DONES from the entrance into the building via the point of installation to the waste storage cell is defined considering each single section from one room to the next room. Together with that, transportation means (e.g. Crane, Ground Based Vehicle (GBV), overhead conveyor) are defined that can be used to transport these components. See figure 1 for an example.

Fig. 1. Example Flow Chart: Beam Dump Cartridge [3].

<!-- image -->

The flow chart also carries information about the radiation status of the component. In the given example, the Beam Dump Cartridge is not irradiated (marked with light blue background color) from the entry point to its installation location in the Beam Transport Room but in case of replacement it has to be handled remotely due to irradiation (marked with red background color). This may have impact on the transport boundaries as shielding and contamination control means are necessary, that will increase the size of the transport unit.

As the building layout is still evolving, the knowledge about the gross size as well as the gross weight is of essential importance in the current design phase. Therefore the size and the movement envelope has to be carefully checked against the size of rooms, corridors, lifts, door openings, and hatches as well as the load capacity of floors, lifts, and etc. At least this has to be done for the biggest and heaviest components as all the other parts will fit for sure in the defined transportation routes. See figure 2 for an example [3].

Fig. 2. Path of Beam Dump Cartridge through building.

<!-- image -->

The size and additional masses of the transportation means, shielding and contamination control casings have also to be considered as well as electrical cables, ventilation channels and etc. installed in the corridors and rooms and decreasing the available height for the transportation unit. The results are collected and handed over to and discussed with the layout planners for DONES for the purpose of building layout optimization. See table 1 for an example register.

Table 1. Example table [4].

| Issue No Description  1 … Door width too small  3 … Aisle width too small  4 … Payload of crane not sufficient  5 … Cornering not possible  9 … Corridor and Cell floor are vertically offset   |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

## 3. Logistics Simulation

The results of the FOM is the input for the modeling and the simulation.

Due to the big amount of parts to be moved during maintenance phases the logistics simulation of the FOM could help identifying bottlenecks and deadlocks due to lack of e.g. corridors, lifts and etc. Especially the lift is one of the major bottleneck as it is used for many parts transportation.

Logistics simulation interconnects the FOM, the plant layout, and the transportation means with all their individual properties. The adjacency matrix provides the paths from origin to destination, and velocity and routing parameters are available from other matrices as well as additional boundaries. The logistics modelling delivers a comprehensive description of all of the transportation processes during maintenance where it is most important but is also capable to model transportation processes for any time wanted (e.g. for preparing / reconditioning outside maintenance phase). Furthermore, possible parallelization of actions can also be integrated in the model. For the purpose of getting information about the behavior of the system in case of failures (e.g. crane has a technical fault and can't operate for a certain time), they can be defined including rescue and recovery scenarios. The flowchart is adapted accordingly. See figure 3 for a generic presentation of the above described.

Fig. 3. Generic presentation of simulation model [5].

<!-- image -->

The logistics simulation delivers then as output information about expected duration of the maintenance phase including details considering transportation times, critical paths i.e. bottlenecks, critical transportation means i.e. in general: lack of resources. See figure 4 for a schematic illustration.

Fig. 4. Logistics simulation course of action [5].

<!-- image -->

But it has to be said clearly: logistics simulation identifies issues worth to be investigated deeply but does not optimize the processes by its own! For that vital brains of experienced engineers are mandatory.

Furthermore, a virtual reality simulation has been performed [6] which illustrates the above identified FOM and makes the layout issues transparent that have to be solved.

## 4. Maintenance Management Plan

In DONES, due to the neutron activation, there are several components, like the Target Assembly (TA) and the Test Modules and those of the accelerator system as well, whose maintenance is considered critical and that can compromise the regular functioning of the plant. At the same time there are a number of standard systems and components that require planned maintenance to guarantee the regular functioning of DONES' systems. So the aim of this work is to establish the Maintenance Management Plan (MMP) for DONES where the maintenance needs, schedule and organization are defined [7]. The establishment of the MMP is a common work of KIT, ENEA, WIGNER, and RACE.

Herein logistics organization tasks considering the spare part storage location and the spare part policy are described as examples. Both of these are crucial for achieving a high availability of the plant.

## 4.1 Spare part storage location

The strategic storage location of the spare parts is fundamental to achieve a smooth and fast maintenance inside the test cell (TC) and the access cell (AC). On one hand, it is preferable to store the spare parts as close as possible to the location where they will be required during the maintenance in order to speed up the maintenance activities. On the other hand, the use of a centralized storage area represents a solution that is more economical and easier to manage [8]. See figure 5 for a schematic overview.

As the trade-off of this is complex, the spare parts location problem has to be deeper analyzed and a decision has to be based on an assessment of different pros and cons [8]. Amongst them the frequency of replacement, the probability of failure, sizes and weights of parts and components are further parameters to be considered.

Fig. 5. Decentralized and centralized storage areas in the DONES facility (top view) [9]

<!-- image -->

Performing a couple of assessment schemes finally result in advantages for installation of an external centralized storage area in the case of IFMIF-DONES, whilst dedicated parts and components could be stored in storage places near to their place of installation [8].

## 4.2 Spare part policy

After having defined well-suited spare parts storage locations according to different criteria the spare part and procurement strategy for each part must be defined in order to assure that the spare parts are always available in the plant warehouses [9].

The mechanism of the replenishment process can be described by the figure 6 below, where the maintenance demand consumes the spare parts in the warehouse and the spare part suppliers feed the warehouse with the ordered number of parts. The orders are issued at the beginning of the replenishment intervals, which, in general, can be different from each other and the correspondent parts will arrive at the DONES warehouse with a certain delivery delay, denoted as delivery lead time. As a result, the ordered quantities must consider the foreseen future demand and/or a properly dimensioned safety stock must be available in the warehouse to avoid high shortage costs [9].

Fig. 6. Spare part supply chain [9]

<!-- image -->

The main goal of the procurement strategy is to minimize the overall operational costs to run the plant. In general, the overall operational costs for the spare parts can be split in 3 main cost items:

- Holding costs, i.e. the costs that the "DONES operation company" incurs to maintain a certain level of inventory (Capital Costs, storage space costs, inventory services costs, inventory risk costs).
- Ordering cost, i.e. the costs that the "DONES operation company" incurs each time a new lot of spare parts is reordered (costs of the ordering process itself and the inbound logistics costs).
- Shortage costs, i.e. the costs that the "DONES operation company" incurs when some spare parts are required but not available in the storage area (so-called "stockout") (maintenance is blocked, unnecessary downtime causes extremely high costs).

Both the maintenance demand and the delivery leadtime are not deterministic and, for that reason, some safety stocks must be additionally planned to avoid the risk of stock-out. In fact, the maintenance demand can further lower the inventory level and a stock-out can occur as shown in figure 7. For that reason, the reorder point must be sufficiently high to compensate the delivery time along with its variability [9].

Fig. 7. Inventory trend in a non-deterministic scenario [9]

<!-- image -->

## 3. Summary and Conclusions

Due to very high irradiation levels during irradiation campaigns regular maintenance is mandatory for IFMIFDONES. Along these maintenance phase scores of parts and components have to be replaced and are causing a complex Flow of Materials (non-irradiated as well as irradiated parts and components). On the other hand a very high availability is required which implies to aim for a short as possible downtime for maintenance purposes.

Thus there is a strong need for sophisticated logistics inside the remote maintenance concepts comprising of i) optimized plant layout, ii) optimized transportation processes, iii) optimized spare part policy in order to get an optimum availability-to-cost-ratio.

First (crucial) parts and components are identified including their properties (size, weights) and their paths through the building are depicted by using Flowcharts. Appropriate transportation means are complemented for every component. Possible impact on the building layout leads to improvements.

After creating a logistics model the FOM is simulated and as results transportation times as well as critical paths, and bottlenecks will initiate optimizations in order to get optimum transportation processes.

Together with a well located spare part storage area and an optimized spare part policy a fluent MMP can be realized and help for high plant availability.

## Acknowledgement

This work has been carried out within the framework of the EUROfusion Consortium and has received funding from the Euratom research and training programme 20142018 under grant agreement No 633053. The views and opinions expressed herein do not necessarily reflect those of the European Commission.

## References

- [1] K. Tian, F. Arbeiter, et.al., The Test cell configuration under IFMIF-DONES condition, Fusion Engineering and Design 124 (2017) 1112-1117.
- [2] A. Ibarra et al., The IFMIF-DONES Project: Preliminary Engineering Design, Nuclear Fusion, doi.org/10.1088/1744326/aad91
- [3] G. Fischer, C. Kunert, et.al., Intermediate report on the flow materials and components, EUROfusion ENS2.4.1.0-T21-05-N1, (2017)
- [4] C. Kunert, M. Mittwollen, et.al, Final Report on the Flow of Materials and Components, EUROfusion, ENS-2.4.1.0T30-04-N1, (2018)
- [5] G. Fischer, M. Mittwollen, Intermediate Report on Logistics Procedures and Maintenance for DONES, EUROfusion ENS-2.4.3.0-T21-07-N1, (2017)
- [6] M. Ascott, Logistics simulation for the Flow of Materials in DONES, EUROfusion ENS-2.4.3.0-T18-02, (2018)
- [7] T. Matyas, M. Mittwollen, et.al., Preliminary Maintenance Management Plan, EUROfusion, EFDA\_D\_2NGGNA, (2017)
- [8] C. Kunert, M. Mittwollen, KIT contribution to Maintenance Management Plan II, EUROfusion ENS2.4.2.0-T21-06-N1, (2018)
- [9] P. Pagani, M. Mittwollen, Maintenance Management Plan I - KIT contribution, EUROfusion ENS-2.4.2.0-T12-04N01, (2016)