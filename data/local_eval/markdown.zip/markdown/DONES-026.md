## BEAM INDUCED FLUORESCENCE MEASUREMENTS OF 100 keV DEUTERONS IN LIPAC ACCELERATOR �

R. Varela y

, A. Guirao, L.M. Martinez, J. Molla, I. Podadera, CIEMAT, Madrid, Spain B. Bolzon, N. Chauvin, CEA, Gif-sur-Yvette, France P. Cara, H. Dzitko, F4E, Garching, Germany J. Knaster, IFMIF-EVEDA, Rokkasho, Japan T. Akagi, R. Ichimiya, Y. Ikeda, M. Sugimoto, QST, Rokkasho, Japan.

## Abstract

The LIPAc accelerator will be a linear CW deuteron accelerator capable of delivering a 9 MeV, 125 mA beam which aims to validate the technology that will be used in the future high power accelerator-driven neutron source, IFMIF. In summer 2017 a campaign of measurements was done during the injector commissioning, in which a Fluorescence Profile Monitor based on an Intensified CID camera (ICID) was used to measure the beam transverse profile at the extraction of the ion source. In this contribution we review the design of the ICID, its performance and discuss the measurements carried out. The performance of ICID monitors for its use in future accelerators will be assessed.

## INTRODUCTION

During the installation and comissioning of LIPAc [1] it was decided to test the performance of an Intensified Charge Injection Device camera in the measurement of the transverse beam profile, substituting the Fluorescence Profile Monitors that were previously installed (normal CID cameras). The main objectives of this measurement campaign, apart from testing the ICID, was the characterization of the extracted beam on the injector [2] most basic configuration, just after the accelerating column, in order to compare the measurements with the results obtained by the simulations. The assessment of the simulated beam is a crucial step for the success of the next commissioning step of the accelerator. In this short campaign of experiments the only component downstream the source were a diagnostic chamber which includes an emittance metter, the FPM, the Doppler Spectrometer and the Beam Dump.

## FLUORESCENCE PROFILE MONITORS

When the charged particle beam travels along the vacuum of the beam pipe it interacts with the atoms and molecules of the low pressure residual gas that have not been pumped out. As a result of the electromagnetic interaction, some of the gas particles end up in an electronic excited state, and return to the ground state emitting photons. The number of emitted photons per unit time is proportional to the gas density and the beam current density, therefore by guiding the emitted photons into a detector we can obtain the transverse beam profile. This fluorescence emission process has a very low cross section, typically two orders of magnitude lower than ionization processes, thus it is only used with high current beams.

� Work partially supported by the Spanish Ministry of Science and Innovation under the project FIS2013-40860-R.

y rodrigo.varela@ciemat.es

The measurements of the vertical transverse profile were done using an Intensified CID Camera [3], seen in Fig. 1. This not a monolithic device, but an assembly of different parts. The front end is a 25 mm fixed focal length with variable aperture, which forms the image in the front plate of the intensifier. The intensifier itself is based on a Micro Channel Plate model BV 2581 BX-V 100 N from Proxitronic (now Proxivision) [4] with a P46 phosphor screen where the intensified image of the beam is formed. A relay lens forms the image onto the final detector, a CID camera 8726DX6 from Thermo Scientific [5] (now Thermo Fisher Scientific). The detector main characteristics are enumerated in Table 1.

Table 1: ICID Characteristics

| MCP Type  V-stack  Photocathode  Bialkali (K2SbCs)  Phosphor screen  P46  MCP max. gain  10 6  Detector sensor size (pixels)  726 x 575  Pixel size  17.3 x 17.3 �m  Calibration constant  0.32 mm/pixel   |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

Figure 1: ICID assembly.

<!-- image -->

The image acquisition is done by capturing the analog output of the camera electronic box with a National Instruments [6] video acquisition card, which is controlled with LabView. The Labview program, created by B. Bolzon (CEA), has many features, including background substraction, automatic profile fitting and average over multiple frames. The data post processing was done at CIEMAT with a python script that includes multiple Region Of Interest se-

doi:10.18429/JACoW-IPAC2018-WEPAF026

lection, automatic profile fitting and automatization routines for data processing.

The whole system was synchronized with the LIPAc timing system. The timing board was designed and built at CIEMAT and is based around a microcontroller with an auxiliary interface board to protect the inputs and generate the required 5V TTL (50 Ohm) signal for the MCP electronics. The microcontroller generates both the gain analog DC signal and the train of pulses with variable period and duty cycle in order to synchronize the gating with the beam arrival.

The other non-interceptive, fluorescence based diagnostic that was installed was a spectrometer [7], which is mainly used to measure the fraction species of the beam, although it is also capable of measuring the beam profile. The apparatus is located at the RF bay, separated from the accelerator, therefore the need of a system to guide the light from the beam. In this case a image fiber was selected. The spectrometer is a iHR320 from Horiba Scientific with a cooled CCD camera. The combination of difraction grating and detector yield a resolution of 0.032 nm. The spectrometer and detector were controlled using a PC with Horiba's propietary software, and the spectral data processing was done using python. In order to separate the lines with Doppler shift the spectrometer is located at an angle of 20º with respect to the beam direction in the horizontal plane.

## OPERATION AND MEASUREMENTS

During operation both devices performed extremely well. The light yield of the residual gas was more than enough to be detected with our ICID without getting close even to the maximum gain and using short integration times. A raw image acquired can be seen in Fig. 2 Due to the proximity to the plasma chamber, the background was measured with the plasma ignited but without beam extracted. One of the main noise sources was the reflection on the chamber walls, which were not darkened in order to minimize the reflection of stray light. Nevertheless, a dark coating would be of little interest in that particular vacuum chamber due to the presence of the emittance scanner [8], which is an Allyson type scanner with tungsten plates facing the beam. Although tungsten is known to be resistant to sputtering, the continuous bombardment with 100 keV ions scrap material and deposit it all around the chamber, making a mirror like deposition that has a very high reflectivity, and even affecting the CF100 viewport where the FPM was installed, requiring a cleaning of the glass to remove the deposited tungsten. In order to minimize the noise associated with the measurement an inherent to the ICID operation, we took multiple pictures of the beam and average them to obtain the final profiles that we proceed to analyze after the measurement campaign.

Due to the minimal injector configuration, with the diagnostics chamber installed after the accelerating column, only a few parameters of the source could be tuned. In order to compare with the simulations we focused on the variation of the profile with respect to the beam current, the intermediate electrode voltage and the repeller electrode voltage. The total accelerating voltage was always kept at 100 keV.

Figure 2: Raw profile acquired by the ICID camera (rotated).

<!-- image -->

## Intermediate Electrode Voltage Variation

The first focusing of the beam just after the extraction from the plasma is done by the Intermediate electrode. During our measurements we chose to vary it from 14 kV to 40 kV, with our range limited by sparks. In Fig. 3 six different profiles are shown at two different currents (total beam current including heavier species). The overall effect in the measured profile of the variation of the electrode voltage is a change in the beam width. However, we observed that the gravity centre of the distribution is slightly shifted at higher voltages.

Figure 3: Beam profile at different intermediate electrode voltages (kV) for 115 mA (top) and 156 mA (bottom) of total extracted current.

<!-- image -->

## Beam Current Variation

LIPAc's nominal beam current is 125 mA, however, in order to compensate the losses in the scrapers, along the

accelerator and the presence of other species (D + 2 and D + 3 ), a total beam current higher than 125 mA is needed. Although the total extracted current is very dependent on the plasma parameters, during this scan we choose to kept the gas flow constant and increase the RF power in order to obtain higher currents. In Fig. 4 the effect of increasing the beam current at two different intermediate electrode voltages is shown. The effect of the higher space charge due to higher current is clearly seen in the profiles, and also the flattening of the beam peak. In order to emphasyze the comparison the profiles were normalized to the unity and their offset substracted, as the increase in the beam current yielded more signal but also an increased background.

Figure 4: Beam profile at different beam currents (mA).

<!-- image -->

## Repeller Electrode Voltage Variation

The function of the repeller electrode is to avoid the entrance of accelerated electrons generated outside the accelerating column. In our measurements we found that, during the scan, a voltage lower than a certain threshold makes the beam unstable and the beam profile appears heavily distorted, with a greatly increased spark rate that disrupt the beam profile due to the falling voltages, thus making impossible the measurement of a correct profile. Another effect of the sparks that we noticed was the noise injection into the ICID electronics, both the MCP electronics and the image acquisition system, with a few episodes of heavy failure that required to reset the electronics. Fortunately, no permanent damage or loss of sensibility was observed.

## Krypton Gas Injection

In order to increase the space charge compensation without increasing the beam losses and the charge exchange neutralization, a small flow of Krypton gas is injected into the ion source. The emittance decrease was observed as it was expected, and a reduction on the beam current ripple was observed at low flow. The effect of the additional gas injection on the profile width was negligible, however the S/N ratio of the image is greatly increased, although the floor level is a little bit increased, as seen in Fig. 5, where the MCP gain voltage and gating signal has been kept constant to see the effect of the increased gas pressure due to Kr. Further data analysis from the aquired profile and the spectroscopic measurements confirmed the linear dependence of the emitted light with respect to the gas pressure.

doi:10.18429/JACoW-IPAC2018-WEPAF026

Figure 5: Beam profile with different Krypton flow injected (sccm).

<!-- image -->

During the Krypton injection some spectroscopic measurements where performed in order to compare the relative intensity between them, and their behaviour with respect to the ion source parameters. In all the cases the line intensity was found to be linear with respect to the beam current and gas pressure, and no dependence on the intermediate electrode or repeller electrode was found. However, during the classification and study of the different lines we could identify and separate the contribution of the 743.58 nm line [9]. The line is quite special compared with the rest as it comes from a transition involving spin flip, requiring the presence of an external electron, therefore single ions such as the Deuteron from the source are not able to excite the transition. This opens up the possibility to use a narrow wavelength filter in front of the spectrometer in order to isolate the transition, see directly (using the spectrograph mode) the contribution of the line to the profile, and then relate it to the electron density inside the beam.

## CONCLUSION

Transverse profile measurements of a 100 keV Deuteron beam have been done and the profile dependence on the ion source parameters have been studied. The performance of the Intensified CID monitor at low energies and high currents has been validated with satisfactory results. Spectroscopic measurements were in accordance with the theory, and the presence of a Krypton line with spin flip opens up the possibility of a direct electron density measurements, which will be studied in the future.

## ACKNOWLEDGEMENTS

Work partially supported by the Spanish Ministry of Science and Innovation under the project FIS2013-40860-R. The author wants to thank CEA, QST and F4E for their help and support.

## REFERENCES

- [1] P. Cara et al., "The Linear IFMIF Prototype Accelerator (LIPAC) design development under the European-Japanese collaboration" , in Proc. 7th Int. Particle Accelerator Conf. (IPAC'16), Busan, Korea, 2016, pp. 985-988,

doi:10.18429/JACoW-IPAC2016-MOPOY057

doi:10.18429/JACoW-IPAC2018-WEPAF026

- [2] R. Gobin et al., "Final design of the IFMIF injector at CEA/Saclay" , in 4th Int. Particle Accelerator Conf. (IPAC'13), Shanghai, China, 2013, paper THPWO003, pp. 3758-3760.
- [3] J. M. Carmona et al., "Measurements of non interceptive fluorescence profile monitor prototypes using 9 MeV deuterons" , Phys. Rev. ST. Accel. Beams, vol. 15, p. 072801, July 2012.
- [4] Proxitronic (now Proxivision),
4. https://www.proxivision.de
- [5] Thermo Fisher Scientific, https://www.thermofisher.com
- [6] National Instruments, https://www.ni.com
- [7] F. Senee et al., "Beam species fraction measurements using Doppler Shift method with Fujikura fiberscope for IFMIF-
8. EVEDA injector" , in Proc. 10th European Workshop on Beam Diagnostics and Instrumentation for Particle Accelerators (DIPAC'11), Hamburg, Germany, 2011, paper TUPD46, pp. 407409.
- [8] B. Bolzon et al., "Beam diagnostics of the LIPAc injector with a focus on the algorithm developed for emittance data analysis of high background including species fraction calculation" , in Proc. 4th Int. Beam Instrumentation Conf. (IBIC'15), Melbourne, Australia, 2015, pp. 313-317, doi:10.18429/JACoW-IBIC2015-TUPB008
- [9] NIST Atomic Spectra Database, https://www.nist.gov/ pml/atomic-spectra-database