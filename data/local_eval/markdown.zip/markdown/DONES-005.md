<!-- image -->

WPENS-CPR(18) 20144

N Holstein et al.

## Development of an electrochemical sensor for hydrogen detection in liquid lithium for IFMIF-DONES

Preprint of Paper to be submitted for publication in Proceeding of 30th Symposium on Fusion Technology (SOFT)

<!-- image -->

This work has been carried out within the framework of the EUROfusion Consortium and has received funding from the Euratom research and training programme 2014-2018 under grant agreement No 633053. The views and opinions expressed herein do not necessarily reflect those of the European Commission.

This document is intended for publication in the open literature. It is made available on the clear understanding that it may not be further circulated and extracts or references may not be published prior to publication of the original when applicable, or without the consent of the Publications Officer, EUROfusion Programme Management Unit, Culham Science Centre, Abingdon, Oxon, OX14 3DB, UK or e-mail Publications.Officer@euro-fusion.org

Enquiries about Copyright and reproduction should be addressed to the Publications Officer, EUROfusion Programme Management Unit, Culham Science Centre, Abingdon, Oxon, OX14 3DB, UK or e-mail Publications.Officer@euro-fusion.org

The contents of this preprint and all other EUROfusion Preprints, Reports and Conference Papers are available to view online free at http://www.euro-fusionscipub.org. This site has full search facilities and e-mail alert options. In the JET specific papers the diagrams contained within the PDFs on this site are hyperlinked

## Development of an electrochemical sensor for hydrogen detection in liquid lithium for IFMIF-DONES

Nils Holstein a , Wolfgang Krauss a , Jürgen Konys a , b Francesco Saverio Nitti b

a Karlsruhe Institute of Technology, Campus Nord, D-76344 Eggenstein-Leopoldshafen, Germany b ENEA, Brasimone, I-40032 Camugnano (BO), Italy

Hydrogen impurities in liquid lithium have a drastic disadvantageous impact on the used structural materials. A problem that might occur also in the planned materials testing facility IFMIF-DONES, where fast neutrons are produced by a reaction of a D-beam with liquid lithium target. Therefore, the operation of such a Li-system requires the control and measurement of impurity concentrations of hydrogen in the Li-melt. Here, especially electrochemistry offers the tool to measure such impurities in real-time conditions. This presentation will outline the development of this H-sensor system and present the physical background of determining non-metallic impurities in molten metals by measuring electrochemical potentials and their transformation by Nernst correlation into concentration values.

Additionally, liquid lithium is a very reactive melt, thus material compatibility is an essential topic for developments of a reliably working sensor together with the essential hydrogen conducting material. Based on these issues a sensor design for measuring hydrogen in liquid lithium was realized under consideration of all physical, chemical and metallurgical aspects, including the successful manufacturing of the sensor in as first prototype and a further first production series. The outlook will deal with measurements of different hydrogen concentrations in lithium.

## 1. Introduction

The structural materials in fusion reactors as e.g. DEMO and future power plants are under strong irradiation and will suffer from radiation damages. The knowledge of the radiation induced degradation of the material properties is essential for plant layout, lifetime and other issues as safety. Such interactions have to be simulated and investigated in a material testing facility, e.g. by the proposed IFMIF-DONES facility. This system will consist of two deuteron accelerator main parts, and a Li loop with an irradiation test cell for material exposure to fast neutrons, produced by the D-Li reaction in the target of fast flowing liquid lithium [1,2] .

Liquid Li is a very reactive melt and interacts with most metals, alloys and non-metallic species at the designed elevated operation temperature of the Li system. Thus, the reliable and safe operation of such a system requires the knowledge of impurities dissolved in the liquid lithium. Especially the measurement and control of the hydrogen content in the liquid metal phase under test and process conditions is absolutely essential [3].

Based on electrochemical online-monitoring systems, in aqueous systems, the measurement of hydrogen species over 14 logarithmic decades is already a wellestablished used feature worldwide everywhere in research and production applications, with typical response-times in the millisecond-sphere. An example is the widely established pH-electrode.

It is the challenge to develop such an electrochemical H-sensor for the use in liquid lithium, applying the same degree of accuracy as it is known from typical pHsondes. Although aqueous and metallic liquids reveal completely different chemical properties, the

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

electrochemical principle itself does not depend on the chemical nature, but indeed needs to be adapted and fitted to the liquid lithium conditions, i.e., the continuous direct online-monitoring of the hydrogen concentration by suitable sensors has to resist the hard chemical conditions permanently and reliably.

## 2. Electrochemistry for sensor design

## 2.1 General electrochemical principles

Whenever two materials (electrically conductive solutions) Mat#1, Mat#2 are in contact via an suitable dielectric interface, an electric voltage, the Electromotoric Force, (EMF) will occur because of the different chemical potentials and the inherent electric standard potentials [4]. The EMF is dependent on the amount i.e. concentration of a dissolved chemical species (in Mat#2). The dissolved species can be anions or cations, e.g., oxygen O 2- or hydrogen H + , if only non-metals are considered. The development of a suitable H-sensor design is orientated on the gained experience with O2concentration measurements in molten heavy liquid metals that demonstrated the successful transfer the technique of electrochemical sensors (ECS), into liquid metals (Fig. 1). The operational performance of that design had been proved by precise online-monitoring of oxygen concentrations over several thousands of hours under process conditions in flowing Pb-Bi [kon04].

The basic design of an electrochemical sensor as shown in Fig.1 contains on one side Mat#1, that provides a known, stable and invariant steady-state concentration c0ref. This acts as the reference electrode system (RES). On the other side, both chemical systems must be separated by a permeable membrane, which will allow diffusion of the investigated species (with the concentration cexp) to be measured against an interface with the RE system. Electrical contacts between the solution with cexp (working electrode) and c0, ref (reference electrode) allow measuring the voltage EMF as result of the two different potentials.

Fig. 1. Basic electrochemical sensor layout for correlating measured EMF and the impurity concentration cexp = [Hdiss]. c0ref is the reference system containing [Hsat].

<!-- image -->

The cexp can be derived from the measured voltage through the Nernst equation which gives a proportional and causal correlation between chemical values (concentration) and is measured by physical values (voltage) [5]; it discloses the term cexp as the only unknown quantity (the amount [Hdiss]), which finally can be numbered by all other known parameters [6].

The development of an ECS for liquid lithium of such a design has to consider the specific properties and reactivity of lithium. The essential divergence in the realization will be defined by the type of the used membrane.

## 2.1 Membrane materials in liquid lithium

For any electrochemical membrane-based system, the permeation of a preferential species into an interface is from decisive meaning for the sensor function, and can (for gaseous species) be subdivided in the following basic steps [7]:

(a) Transfer of the gas molecule to the surface: Van der Waals adsorption; (b) Dissociation of the molecule to single atoms on the surface: chemisorption; (c) dissolution of the atoms into the membrane matrix; (d) diffusion of dissolved species through the membrane; (e) transfer from the solution to the surface; (f)

recombination of atoms to form molecules on surface; (g) resorption of gas into solution.

For generating a charge, which will lead to physical values (electric potential), step c, the dissolution, under ionic dissociation determines the function of voltammetric monitoring systems. Another additional requirement for an EC-interface to generate a potential, not a current, it must also be fabricated from nonconducting material. In general the used sensor parts materials necessarily must fit to the requirements for liquid lithium systems with its corrosivity and its high reactivity due to its low standard potential ELi = -3.1 V [8]. The membrane material must be inert against all chemical, thermic, mechanical stresses and influences.

Unfortunately such a favorable single-material membrane (in EC measurements mostly ceramic solid electrolytes, as it is seen for a molten metal system in Fig.1) does not exist up-to-date for the use in liquid lithium. This means so far, all the functionalities (permeation = conducting for one chemical species + insulation for electric currents + mechanical stability) of such a membrane must be compiled/collocated/merged by several different, but compatible components to forming a whole suitable Li-resistant membrane system i.e. a metallic skin- with strong stability and high permeation rates, and a dielectric matrix that supports the hydrogen permeation. In practice, due to the fact, that also the membrane side versus the reference electrode system RES should be made of the same material, the following sequence of components is proposed leading as first preliminary design step to a double-tube construction for a sensor (Fig. 2), enabling the sensor as single-rod measuring cell:

## Liq. Li // MM // HCE// MM //RES

Only a few materials, mostly from the refractory metal group, are stable enough to withstand the aggressive conditions in liquid lithium. Proceeding studies of permeation studies showed, that for permeation purposes the most attractive materials are Ta, Nb, Fe, but that under the planned DONES conditions most of them would not be stable enough. Suitable literature data for the aspects "membrane stability" + "liquid lithium and impurities" + "permeation properties" is extremely rare, but Niobium seems to be the most suitable membrane material for this kind of application 8

Fig. 2. Single-rod measuring cell:. Preliminary design of the sensor construction (outer diameter 20 mm). The measuring site is the surface of the outer Nb tube. The RE part is the inner Nb-tube filled with Li/LiH, (inner diameter 6 mm).

<!-- image -->

Fig. 3 shows results of the calculations for the permeation through membranes of the metals iron, tantalum and niobium as given in [8 Hol17]. Indeed iron and tantalum have very good permeation properties, but they are significant unstable in liquid lithium. Under the intended conditions, i.e. to be stable in liquid lithium and to have high permeation rates for hydrogen, niobium seems to be the favored membrane material, due to its compromise of high permeability and sufficient stability.

Fig. 3. Permeation studies (H-flux as function of pressure) of the H-membrane materials Nb, Fe, Ta.

<!-- image -->

## 2.2 Electrolyte material selection

The niobium crucibles serve as containers of the ECcell to be filled with two different electrolytes: The space between the inner and outer Niobium membrane has to be filled with a hydrogen conducting electrolyte (HCE), the smaller inner Nb-crucible contains the reference electrolyte system.

## 2.2.1 Hydrogen conductor electrolyte (HCE)

An intense literature research of suitable hydrogen conducting systems lead to calcium chloride (CaCl2) with a small addition (between 5-15 %) of calcium hydride CaH2. For this HCE-purpose, any exact data do not exist and therefore have to be determined for the first time by the investigations here. Independently from the used CaCl2/CaH2 ratio to be finally applied, the CaCl2/CaH2 mixture is always liquid under high conditioning temperatures (800°C), and always a solid electrolyte under DONES conditions. The HCE processing and the electrolyte qualifications are under evaluation actually.

## 2.2.2 Reference electrode system (RES)

The RES is an equimolar mixture of lithium and lithium hydride. Hydrogen does dissolve at 300°C with 3,44 at-% in liquid lithium, in case of supersaturation above this limit solid precipitates of LiH are formed [10] and act as steady-state stable H reservoir. Thus, a Li+LiH mixture (1:1 = 6,66 wt-%, = 33,3 at-% Li) is a strong supersaturated phase and in this respect a suitable stable reference system, i.e. giving a stable electric potential c0ref. It is liquid under DONES conditions. In this case ( detection of hydrogen in liquid lithium), the sensor system is a concentration cell: The dissolved amount of hydrogen cexp can vary between c = 0 and the temperature dependent saturation csat(T). Exceeding this concentration will lead to precipitation of LiH and furthermore aligning the Li-melt Li+H to the RE system Li+LiH; this is in theory the converge to an equilibrium condition (EMF = 0,0 V). Therefore the H-content alone will act as the dominating factor for the evident physical signal of EMF.

## 3. Sensor properties layout

The proposed sensor for H-measurements consists of the main parts:

- Active sensor head
- Support tubings,
- Insulations / spacers,
- Connecting flanges
- Sealings and the electrolyte systems

## 3.1 Sensor materials and mechanical processing

Fig.4 shows the realization of the sensor head with the measuring active units made from niobium crucibles with a wall-thickness of 0.6 mm. They are mounted on steel holder tubes, and the space between inner and outer surface is of approx. 6 mm width, which is similar to the diameter of the RE electrode. The total height of the (outer) Nb- head is 40 mm, planned for a maximal Liimmersion depth of 35 mm.

Several sensors with different total lengths were fabricated to analyze practical experiences of assembling procedures and the performance under experimental conditions e.g. the influence of thermal effects. The shorter type of a sensor has a length of 200 mm and the longer one of 450 mm,

<!-- image -->

Fig. 4. Dimensions and positioning of niobium cell cups. The Nb-crucibles have diameter of 6 and 20 mm, respectively.

The connection of the Nb-cups to the support tubes was done by e-beam welding to guarantee leak tight connections. Due to handling in a glovebox a compact and space-saving design of the electrochemical hydrogen sensor (ECHS) is favorable. Also with respect to of a future use in the DONES -system, it will be advantageous and appropriate to prepare and install the sensor by quick-fit set-ups (easy-to-use system).

Fig.5 shows the two sensor tubes of the ECHS with all auxiliary parts before final conjunction. Care must be taken for the clear and distinct electric insulation between the both tubes. In the present layout this is realized by teflon sealings (cold parts), in the lower sections by ceramic tubes (hot region).

Fig. 5. Inner and outer sensor parts.

<!-- image -->

## 3.2 Completed assembly of the sensor

Fig. 6 represents the appearance of a fully assembled sensor which can be integrated into any standard flange system. The size of the whole sensor is foreseen to range from 200 mm up to 450 mm in length. As mentioned above, the optimal length will be evaluated in practical qualification tests. Due to the electric conductive connection of the Nb-parts with the steel support structure, the voltage (EMF) can directly be measured at the upper ends of the tubes.

Fig. 6. Sensor assembled including electric contacts

<!-- image -->

## 4. Designed test rig and sensor qualification

Fig.7 shows the flow-diagram for the designed test rig to perform the measurements of hydrogen in liquid lithium. Indicated are the main components, e.g., the monitoring system (voltammetry), furnaces and ovens for thermal processing (heating), furthermore the support system (gases, cooling, power supply with physical + chemical connections), which are located outside of the glove-box.

All laboratory investigations are carried out in the glovebox (MB20G, Fa. MBRAUN) to guarantee working under demanding inert conditions; which means not only "water-free" respectively "oxygen-free", but as for liquid lithium applications obligatory, inert in the sense of nitrogen-free. All components are installed in the glove-box system to prevent contamination of the sensitive lithium metal. The oxygen and nitrogen values are clearly below the envisaged concentrations. Melting and handling of lithium was successfully performed and first reaction studies for processing of the electrolytes are under execution.

Fig. 7. Chemicals for the electrolyte systems Hconducting electrolyte and RE

<!-- image -->

## 5. Summary and Outlook

For the first time, an electrochemical sensor for hydrogen impurities in liquid lithium was designed, evaluated and manufactured; foreseen as main part of the online-monitoring of H-concentrations in IFMIFDONES systems. The demanding challenge, to elaborate suitable materials and their combination, which especially allow the use of an EMF sensor under the highly aggressive operating conditions in liquid lithium, was successfully solved.

By calculations of H-permeation through thin metal walls it was revealed that niobium is the most promising candidate material under the given preconditions. This finding allowed manufacturing of all components for a first elaborated series of completed sensor, which are now to be filled with the electroactive chemical materials for first measurements.

Furthermore, the full set-up according to the preliminary design of the online monitoring system was realized, and prepared for measurements with liquid lithium which will enables a comprehensive sensor qualification in the future.

## References

- [1] A. Möslang et.al., The IFMIF test facilities design, Fus. Eng. Des. 81 (2006) 863-871.
- [2] R. Heidinger et.al., Technical analysis of an early fusion neutron source based on the enhancement of the IFMIF/EVEDA accelerator prototype, Fus. Eng. Des. 89 (2014) 2136-2140.
- [3] IFMIF-KEP International Fusion Materials Irradiation Facility key element technology phase report, JAERITech 2003-005, p.223 ff.
- [4] C.H. Hamann, A. Hamnett, W. Vielstich, Electrochemistry, 2nd Completely Revised Edition,
5. ISBN: 978-3-527-31069-2, Wiley-VHC, Weinheim 2007.
- [5] J. Konys et.al., Oxygen measurements in stagnant leadbismuth eutectic using electrochemical sensors, J. Nucl. Mat. 335 (2004) 249-253.
- [6] C.K. Mathews, Electrochemical Sensors, Curr. Sci. 61,/8 (1991), 511-519
- [7] J.K. Gorman, W.R. Nardella Hydrogen permeation through metals, Vacuum, 12 (1962) 19-24
- [8] V.A. Maroni et.al., A review of the chemical, physical, and thermal properties of Lithium that are related to its use in Fusion reactors, Report ANL-8001, Argonne Nat. Lab. 1973.
- [9] N. Holstein, W. Krauss, J. Konys, Preliminary design for the on-line H-electrochemical sensor and of the validation experiments, ENS-5.9.1.0-T7, IDM, 1st Dec 2016.
- [10] C.C. Addison, The chemistry of the liquid alkali metals, John Wiley &amp; Sons 1984.

## Acknowledgement

This work has been carried out within the framework of the EUROfusion Consortium and has received funding from the Euratom research and training programme 2014-2018 under grant agreement No 633053. The views and opinions expressed herein do not necessarily reflect those of the European Commission.