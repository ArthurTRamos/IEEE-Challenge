<!-- image -->

WPENS-CPR(18) 19745

P. Arena et al.

## The Design of the DONES Lithium Target System

Preprint of Paper to be submitted for publication in Proceeding of 30th Symposium on Fusion Technology (SOFT)

<!-- image -->

This work has been carried out within the framework of the EUROfusion Consortium and has received funding from the Euratom research and training programme 2014-2018 under grant agreement No 633053. The views and opinions expressed herein do not necessarily reflect those of the European Commission.

This document is intended for publication in the open literature. It is made available on the clear understanding that it may not be further circulated and extracts or references may not be published prior to publication of the original when applicable, or without the consent of the Publications Officer, EUROfusion Programme Management Unit, Culham Science Centre, Abingdon, Oxon, OX14 3DB, UK or e-mail Publications.Officer@euro-fusion.org

Enquiries about Copyright and reproduction should be addressed to the Publications Officer, EUROfusion Programme Management Unit, Culham Science Centre, Abingdon, Oxon, OX14 3DB, UK or e-mail Publications.Officer@euro-fusion.org

The contents of this preprint and all other EUROfusion Preprints, Reports and Conference Papers are available to view online free at http://www.euro-fusionscipub.org. This site has full search facilities and e-mail alert options. In the JET specific papers the diagrams contained within the PDFs on this site are hyperlinked

## The Design of the DONES Lithium Target System

Pietro Arena a , Davide Bernardi b , Manuela Frisoni c , Pietro Alessandro Di Maio a , Sergej Gordeev d , Gioacchino Miccichè b , Francesco Saverio Nitti b , Angel Ibarra e

a Dipartimento di Energia, Ingegneria dell'Informazione e Modelli Matematici, Università di Palermo, Viale delle Scienze, 90128 Palermo, ITALY

b ENEA C.R. Brasimone, 40032 Camugnano (BO), ITALY

c ENEA C.R. Bologna, 40129 Bologna, ITALY

d Karlsruhe Institute of Technology (KIT), Institute for Neutron Physics and Reactor Technology (INR),

76131 Karlsruhe, GERMANY

e Laboratorio Nacionale de Fusion, CIEMAT, 28040 Madrid, SPAIN

In the framework of the EU fusion roadmap implementing activities, an accelerator-based Li(d,xn) neutron source called DONES (Demo-Oriented early NEutron Source) is being designed within the EUROfusion workpackage WPENS as an essential irradiation facility for testing candidate materials for DEMO reactor and future fusion power plants. DONES will employ a high speed liquid lithium jet struck by a 125 mA, 40 MeV deuteron beam to generate the intense neutron flux used to irradiate the material samples up to the desired level of displacement damage (~10 dpa/fpy for iron in 0.3 l) and He production rates (~10-13 appm He/dpa).

In order to rapidly achieve a sound and stable design, a new configuration of the DONES target system based on the so-called integral concept has been proposed as reference solution in place of the former baseline design that envisaged a target assembly endowed with a replaceable back-plate, being the latter solution not yet fully qualified and thus not readily implementable.

Moreover, following the outcomes of detailed dedicated analyses taking into account different aspects, the design of several components (Quench Tank, Lithium inlet pipe, Vacuum Chamber, etc.) has been changed.

In this paper, a brief description of the current design of the DONES Target System is presented including all the above mentioned aspects, showing the capability of the system to fulfil the prescribed requirements.

Keywords: DONES, IFMIF, Target System, Lithium Target System

## 1. Introduction

The test and qualification of materials to be adopted as structural materials in the ITER and DEMO fusion facilities, as well as in future fusion power plants, is one of the missions of the European fusion roadmap [1] and it will require the availability of an ad-hoc designed neutron source. To this purpose, within the framework of the European R&amp;D activities envisaged by the EUROfusion action [2], it has been foreseen the Work Package (WP) Early Neutron Source (ENS), with the aim of developing the Demo Oriented NEutron Source (DONES) [3].

DONES will be a deuteron-driven neutron source, derived from the International Fusion Irradiation Materials Facility (IFMIF) [4], able to generate an intense neutron flux (~10 18 n·m -2 ·s -1 ) and obtain very high level of damage. This will be achieved by means of the interaction of a 125 mA deuterium ion beam (D + ) at the energy of 40 MeV with a liquid lithium flowing film, through Li(d,xn) reactions. Neutrons so generated have an energy very close to those obtained in a D-T fusion reaction (14.1 MeV). Interactions between the D + beam and the lithium flow will take place within the region of the Target System (TS), in correspondence of the component called Target Assembly (TA).

Recently, the DONES Preliminary Engineering Design Report has been released. The rationale adopted for the design of the different TS components, together

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

with their description, is reported in the following.

## 2. DONES

The achievement of the aforementioned goals and objectives requires the design and construction of several cutting edge devices, which, in DONES, are assembled in four different groups systems, namely Accelerator, Lithium, Test and Conventional Systems (Fig. 1).

The group of the Accelerator Systems is mainly composed of a linear accelerator able to supply the 125 mA ion beam The beam is created by an ion source and then accelerated in different stages up to the energy of 40 MeV by both a radiofrequency system (RFQ) and some superconducting cavities. Finally, a series of magneticoptic devices are in charge of tailor the beam to its rectangular shape. Two profiles are going to be investigated: the nominal 20 x 5 cm² size and the alternative 10 x 5 cm² size. Differently from IFMIF, for DONES only one accelerator is foreseen [3].

The Lithium Systems, mainly composed of two areas: the Li-loop and the TS. The Li-loop is in charge of maintaining a stable lithium flow within the TS by means of an Electro-Magnetic Pump (EMP), removing the 5 MW of heat power generated in the lithium flow by D-Li interactions (Heat Removal System), as well as the control and removal of impurities present in the lithium flow (Impurity control system).

Fig. 1. DONES general view.

<!-- image -->

The TS is where D-Li reactions take place. In fact, the lithium jet flows within the TA and then it is struck by the deuteron beam coming from the accelerator with an angle of 9°. The section of the lithium flow hit by deuterons is called foot-print.

The third group of devices presents in DONES is the Test Systems, mainly composed of the Test Cell (TC) and the Access Cell (AC). The TC, surrounded by concrete walls covered by a steel liner, is the area where both the Test Module housing the specimens to be irradiated and the TA are located. With respect to IFMIF, only the High Flux Test Module (HFTM) has been maintained [3]. The AC is the area over the TC devoted to host all the systems deputed to Remote Handling (RH) operations and assure the shielding towards external environment by proper shielding plugs. Figure 2 reports a view of the TS inside the TC.

Finally, a group of Conventional Systems is in charge of providing services like power supply, air treatment (heating, ventilation and conditioning), service water and gas systems, radioactive waste treatment, control and radiation monitoring systems.

## 3. The Target System

The Target System (TS) is the core of DONES. In fact, it is in this region of the plant that neutrons are generated by means of D-Li stripping reactions. In particular, the TS has to fulfil the following functions:

- producing the adequate neutron flux to properly irradiate the test modules;
- maintaining a stable high-velocity, free surface flow of liquid lithium in front of the D + beam;
- removing the high thermal power deposited within the lithium jet by the D + beam.

The TS is composed of the Target Assembly (TA) with its support, the Quench Tank (QT) with lithium outlet channels, the shielding plugs in correspondence of TC interfaces with adjacent environments, as well as the local control and diagnostic systems.

Fig. 2. The Target System inside the Test Cell.

<!-- image -->

## 3.1 Target Assembly and its support

The TA (Fig. 3) is the whole of components devoted to generate a stable and fast lithium film and housing DLi interactions.

Lithium coming from the EMP is routed within the TS through the 6" inlet pipe, which consists of two sections (a fixed and a removable one) connected by means of a Fast Disconnecting System (FDS) [5]. Then, a Flow Straightener is in charge of reducing the turbulences generating a smoother flow. A double Reducer "Shima" Nozzle (with contraction ratios of 3.2 and 2.5) is finally devoted to shape and accelerate the lithium jet to a thickness of 25 ± 1 mm and a velocity (in correspondence of the foot-print) of 15 m/s. Hence, the 25 mm thick lithium film flows on the curved channel located in correspondence of the Back-plate, where D-Li interactions take place. As far as the Back-plate (BP) is concerned, two concepts have been investigated in the framework of the R&amp;D activities on IFMIF: one foreseeing a removable BP [6]-[10] and one considering a TA with an integrated BP [11],[12]. Despite both systems have shown good thermo-mechanical performances, the BP removable concept is not yet fully qualified from the tightness point of view. Thus, the integral TA concept has been considered as the reference one [13].

Fig. 3. The Target Assembly and its support.

<!-- image -->

The D + ion beam is carried inside the TA through two Beam Ducts (BDs), connecting the accelerator with the TS. Nevertheless in DONES only one BD is active, the other has been maintained for diagnostic purposes and for the possible future upgrade to IFMIF [3]. Each BD is composed of a removable and a fixed section. The removable one is welded to the Vacuum Chamber, which guarantees the vacuum conditions on the lithium film surface, while the fixed section is part of the interface shielding plug. The two sections are connected by means of two FDSs (one for each BD).

A 316 L steel support structure allow the TA to be centered during the mounting phase and sustained during the operational one. Due to the high level of neutronic irradiation predicted in some regions (30 dpa/fpy for the BP [14]), all TA components are made of EUROFER steel, with the exception of the fixed part of the inlet pipe, made of AISI 316 L. For this reason it is foreseen to replace the TA once a year.

## 3.2 Quench Tank and Lithium outlet channels

Once the lithium film interacts with the deuteron beam producing neutrons, the lithium outlet channel routes it towards the Quench Tank (QT), being the two components connected by means of a FDS. The QT (Fig. 4) consists of a stainless steel (316 L) vessel devoted to collect the lithium coming from the BP, homogenize its temperature and reduce its velocity down to a value lower than 5 m/s. With respect to IFMIF design, in order to solve some hydraulic and neutronic issues (e.g. cavitation, radiation streaming), in DONES the QT has been moved inside the TC [15]-[17]. Moreover, in order to increase the lithium jet stability, reduce lithium sloshing and splashing inside the QT and obtain a uniform outlet flow, a new design has been adopted for the QT. This design foresees a squared shape stiffened by some external ribs (Fig. 4). A lithium outlet pipe is finally devoted to connect the QT to the Li-loop and route the lithium towards the Heat Removal System.

Fig. 4. The new layout of the Quench Tank.

<!-- image -->

## 3.3 Shielding plugs

Three penetrations in the TC walls and floor allow the TS to be connected with the accelerator and the Lithium Systems, namely the Beam Duct Interface (BDI), the Inlet and Outlet Interface Shielding Plugs (IISP and OISP).

The BDI will perform the connection between the TC and the Target Interface Room (TIR), assuring at the same time a gas tight seal between the two environments and the TIR shielding from back-scattered neutrons. The two ends of the BDI will be connected to the TA by means of a FDS and to the TIR by means of a claw clamp connector.

Concerning the IISP and OISP, they will connect the TS to the lithium circuit by means of two penetrations in the TC floor. They surround the 6" Li-pipe and they consist of different annular regions in order to shield, insulate and heat the Li-pipe. In both cases, the lower flange of the shielding plugs is connected to a bellow allowing the thermal expansion of the Li-pipe in vertical direction. As far as the TC sides of the shielding plugs are concerned, the OISP is directly connected to the bottom part of the QT, while the IISP is fixed to the TC liner by means of a flange. A view of the IISP is depicted in figure 5.

Fig. 5. Detail of the Inlet Interface Shielding Plug.

<!-- image -->

## 3.4 Local control system and diagnostics

In order to ensure the safe and reliable operation of DONES some control systems and diagnostics have been foreseen to be installed in the TS. In particular, the monitoring of the lithium flow will be performed adopting a radiation proof camera that will be in charge of catching images of the lithium free surface, whereas a laser-based distance meter will measure the lithium flow thickness in correspondence of the beam foot-print. However, the design of both systems is not fully developed and it is currently ongoing.

## 4. Conclusions

Within the framework of the EUROfusion activities, the DONES PEDR has been recently released. The DONES Target System design, developed starting from the presently available IFMIF engineering design, has been successively carried out accordingly to DONES operative conditions. Nevertheless, since the design of some components is not yet finalized, some modifications in the Target System layout and components may occur in the next future.

## Acknowledgments

This work has been carried out within the framework of the EUROfusion Consortium and has received funding from the Euratom research and training programme 2014-2018 under grant agreement No 633053. The views and opinions expressed herein do not necessarily reflect those of the European Commission.

## References

- [1] F. Romanelli, Fusion Electricity, A roadmap to the realisation of fusion energy, European Fusion Development Agreement, EFDA, November 2012, ISBN 978-3-00-0407.
- [2] G. Federici et al., Overview of the design approach and prioritization of R&amp;D activities towards an EU DEMO, Fus Eng Des 109-111 (2016) 1464-1474.
- [3] A. Ibarra et al., A stepped approach from IFMIF/EVEDA toward IFMIF, Fus Sci Tech, 66 (2014) 252-259.
- [4] P. Garin, M. Sugimoto, Main baseline of IFMIF/EVEDA project, Fus Eng Des 84 (2009) 259-264.
- [5] G. Micciché et al., Design manufacturing and testing of a fast disconnecting system for the European target assembly concept of IFMIF, Proceedings of the 2013 IEEE 25 th SOFE, doi: 10.1109/SOFE.2013.6635434.
- [6] P.A. Di Maio et al., Study of the thermo-mechanical performances of the IFMIF-EVEDA Lithium Test Loop target assembly, Fus Eng Des 87 (2012) 822-827.
- [7] P. Arena et al., On the thermomechanical behavior of the European target assembly design of IFMIF-EVEDA lithium test loop under start-up transient scenarios, Fus Eng Des 88 (2013) 774-777.
- [8] D. Bernardi et al., Start-up and shutdown thermomechanical transient analyses of the IFMIF European lithium target system, Fus Eng Des 89 (2014) 1913-1922.
- [9] D. Bernardi et al. Analysis of the thermomechanical behavior of the IFMIF bayonet target assembly under design loading scenarios, Fus Eng Des 96-97 (2015) 217221.
- [10] G. Bongiovì et al., Thermo-mechanical analysis of irradiation swelling and design optimization of the IFMIF target assembly with bayonet backplate, Fus Eng Des 123 (2017) 201-205.
- [11] M. Ida et al., Thermal-stress analysis of IFMIF target backwall made of reduced-activation ferritic steel and austenitic stainless steel, Jour Nuc Mat 386-388 (2009) 987-990.
- [12] K. Watanabe et al., Thermo-structural analysis of integrated back plate in IFMIF/EVEDA liquid lithium target, Fus Eng Des 86 (2011) 2482-2486.
- [13] P. Arena et al., Thermomechanical analysis supporting the preliminary engineering design of DONES target assembly, Fus Eng Des, article in press, https://doi.org/10.1016/j.fusengdes.2018.05.003.
- [14] M. Frisoni et al., Nuclear analysis of the IFMIF European lithium target assembly system, Fus Eng Des 89 (2014) 1959-1963.
- [15] K. Tian et al., The test cell configuration under IFMIFDONES condition, Fus Eng Des, 124 (2017) 1112-1117.
- [16] Y. Qiu et al., Neutronics assessment of different quench tank location options in IFMIF-DONES, Fus Eng Des, 124 (2017) 1059-1062.
- [17] S. Gordeev et al., Analyses of the quench tank configuration for DONES liquid-lithium target system, Fus Eng Des, article in press, https://doi.org/10.1016/j.fusengdes.2018.02.019.