## Abstract

The IFMIF-EVEDA accelerator will be a 9 MeV, 125 mA cw deuteron accelerator prototype for verifying the validity of the accelerator design for IFMIF. A beam stop will be used for the commissioning as well as for the EVEDA accelerator tests. Therefore, this component must be designed to stop 5 MeV and 9 MeV deuteron beams with a maximum power of 1.12 MW.

The first step of the design is the beam-facing material selection. The criteria used for this selection are low neutron production, low activation and good thermomechanical behaviour.

A thermomechanical analysis with ANSYS has been performed for a few materials which show good behaviour from the radiological point of view. The input data are the expected beam shape and divergence at the beam dump entrance produced by the high energy beam line quadrupoles, a conical beam stop shape and the preliminary design of the cooling system.

As a conclusion of the previous studies a conceptual design of the beam stop will be presented.

## INTRODUCTION

The IFMIF-EVEDA accelerator [1] will be a 9 MeV, 125 mA cw deuteron accelerator, identical to the low energy section of one of the IFMIF accelerators, thus including the ion source, the RFQ and the first module of a superconducting (sc) linac based on half wave resonator cavities.

As no target is foreseen for the accelerated beam, a beam dump is required to stop the beam exiting the accelerator during commissioning and accelerator tests.

## SYSTEM REQUIREMENTS AND INPUT DATA FOR THE DESIGN

Commissioning will be performed mainly with H2 + pulsed beams with progressively increasing duty factor and current up to the nominal 125 mA current. Therefore the beam dump must be able to stop deuteron and H2 + continuous and pulsed beams with energies 5 MeV (RFQ output) and 9 MeV (linac output). The maximum beam power is 125 mA x 9 MeV= 1.12 MW. A maximum operation time at full current of around 1 year and an operation time with 5 Hz pulsed beam with 0.1% duty cycle of 2 months has been assumed.

Due to restrictions in the accelerator building size the length of the HEBT line in front of the beam dump plus that of the beam dump itself should not be much larger than 6-7 m. Taking into account the space requirements for diagnostics and shielding, after some preliminary

## IFMIF-EVEDA ACCELERATOR: BEAM DUMP DESIGN

B. Brañas, D. Iglesias, F. Arranz, J. Gómez , C. Oliver, G. Barrera, A. Ibarra CIEMAT, Madrid, Spain

calculations, a beam dump maximum length (without shielding) of 2.5 m was selected.

The beam exiting the accelerator has a rms size around 3 mm. Four quadrupoles open the beam so that it can be absorbed safely at the beam dump [2]. The currents and position of these quadrupoles have been chosen to obtain the highest possible beam size and divergence at the beam dump entrance. The resultant beam shape at this location is shown in Fig.1. It can be observed that this shape departs from a gaussian being less peaked and with less power at the edges.

Figure 1: Beam profile (W/cm2) at the beam dump entrance.

<!-- image -->

As the range of deuterons in different candidate materials (Ni, Cu, W) is of the order of hundreds of microns, it is not possible to install a vacuum window previous to the beam dump. Therefore the beam dump must operate in vacuum.

The beam dump and its surroundings will become activated due to neutron irradiation coming from deuteron reactions with the beam dump material and the beam facing material itself will be highly activated by the neutrons and the impinging deuterons. A very important factor influencing the design is the radiation dose during beam off phases in the accelerator vault. Man-access to the vault is necessary for maintenance of the different accelerator components and therefore the right choice of beam facing material and beam dump geometry must be made to minimize the radiation levels. This paper concentrates on the thermomechanical aspects of the beam dump while the radiological aspects are treated elsewhere [3].

## BEAM FACING WALL GEOMETRY

The beam shape along with the geometry of the facing wall determines the power deposition. As will be shown in next sections, both the thermal stress and temperature of the internal wall are directly proportional to the value of the power density in each point of the material.

The power deposited at the beam dump surface has been calculated using the particle position and velocity distributions at the beam dump entrance from the beam dynamics simulations [2]. The deuteron backscattering at the beam dump surface has been taken into account. This effect changes the power density profile obtained specially near the cone vertex, where the area is smaller. For simplicity, as the beam is almost axisymmetric, for revolution geometries the mean value in the transversal section is shown. The peak value shall be slightly higher

## Revolution Geometries

Figure 2 shows the power density deposited on a conical beam dump (green curve lower plot). It can be observed that it is very low in the first part of the cone while it reaches values up to 2.50 MW/m 2 . A more uniform power deposition with lower peak power density values can be obtained for revolution surfaces in which the angle with respect to the beam changes along the beam dump length (red curves in Fig. 2).

<!-- image -->

Figure 2: Mean Power density deposited at a conical beam dump (green lines) and at a beam dump with the same length and minimum peak power density (red lines).

<!-- image -->

## Symmetrical Plates Geometry

The plate geometry offers some advantage of simplicity in manufacturing although has other drawbacks like appearance of transverse temperature gradients (figure 3) and the need of supporting the plates inside the vacuum chamber. The peak value of the power density in this geometry is similar to the one obtained for the conical shape.

Figure 3: Power deposition in plates beam dump.

<!-- image -->

## THERMO-MECHANICAL ANALYSIS

From all the operation modes, the nominal full current is taken as the reference as it produces the highest temperatures and stresses. Therefore the evaluation of the design alternatives can performed by simple linear static analysis. Anyway, further verifications must be performed to check that buckling, dynamic and fatigue effects do not impose higher requirements to the beam dump design.

The loads on the beam dump, in order of uncertainty are the following:

- Beam power deposition produces thermal stress due to thermal gradients and internal hyperstaticity.
- Coolant pressure effects produce mechanical stress
- Gravity acceleration bends the beam dump between support points.

The study of the stress and strain of the different geometries and materials was performed using a finite element model, linear formulation and temperature dependent material properties. When both the geometry and the loads are axisymmetric, the elements used are 2D also axisymmetric. For the plate geometry and the analysis of gravity effects on any geometry, shell elements are used.

The analysis performed for the conical and modified geometries of Fig. 2 shows that although the peak power density is lower in the last case, the maximum thermal stress is higher. The reason is that in the modified geometry a very high axial gradient appears near the base of the cone (z=0). Giving rise to high bending stresses (figure 4) similar to those that would appear in a hollow circular plate heated in the middle.

Figure 4: Von Mises stress at the base of the optimized geometry. Section view, beam direction vertical upwards

<!-- image -->

A similar effect occurs on the plate geometry. The transversal thermal gradient on a flat surface produces a bending effect along its axial normal plane (Figure 5) giving stress values higher than those obtained in a conical geometry. These stresses can be greatly reduced by using several smaller plates which can expand freely covering the whole beam surface.

Figure 5: Von Mises stress for plate geometry.

<!-- image -->

Comparing different materials, as the thermal stresses are produced by a constrained thermal expansion, the lower the expansion and the resistance to that expansion, the lower the stresses generated by the power deposition. So, for a given geometry, the stresses are approximately proportional to the parameter K/(Eα), where K is the conductivity, E is the elastic (Young) modulus and α is the thermal expansion coefficient. As can be seen in Table 1, copper is the best among the candidate materials.

Structural analysis have been undertaken, validating copper as the material with the best performance for all the load combinations. Fig. 6 shows the total stresses for a conical beam dump with 15 cm diameter and 2.5 length and 3.5 mm thinkness.

Table 1: Properties of candidate beam facing materials

| E (GPa) α (10  -6 K -1 ) K(W/mK) K/Eα/(a.u.)  Ni 200 204 13.4  90  0.033  W 398 3.93  166  0.106  Ta  186 6.3  57.5  0.05  Cu 101 115 17.7  386  0.192  Al 1050 69  25.5  227  0.129   |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

Figure 6: Total Tresca stress intensity for actual design.

<!-- image -->

The thickness has been chosen considering the thermal stresses (which are almost proportional to this parameter) and the pressure stresses which have the opposite dependence.

## COOLING SYSTEM

The analysis performed shows that a cooling system based on liquid water flowing at high velocity (around 5 m/s) is appropriate for this application. As the temperature of the material at the coolant side can reach 130-140 ºC the water must be slightly pressurized (around 6 bar) to avoid local boiling.

Two different schemes for the flow direction are being considered: axial flow with annular cross section (in a similar manner to that of the LEDA or IPHI beam dumps [4]) and helical flow with a constant area for the flow passage. The high velocity is needed specially at the regions of higher power deposition where a large heat transmission coefficient between surface and coolant is required to limit the surface temperature and consequently the required water pressure.

## REFERENCES

- [1] A. Mosnier et al., these proceedings
- [2] C. Oliver et al., these proceedings
- [3] D. López et al., these proceedings
- [4] T.H. Van Hagan et al. LINAC Conference Proceedings 1998