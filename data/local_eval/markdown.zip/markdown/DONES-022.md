doi:10.18429/JACoW-IPAC2022-THPOST035

## STATUS OF THE ENGINEERING DESIGN OF THE IFMIF-DONES HIGH ENERGY BEAM TRANSPORT LINE AND BEAM DUMP SYSTEM*

D. Sánchez-Herranz † , University of Granada, Granada, Spain

O. Nomen, M. Sanmartí, B. K. Singh, IREC, Sant Adrià de Besós, Spain F. Arranz, I. Podadera, C. Oliver, CIEMAT, Madrid, Spain P. Cara, Fusion for Energy BA/IFMIF, Garching, Germany V. Hauer, KIT, Eggenstein-Leopoldshafen, Germany F. Ogando, UNED, Madrid, Spain

The IFMIF-DONES High Energy Beam Transport Line and Beam Dump System (HEBT &amp; BD) design has been developed considering as main requirements the ones shown in Table 1.

Table 1: Requirements HEBT&amp;BD System

| Requirement  Value  Particle Type  D+  Beam energy  40 MeV  Nom. beam peak current  125 mA  Nom. duty cycle  100%  Nom. transmission ratio  &gt;99.8%  Beam dynamics length  48.8 m  Achromatic bending  9º  Beam footprint at target  20x5cm 2 [10x5cm 2 ]  Beam Dump peak power  5 MW  Beam Dump avg. power  50 kW  RMS beam size BD cone  ≈ 40 mm  Divergence at BD cone  14-16 mrad  Off axis  &lt;3 mm  Pressure at SRF Linac  &lt;5·10 -6 Pa  Pressure at Li target  &gt;10 -2 Pa   |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

A preliminary design of the HEBT system was initiated following the requirements specified [5], establishing a first layout. It shall provide a continuous wave (CW) deuteron beam with adjustable rectangular footprint. Due to the development of the facility and its systems associated, multiple aspects have been either modified or developed for the HEBT main or beam dump transport lines. Next sections are devoted to give an overview of the current design and configuration updates. Main points of the HEBT engineering design which have been detailed from the previous preliminary design correspond to: Detailed design of magnets, recalculation of vacuum subsystem and adaptation to aluminium of beam facing components along the transport line, considering limiting factors for beam pipes the maximum outer diameter given by fixed aperture of magnets and minimum one due to beam envelope obtained in simulations. An important consequence of this material change to aluminium is the necessity to implement new type of flange connections, which is currently under-study. Figure 1 on the following page depicts configuration of all integrated components along the HEBT system.

Abstract

IFMIF-DONES plant [1] (International Fusion Materials Irradiation Facility - DEMO Oriented Neutron Source) is currently being developed under the framework of a work package of the EUROfusion Consortium. It will be a facility located at the south of Spain in Granada. Its objective and main goal is the testing and qualification of fusion materials by the generation of a neutron flux with a broad energy distribution covering the typical neutron spectrum of a (D-T) fusion reactor. This is achieved by the Li(d,xn) nuclear reactions occurring in a liquid lithium target where a 40 MeV at 125 mA deuteron beam with a variable beam footprint between 200 mm x 50 mm and 100 mm x 50mm collides. The Accelerator Systems is in charge of providing such high energy deuterons to produce the required neutron flux. The High Energy Beam Transport line (HEBT) is the last subsystem of the IFMIF-DONES accelerator, and its main functions are to guide the deuteron beam towards the liquid lithium target and to shape it with the required rectangular reference beam footprints. The HEBT system includes a Beam Dump devoted to stop the beam during commissioning and start-up phases.

The present work details the present status of the HEBT engineering design, including beam dynamics, vacuum configuration, radioprotection, beam diagnostics devices and remote handling analyses performed detailing the layout and integration of required components throughout the beamline.

## INTRODUCTION

The linear accelerator for the IFMIF-DONES facility [2] will produce a continuous wave deuteron beam of 125 mA, accelerated up to 40 MeV that will impinge on a liquid lithium target producing a fusion-like neutron flux for the assessment of materials damage in future fusion reactors. IFMIF-DONES linear accelerator is divided in seven subsystems: Injector, Radio Frequency Quadrupole, Medium Energy Beam Transport line, Superconducting RF LINAC, High Energy Beam Transport line, Radio Frequency Power and Accelerator Systems Ancillaries.

IFMIF-DONES accelerator is based on the design of LIPAC [3, 4], currently undergoing its commissioning phase. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

This work has been carried out within the framework of the EUROfusion Consortium, funded by the European Union via the Euratom Research and Training Programme (Grant Agreement No 101052200 - EUROfusion). Views and opinions expressed are however those of the author(s) only and do not necessarily reflect those of the European Union or the European Commission. Neither the European Union nor the European Commission can be held responsible for them. † dsherranz@ugr.es

<!-- image -->

Figure 1: General distribution of HEBT mainline and Beam Dump Transport Line.

<!-- image -->

## HEBT LAYOUT AND DESIGN

## Beam Dynamics Characteristics

HEBT section has been designed to handle a 40 MeV beam at 125 mA coming out from the SRF Linac, transporting it to the lithium target securely and with the beam size and characteristics required by the project to optimize the irradiation field [6]. Beam dynamics optimisation has been performed modifying its original layout with the aim to guarantee enough space for components integration, adapt the main line and beam dump transport line to building modifications and increase space around individual steerers to minimize the magnetic field aberrations. Beam sizes present vary from apertures of 20 mm at the HEBT entrance up to 200 mm where beam enters the target area.

## Magnets and Steerers

Transportation and shaping of the beam throughout HEBT line is done by means of multiple magnets. Twentyfour quadrupoles grouped in four types (QD-A, QD-B, QD-C and QD-D) have been identified to keep the beam pipe aperture as small as possible. Two types of dipoles are also needed for the beam bending. The first type, namely DP-A type, covering the D1 and D2 dipoles in the main HEBT line, will have a small bending angle of 4.5⁰. The DP-B type is used for D3 in the BDTL line having a larger bending angle of 30⁰.

Non-linear magnets have been designed according to the nominal tuning requirements. A couple of octupoles OP-A and OP-B will be implemented, each of them with different characteristics, whereas one type DDP is expected for the two dodecapoles needed.

Horizontal and vertical dipolar correctors are needed to steer beam trajectory deviations appearing due to upstream elements or magnets misalignments and field errors.

Twenty pairs of correctors with an integrated field of 40 G.m are recommended, all grouped in three types (ST-A, ST-B and ST-C) depending on aperture of section where they are located.

A margin of 5 mm between the beam-stay-clear radius that must be exclusively reserved for the beam to travel avoiding any losses and magnets' mechanical aperture has been considered to properly accommodate vacuum pipe thicknesses and alignment tolerances. Table 2 presents type of magnets and their main characteristics:

Table 2: Magnets Characteristics

| Magnet  type  Aperture  [mm]  Pole field  [T]  Units  QD-A  55  0,550  9  QD-B  85  0,595  10  QD-C  130  0,390  2  QD-D  70  1,050  3  DP-A  65  0,410  2  DP-B  55  0,850  1  DDP  65  0,360  2  OP-A  65  0,400  1  OP-B  85  0,360  1   |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

## Diagnostics Devices

Given the very high current and power to be transported by IFMIF-DONES high energy beam transport line, beam diagnostics devices are of paramount importance to properly tune, characterize and monitor the accelerated beam. Multiple types of diagnostics have been integrated all along the HEBT, each of them with different functionality and characteristics [7].

Twenty-two Beam Position Monitors (BPMs) are necessary to detect possible beam deviation from the central axis

and correct the dipolar errors created by misalignments of the different accelerator elements, mainly non-linear magnets.

To measure beam current in both CW and pulsed modes, sixteen current transformers are placed at multiple locations. Three types of current monitors will be installed: ACCT, used for pulsed mode, DCCT for CW and CWCT capable of measure in both operation modes.

Beam Profile Monitors are required for both magnets tuning and beam characterization. Due to the limited space, a minimum set of fourteen have been considered. A combination of non-interceptive and interceptive instruments has been implemented by means of Beam Profile Chambers (BPCs), compromising a vacuum chamber where a pair of Fluorescence Profile Monitors (FPMs) plus a single Secondary Emission Monitor (SEM Grid) are installed. These BPCs shall be as close as possible to the non-linear magnets for an optimum octupole and dodecapole tuning to sustain proper beam shaping at downstream sections where no magnetics elements are present.

Last type of diagnostic devices implemented are sixteen Beam Loss Monitors (BLoMs), which are primary diagnostics for beam tuning and equipment protection via measurement of the amount and location of beam losses along the beam transport line. LIPAc Ionization chambers type is the present choice for those monitors.

## Vacuum System Modelling

Vacuum system of HEBT has been recalculated, leading to modification on pump types integrated and pumping speeds. These changes are required due to, first, beam pipe material replacing stainless steel grade 316L for aluminium 6061 which implies changes on thermal outgassing rates, secondly and Argon injection inside Target Vacuum Chamber (TVC) required to prevent boiling or significant vaporization from the lithium surface ensuring a total pressure in TVC above 10 -2 Pa. Two cases for argon injection during nominal beam operation were simulated with slightly different pump speeds and active pumping points. In both cases, argon flow rate was kept constant at a value of 5ˑ10 - 4 Pa. m 3 /s. Figure 2 shows HEBT and BD pressure profiles for argon injection in both alternatives.

Figure 2: Pressure profile along HEBT (Case Ar1 + 2).

<!-- image -->

As it can be seen, in both cases the pressure falls far below the maximum permitted pressure of 5ˑ10 -6 Pa at the SRF Linac side, it also stays higher than 10 -2 Pa on TVC side. Thus, either of the two pump configurations results obtained will be suitable. New pumping configuration listing pump types and speeds is listed in Table 3.

Table 3: HEBT and BD Pumping Configuration

| Point  Type  Pump  speed  [Ar1, l/s]  Pump  speed  [Ar2, l/s]  P25 NEG/SIP  0  240  P26  CP  1000  1100  P27  TMP  1100  1100  P28  TMP  1100  1100  P29  TMP  1100  1100  P30  TMP  1100  1100  P31  TMP  1100  1100   |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

## RH and Radioprotection

HEBT spans along two different maintenance areas, established based on radiation dose rates calculated to workers. Most of it lays inside the first area where limited access is allowed for hands-on operations. The second area is named Target Interface Room (TIR), where maintenance is required to be carried out by remote handling [8]. To meet manual servicing inside the first area, it has been identified that the use of stainless steel as beam facing material leads to production of Co-56 with T1/2 =77 days, ruling out any possibility of hands-on maintenance during beam stop period, hence material for beam facing components was changed to aluminium. Activated devices, scraper and beam dump cartridge must be taken out from their radiation protection shieldings by remote handling means [9]. Once removed, vacuum pumps, diagnostics devices and other components can be handled manually.

## CONCLUSION

Engineering design of HEBT is achieving a mature stage and adapted to requirements and changes that arise as IFMIF-DONES facility overall design evolves.

Current configuration explained, portrays progress made from the previous preliminary stage towards a more detailed system in which mechanical and functional aspects of the components have been further specified. Magnets' characteristics are now defined, and their mechanical implementation performed, vacuum system has been successfully adapted to the required argon injection modification together with subsequent integration of newly required vacuum pumps, and finally adaptation of the beam line components material to aluminium has been identified and is presently being applied, paying attention to constraints such as, beam pipe thickness increment and flange type.

Future steps and required updates of the HEBT will be intrinsically and greatly linked to LIPAc results currently being obtained.

## REFERENCES

- [1] W. Królas et al., "The IFMIF-DONES fusion oriented neutron source: evolution of the design", Nucl. Fus. vol. 61, 2021.
- [2] I. Podadera et al., "The Accelerator System of IFMIFDONES Multi-MW Facility", in Proc. IPAC'21, Campinas, Brazil, May 2021, pp.1910-1913. doi:10.18429/JACoWIPAC2021-TUPAB211
- [3] H. Dzitko et al., "Status and future developments of the Linear IFMIF Prototype Accelerator (LIPAc)", Fusion Eng. Des., vol. 168, pp.112621, 2021.
- [4] P. Cara et al., "IFMIF/EVEDA Project: Achievements and Outlooks beyond 2020", in Proc. FEC'20 TECH/4, p. 650, 2021.
- [5] O. Nomen et al., "Preliminary design of the HEBT of IFMIF DONES", Fusion Eng. Des. vol. 153, p. 111515, 2020.
- [6] C. Oliver et al., "Impact of the Magnet Alignment and Field Errors on the Output Uniform Beam at the DONES HEBT Line", in Proc. IPAC'21, Campinas, Brazil, May 2021, pp. 3251-3253. doi:10.18429/JACoW-IPAC2021WEPAB259
- [7] I. Podadera et al., "Beam diagnostics for the Multi-MW High Energy Beam Transport Line of DONES", in Proc. IBIC'19, Malmö, Sweden, Sep. 2018, pp. 200-204. doi:10.18429/JACoW-IBIC2019-MOPP042
- [8] D. Sánchez-Herranz et al., "Design of the HEBT components inside TIR room of the IFMIF DONES facility", Fusion Eng. Des., vol. 168, pp. 112636, 2021.
- [9] S. Coloma et al., "Remote handling maintenance of beam dump in IFMIF-DONES", Fusion Eng. Des. vol. 165, p. 112216, 2020.