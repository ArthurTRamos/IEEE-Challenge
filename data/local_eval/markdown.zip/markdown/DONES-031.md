<!-- image -->

## PAPER · OPEN ACCESS

## Status of DONES neutronics, source terms analyses and radiation protections

To cite this article: Y. Qiu et al 2025 Nucl. Fusion 65 122013

View the article online for updates and enhancements.

<!-- image -->

<!-- image -->

<!-- image -->

## You may also like

- [Programme management in IFMIFDONES -](/article/10.1088/1741-4326/adef69)

M. García, A. Díez, A. Zsákai et al.

- The IFMIF-DONES Irradiation Modules F. Arbeiter, U. Wicek, B. Brañas et al. -
- [The IFMIF-DONES control architecture: the state-of-the-art design of central and local control systems and communication networks -](/article/10.1088/1741-4326/adc1dd)
- M. Cappelli, F. Ambi, E. Botta et al.

Nucl. Fusion 65 (2025) 122013 (37pp)

[https://doi.org/10.1088/1741-4326/addeda](https://doi.org/10.1088/1741-4326/addeda)

## Status of DONES neutronics, source terms analyses and radiation protections

```
Y. Qiu 1,∗ , T. Berry 2 , I. ´Alvarez 12 , K. Ambroˇzicˇ 4 , B. Bie´nkowska 5 , H. Chohan 2 , A. ˇCufar 4 , D. Dworak 6 , B. Kos 4 , A.J. Lopez-Revelles 7 , V. Lopez 7 , F. Mota 8 , M.J. Martinez-Echevarria 3 , T. Piotrowski 9 , A. Serikov 1 , G. Stankunas 10 , A. Tidikas 10 , L. Taling 2 , G. Tracz 6 , U. Wia˛cek 6 , G. ˇZerovnik 4 , M. Ansorge 11 , M. Anguiano 12 , T. Dezsi 13 , J. García 1,3 , D. Jimenez-Rey 8 , M. Ke˛pniak 9 , E. Mendoza 8 , J. Malec 4 , F. Ogando 7 , J. Park 1 , J. Martínez-Serrano 14 and the EUROfusion WPENS Team a
```

1 Karlsruhe Institute of Technology, Karlsruhe, Germany

2 UKAEA, Culham Science Centre, Abingdon OX14 3DB, United Kingdom of Great Britain and Northern Ireland

3 Universidad de Granada, C/Gran Vía de Colón 48, 18010 Granada, Spain

4 Reactor Physics Department, Joˇzef Stefan Institute, Jamova Cesta 39, SI-1000 Ljubljana, Slovenia

5 Institute of Plasma Physics and Laser Microfusion (IPPLM), 23 Hery Str., 01-497 Warsaw, Poland

6 Institute of Nuclear Physics Polish Academy of Sciences (IFJ PAN), ul. Radzikowskiego 152, 31-342 Cracow, Poland

7 Universidad Nacional de Educación a Distancia (UNED), Madrid, Spain

8 Centro de Investigaciones Energética Medioambientales y Tecnológicas (CIEMAT), Madrid, Spain

9 Warsaw University of Technology, Al. Armii Ludowej 16, 00-637 Warsaw, Poland

10 Lithuanian Energy Institute, Laboratory of Nuclear Installation Safety, Breslaujos st. 3, Kaunas, Lithuania

11 Nuclear Physics Institute of the Czech Academy of Sciences, 250 68 ˇReˇz, Czech Republic

12 Department of Atomic, Molecular and Nuclear Physics, University of Granada, UGR, Granada, Spain

13 C3D Engineering Ltd, 1106 Budapest, Hungary

14 Universidad de Málaga, Málaga, Spain

[E-mail: yuefeng.qiu@kit.edu](mailto:yuefeng.qiu@kit.edu)

Received 15 November 2024, revised 8 May 2025 Accepted for publication 30 May 2025 Published 30 September 2025

## Abstract

International Fusion Materials Irradiation Facility-Demo Oriented NEutron Source is an accelerator-based neutron irradiation facility for the study and qualification of materials used for the design, licensing, and reliable operation of fusion reactors such as DEMO. Neutron serves as a critical tool for irradiating and testing material samples, while also posing significant radiation safety considerations. This work provides a comprehensive overview of neutronics studies and nuclear analyses, beginning with the accelerator where neutron and gamma are

a See the Appendix in Ibarra et al (https://doi.org/10.1088/1741-4326/adb864) for the EUROfusion WPENS Team.

∗ Author to whom any correspondence should be addressed.

<!-- image -->

Original content from this work may be used under the terms of the Creative Commons Attribution 4.0 licence. Any

further distribution of this work must maintain attribution to the author(s) and the title of the work, journal citation and DOI.

<!-- image -->

generated from deuteron losses and deposition, progressing to the test systems where most d-Li neutrons are produced, and then to the systems and areas where the radiation is covered. Key aspects analysed include neutron-induced material damage and gas production, nuclear heating, radiation doses during both beam-on and beam-off conditions, activation of structural components and liquids (such as lithium and water), and the assessment and optimization of radiation shielding across the accelerator systems, target systems, lithium systems, and building and plant systems. Additionally, this article highlights recent advancements in neutronics simulation tools, evaluations of nuclear data, and experimental efforts, all of which provide essential foundations for nuclear analyses in DONES.

Keywords: DONES, neutronics, radiation, dose, Monte Carlo

(Some figures may appear in colour only in the online journal)

## 1. Introduction

IFMIF-DONES (International Fusion Materials Irradiation Facility-Demo Oriented NEutron Source, abbreviated as DONES) is a powerful neutron irradiation facility for the study and qualification of materials planned as part of the European fusion roadmap [1]. It is designed for studying the properties of materials under strong irradiation in a neutron field similar to the one in the first wall of a fusion reactor. Understanding the materials degradation and property changes in the reactor's operational lifetime is a key issue in the design, licensing, and reliable operation of fusion reactors such as DEMO.

To meet the challenging needs, DONES will produce fusion-like neutrons using a 125 mA deuteron beam, accelerated up to 40 MeV and shaped to have a quasi-rectangular footprint that will impinge on a 25 mm thick liquid-lithium curtain flowing at 15 m s-1 speed. The stripping reactions Li(d, xn) will generate intensive neutrons with energies up to 55 MeV, total yield of 6.8×10 16 n/s, and peak fluxes of 10 15 n/cm 2 /s, and used for continuous material irradiation that will interact with the materials samples located in the test modules immediately behind the lithium target. The neutron spectrum from the target has a broad peak around 14 MeV, which resembles the fusion reactor irradiation environment, with similar primary knock-on atom spectra and gas production being observed in the fusion reactor first wall. The characteristics of the neutron produced from d-Li reactions, the performance of the DONES facility in irradiating fusion structural materials, and the radiation protection have been studied in the past decades [2-5].

Neutrons, on one hand, are used as tools for material testing in DONES. To evaluate the performance of DONES in material irradiations, high-quality nuclear data, nuclear simulation methodologies, and nuclear analysis are required. First is accurate modelling of d-Li interaction at the target, where the neutron production and emission. Secondly, the simulation models of the test systems (TS) are regularly updated on the actual design, in order to provide the best estimation of the irradiation on the materials samples. On these basis, irradiation characteristics i.e. damage doses, and gas productions as key data are computed for answering the performance of the neutron source, which is a key mission of DONES neutronics.

On the other hand, neutrons and gamma are hazardous source terms of radiation which require active protection. In this regard, reliable nuclear analyses are essential for design optimizations and safety compliance of DONES systems. The neutrons and gammas produced from the accelerator and the target impose strong nuclear heat power on the vicinity structures that need active cooling with water and helium gas. The estimations of sources, and radiation protections of prompt neutrons and gammas, as well as the decay gammas from the activated structures, lithium, water and air, are another main challenge to be addressed in DONES nuclear analyses.

A brief summary of the DONES systems and related neutronics activities is given, with the help of figure 1 which provides a schematic overview of the entire DONES plant configuration.

The deuteron ion beam is produced from the injector with an initial energy of 100 keV, which will be accelerated through the radio frequency quadrupole (RFQ) to 5 MeV, passing through the Medium Energy Beam Transport (MEBT), then further accelerated through the Superconducting Radio Frequency accelerator (SRF) to an energy of 40 MeV, and at the end transported by the High Energy Beam Transport (HEBT) line to the Li target. In the early commissioning phase, deuterons will be deposited in beam dumps (BDs) instead of the target, namely the Lower Power Beam Dump (LPBD) and the High Power Beam Dump (HPBD). The contribution of beam losses along the accelerator is also important, including both losses along the beam line and controlled losses in scrapers and collimators. Here the deuterons interact with materials such as copper, CuCrZr alloy, stainless steel (SS), aluminium, and niobium. When the beam reaches the target systems, the deuteron flux on the target generates intense radiation sources. Neutrons are produced in the Li curtain formed in the Target Assembly (TA), where the Li and its impurities are activated by both deuterons and neutrons. Neutrons are produced in the target, characterized first during the commissioning with the STart-Up and Monitoring Module (STUMM), and replaced during operation with the High Flux Test Module (HFTM) and other irradiation modules. In the Test Cell (TC), target neutrons are shielded with steel, concrete blocks and cooling water, but also stream through penetrations, such as the beam channel, gaps between blocks, Li pipes, and neutron tube for the other experimental stations, imposing potential safety concerns for neighbouring rooms. In the Li system, radiation and contaminant sources, such as Be-7, H-3, and activated corrosion products (ACPs), which are dissolved and deposited in the loop, are the main contributors to the radionuclide inventory in the Li heat removal and impurity control loops. ACPs are also present in the radionuclide inventory of water cooling circuits, along with short-lived water activation products.

Figure 1. IFMIF-DONES schematic plant configuration. Reproduced from [1]. © 2021 The Author(s). Published on behalf of IAEA by IOP Publishing Ltd CC BY 4.0.

<!-- image -->

Besides those prompt sources during beam-on operation, radiation sources from material activation has strong implications for safety, maintenance and waste managements. In addition to the direct deuteron activation of beam-facing materials, those near-source components, fluids and atmospheric gases are also get activated by neutron and produce decay gammas. In the building systems where the waste management, remote handling, logistics and maintenance activities are strongly involved, all those management these activated material and resulting radiation impacts has to be properly assessed. For example, the irradiated material samples will be further extracted, and the radioactive waste will be further disassembled, stored and transported. The safety concerns from radiation resulting from these sources will be evaluated to the workers, sensitive components, as well as to the public. The underlying challenges are complexities of the source terms and the facilities under different operation assumptions, which require nuclear analyses dedicated to each of those radiation contributions and their impacts.

In order to offer quality-assured neutronics studies and nuclear analysis, we assessed, used and further developed dedicated simulation tools and nuclear data, created high-fidelity CAD-based simulation geometries, made realistic and comprehensive assumptions on the source contributions, and computed and analysed the results to comply with the current safety guidelines. In this article, the simulation codes and data relied on by the nuclear analyses will be first summarized and presented in section 2, with further discussion in section 4 for their recent development and evaluations. Section 3 is the main part of this article, which consists of a systematic presentation of the nuclear analyses for the IFMIF-DONES systems. Summary and discussions will be given throughout the article, as well as in section 5.

## 2. Methodologies tools and data

For the deuteron transport simulation, although many charge particle simulation codes exist, the outstanding ones are selected, validated, used, and further developed for the DONES nuclear analyses. MCUNED [6] and McDeLicious [2], which are built based on the Monte Carlo (MC) transport code MCNP [7], are dedicated for the DONES-like applications. MCUNED provides capabilities for simulating deuteron transport with specially corrected neutron angular distribution from the deuteron breakup reaction. For the d-Li reactions in the target, McDeLicious simulates the generation of neutrons and photons based on the use of evaluated d + 6,7 Li cross-sections FZK-2005 [8]. In addition to the full-fledged deuteron MC simulation codes, srcUNED-Ac [9] which is an MCNP source add-on, allows deuteron-produced secondary neutrons and gammas along the accelerator to be produced with precomputed double-differential spectra on different materials.

With the synergies producing fusion-like neutrons, the common simulation tools for geometry modelling, activations, and shutdown dose simulation used in fusion neutronics are also suitable for DONES analyses. CAD-to-MC modelling tools McCad [10], SuperMC [11], GEOUNED [12] and MCNP geometry restructuring tools Numjuggler [13] are recommended for modelling of IFMIF-DONES geometries. Activation inventory tools FISPACT [14] and ACAB [15] have been adopted for DONES by linking with proper neutron activation libraries, e.g. taking into account the selection of nuclear data and group structures 211-group Vitamin-J+ and 709group CCFE structures [16] that provide energy bins covering a maximum energy of 55 MeV. For Shutdown Dose Rate (SDR) calculations, rigorous two-step-based tools MCR2S [17], R2Smesh [18], and R2SUNED [19], which are wellvalidated for neutron activation in fusion applications, are also recommended for DONES application. However, particular attention is needed for the deuteron activation using voxelbased methods, as 40 MeV deuterons result in only a few millimetres in penetration depths, and thus require dedicated mesh for activated parts. In this case the direct one-step (D1S) SDR tool D1SUNED [20] is recommended for deuteron activation, which is capable of simulating light ion-induced activation. In addition, tools for liquid activation and source modelling, e.g. Actiflow [21] have been used in the radiation analysis of activated water, and CAD2CDGS [22] for Li, both with the capabilities of simulating heterogenous activations and complex piping structures.

Variance reduction techniques are essential for neutron and photon shielding calculations, due to the meter-thick heavy shielding structure with many penetrations. ADVANTG [23] is a weight-window mesh (WWM) generation tool that uses a deterministic solver to compute priori neutron flux for global and local WWMs. It shows sometimes deficiencies in DONES simulations due to strong streaming through the penetrations. The OTF-GVR [24] WWM tool, which performs flux-WWM iterative process and controls over-splitting particles in the MC code internally, has been demonstrated with good performance in DONES shielding analysis.

FENDL library is the current reference cross-section library for neutron transport. The newly released FENDL-3.2 [25] is recommended for DONES, since it offers good agreement with the iron experimental data compared with the previous release FENDL-3.1d [26] at the DONES relevant neutron energies. For the neutron activation, the TENDL libraries [27] are recommended, which are based on the physics model implemented in the TALYS code [28]. Apart from general neutron cross sections, special displacement cross sections [29], which are based on the NRT-dpa (Norgett-RobinsonTorrens) model (as the baseline model for the following sections) and the molecular dynamics (MD) based arc-dpa models, were adopted in both the DONES project and the European DEMO project for damage dose simulations of Eurofer steel, SS, and other elements. One particular need of DONES neutronics is high-quality deuteron transport and activation libraries. TENDL library has known deficiencies in the deuteron reaction models [30], which are still not improved in TENDL-2021 [27] and TENDL-2023 at the time of writing. The release of JENDL/DEU-2020 [31], which is now a sub-library of JENDL-5 [32], provides several important target materials (Li-6, Li-7, Be-9, and C-12, C-13) and accelerator component materials (Al-27, Cu-63, Cu-65, and Nb-93). Ongoing validations of JENDL-5, such as the Cu-63 and Cu65 data [33], show clear improvements in the deuteron libraries of JENDL-5 compared to those of TENDL-2021. The latest developments and validations for the toolkits and data will be further presented in section 4.

## 3. Nuclear analysis for IFMIF-DONES systems

## 3.1. Nuclear analysis for accelerator systems

For the accelerator system, MCNP neutronics geometry with rich details has been created for general-purpose simulations. Studies for the three phases of the commissioning are provided for the licensing of the facility. In normal operations, beam-on and beam-off biological dose maps and component absorbed doses are computed for the needs of accelerator design and shielding optimization, remote handling and maintenance, as well as radiation protection. For the strong source contribution such as MEBT and HEBT scraper, BD, as well as safety important components such as Fast Safety Isolation valve (FSIV), dedicated analyses are provided for reducing the radiation and enhancing the lifetime according to the ALARA principle (As Low As Reasonably Achievable). Activation analysis for those components, as well as cooling water and atmosphere gas, are also carried out for controlling the radiation and contaminations.

3.1.1. Geometrymodels. DONES accelerator systems (AS) [34] shown in figure 2 deliver a 125 mA, 40 MeV deuteron beam using a 175 MHz continuous-wave (CW) linear accelerator. The injector provides an ion source at 100 keV energy, coupled with a low-energy transport (LEBT) line. The beam is then further bunched and accelerated by the RFQ up to 5 MeV, transported through the MEBT line, and accelerated by the SRF linear accelerator (LINAC) to the final energy of 40 MeV. In the HEBT line, the beam is shaped to a quasirectangular beam footprint by magnets and scrapers, guided to the HPBD during the commissioning phase, and transported to the Li target during normal operation. The neutronics model in figure 2 is created from the engineering CAD model removing and simplifying unnecessary details, while remaining a complex model within total of 20k cells in the MC model. The simplified geometries that are still used for HEBT, in particular the beamlines and magnets, will be further detailed in the near future. The model is structured with a set of dummy envelopes created inside the accelerator room, which facilitates the future upgrade of individual components.

3.1.2. Commissioning analyses. The Phase 1 commissioning will consist of the Injector system [1] with a LPBD. During this phase, the Injector system will deliver a continuous wave beam (up to 140 mA of 100 keV deuterons) with small transverse emittances and low energy dispersion to the LPBD, in a 100% duty cycle (DC). The 100 keV deuterons can induce nuclear interactions with the deuterium previously implanted in the stopping material. This interaction will generate a 2.5 MeV neutron source due to the D-D fusion reaction. Based on the experience gained in the Linear IFMIF

Figure 2. The neutronics geometry of the accelerator systems and individual illustrated components geometries.

<!-- image -->

Prototype Accelerator (LIPAc) commissioning [35], the nuclear analysis is based on a D-D neutron source with a conservative intensity of 2.6 × 10 10 n/C. Figure 3 shows the dose around the LPBD during the commissioning phase, which is as high as 100 mSv h-1 at a distance of ∼1 m away from the source. Temporary local shielding is suggested near the BD to reduce the overall dose rate, since it is foreseen to install the downstream accelerator components alongside the Phase 1. The radiation to the outside of the room through penetrations is estimated to be &lt;5 µSv h-1 . The residual doses from the activated LPBD and vicinities structure will be computed in the following studies.

Phase 2 commissioning of the RFQ, MEBT, and HPBD is planned to operate the machine with a 20% DC at a beam energy of 5 MeV for a maximum integrated beam time of two months. Deuterons will leave the MEBT via a Diagnostics Plate (DP) before being deposited in a repositioned HighPower Beam Dump (HPBD). A number of radiation sources arise from deuterons reacting with the beamline components, including d-D interactions, beam losses along the SS316 beam pipes and copper in RFQ, deposition on collimating copper scraper blades (in total 120 W on two scrapers in the MEBT), deposition in the HPBD copper cone at even higher power of 125 kW. During beam-on, the total dose of polyethylene (PE) is computed for the purpose of dose assessment of sealings and gaskets, as shown in figure 4. The dose limit for the gaskets are estimated to be several MGy [36], thus the value is far below it. The D-D neutrons are dominant at the front section of RFQ, but overall two orders of magnitude lower than doses from other sources. The produced residual biological doses are 100 µSv h-1 near the MEBT and the entrance of the HPBD, and above 10 µSv h-1 in the meters around the accelerator after 1 h of cooling. The dose decreases by &gt;70% after 1 d of cooling, dominated by Cu-64 (12.7 h) decay and then slowly by Zn-65 (244 d) contributions (see figure 5) [37].

Phase 3 commissioning on the superconducting radio frequency (SRF) operates the accelerator at 1% DC at 40 MeV, with a secondary line guiding the beam to the HPBD, depositing in total of 50 kW beam power. Radiation sources, such as beam losses and the scraper at the BD entrance have also been taken into account. The beam-on and beam-off dose maps are shown in figure 6. It shows shielding weakness for the downstream walls near the airlock AL151 and room R112 adjacent to the BD, where the wall thickness is increased by 35-50 cm to bring down the dose to &lt;10 µSv h-1 . The residual dose in figure 6 after 1 year of conservative commissioning phase at 1 week cooling is &gt;1 mSv h-1 surrounding the HPBD front aperture, due to decay gammas from Mn-56 (2.57 h) and Cu64 (12.7 h) in the first several hours of cooling, and then Co-58 (70.8 d), Zn-65 (244 d), and Co-60 (5.27 y), which decreases slowly the residual dose from 1 d to weeks.

## 3.1.3. Radiation dose maps during normal operations.

During normal operation in CWmode, the main radiological source terms in the AS are the deuteron beam and secondary particles along the accelerator lines, contributed by beam losses along the vacuum pipes, scrapers and collimators. In RFQ, beam losses as a function of beam energy have been taken, which are overall higher than 1 W m-1 in particular the RFQ upstream. For the downstream components MEBT, SRF and HEBT, 1 W m-1 beam loss assumptions were taken for deuteron source contribution, a conservative value backed by beam dynamics simulations. The CuCrZr scrapers used for collimating the beam receive a 0.6 kW beam deposition at 5 MeV in two MEBT copper scrapers, 2.4 kW in the first HEBT scrapers at 40 MeV, and 3.2 kW in the second scraper (or, the HEBT collimator). In addition, the back-streaming neutron from the TC is computed using a surface source recording the particles coming from the beam-ducts.

As accelerator components are subjected to a high-radiation environment, radiation shielding with the concrete building with the penetration needs to be analysed to confirm that the radiological classification of the rooms is compliant. The beam-on and beam-off biological doses are shown in figure 7. The neutron production in the first HEBT scraper is as high as 10 13 n s-1 , thus the maximum biological dose, approximately 10 6 mSv h-1 , is observed near the HEBT scraper. The value is even higher doses in the target interface room (TIR) due to neutrons from the TC. Biological dose maps at 1 hour, 1 day, and 1 week post-shutdown show the most affected areas are HEBT scraper and the downstream area. The residual dose from the HEBT scraper is dominated by gammas from Zn-63 (38.3 min), Cu-64 (12.7 h), and Zn-65 (244 d), which are produced from Cu(d,x) reactions. A 10%-20% dose reduction is noted from 1 h to 1 d, and 20%-30% near SRF Cryomodules 3, 4, and 5. From 1 d to 1 week, a further 10%-20% reduction occurs around the HEBT scraper, with similar decreases near SRF Cryomodules. Figure 8 provides the beam-on absorbed dose in Silicon, which is a standard reference material used for electronics and has radiation degradation concerns. The local maximum values are 7 Gy h-1 in the MEBT scrapers, 1377 Gy h-1 in the HEBT scraper, 1.75 Gy h-1 in the lead shutter, and 2220 Gy h-1 in the TIR collimator.

3.1.4. Radiations from the MEBT. For the low-energy section of the accelerator, MEBT with two scrapers for shaping the beam is the main source of radiation. The scraper blade is made of copper, receives deuteron deposition of 300 W/scraper with 5 MeV energy, and is actively cooled by water.

Figure 3. Biological dose rate (µSv/h) during commissioning of the injector system.

<!-- image -->

Figure 4. Integrated prompt dose (Gy) to PE in Phase 2 commissioning during operation over two months, in vertical view. Rainbow colour legend for the dose map, and discretized colour legend for the contour lines.

<!-- image -->

Figure 5. Total residual dose rate (µSv/h) in Phase 2commissioning accelerator after a decay time of 1 h and 1 d, in horizontal view.

<!-- image -->

A neutronics CAD model has been created, which is incorporated in the accelerator model with upstream RFQ and downstream SRF modules. Several sources have been accounted for, including beamline losses, scraper blade deposition and d-D neutrons in the RFQ, additionally accounting for both direct deuteron activations and secondary neutron activations. The simulations were achieved by a combination of several tools srcUNED-Ac, MCUNED, MCNP6, FISPACTII, and MCR2S for deuteron and neutron activation of those blades and beam pipes. Simulations for shutdown doses 1 h and 2 d after shutdown were performed, with an assumption of 2 years of operation followed by replacements of new scrapers.

It is found that dose rates around the MEBT are largely below 100 µSv h-1 at the relevant decay time for maintenance. At the cooling time of 1 h, the dose rate is close to the high-energy end of the RFQ and the MEBT scrapers exceeds 1000 µSv h-1 close to the structures. This is due to the high losses and high deuteron energy in these regions. 1 m around the MEBT the shutdown dose rate (SDDR) exceeds

<!-- image -->

Figure 6. Beam-on radiation dose (top) and residual dose rate 1 week after shutdown (bottom) (µSv/h) during Phase 3 commissioning in the HPBD surroundings.

<!-- image -->

Figure 7. The beam-on total dose rate (mSv/h) contributed by neutron and photon, and the beam-off dose at the cooling time of 1 hour, 1 day and 1 week.

<!-- image -->

Figure 8. The Silicon absorbed dose (Gy/h) during beam-on in the accelerator rooms.

<!-- image -->

100 µSv h-1 , and is broadly above 10 µSv h-1 . After 2 d of shutdown, the dose close to the MEBT is overall 100 µSv h-1 , while the dose comes down to below 10 µSv h-1 at 1 m surrounding the MEBT, due to the decay of Cu-64 (12.7 h).

3.1.5. Radiations from the SRF. A radiative analysis of the SRF has been conducted to determine the impact of radiation during normal operation on the components and to map the residual radioactivity after shutdown. The neutron sources considered were nuclear interactions with the beamline deuterons and the beampipe throughout the accelerator and MEBT scraper, assuming realistic losses for RFQ, 1 W m-1 for MEBT and SRF, and 600 W for MEBT scrapers. The photons were produced from deuteron-induced nuclear and electromagnetic interactions, as well as prompt photons produced from the secondary neutrons interacting with materials in the SRF. The beam energy is subdivided in the RFQ into 6 bins on the realistic beam losses for the energy increase from 0.1 MeV to 5 MeV, and another 196 bins from 5 MeV to 40 MeV in the SRF. The source is modelled using srcUNED-Ac code based on corresponding losses and energies. The radiation sources contributed by the HEBT beamline and scraper, which are dominant sources at the downstream beamline, have also been taken into account. Considering the back-streaming neutrons and gammas from TC are too small to produce results with satisfactory error margins, this contribution is not taken into account.

Table 1. Table of components with their maximum and minimum dose rates.

| Components  Min. Dose  Rate (Gy/hr)  Max. Dose  Rate (Gy/hr)  Beam Loss Monitors  0.005  0.104  Tie Rods  0.004  0.069  Cold-Warm  Transition Gaskets  0.004  0.103  Coupler Gaskets  0.001  0.020  Door Gaskets  0.001  0.014  Top Plate Gaskets  0.001  0.009   |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

Figure 9. Residual dose (µSv/h) of MEBT combined with the source from RFQ and SRF area.

<!-- image -->

During operations, the absorbed doses are computed in table 1 for the sensitive components, including the beam loss monitors, tie rods, and a set of gaskets for various purposes. The cumulated doses at the time of operations will be used then for estimating the lifetime of these components and scheduling maintenance frequencies. The shutdown dose rates in figure 10 are obtained using two shutdown dose calculation codes MCR2S and N1S [38], with a deviation of 10% between the two codes. The residual doses are clearly higher in the last two cryomodules, as the beam energy is higher resulting in higher neutron productions and activations. Some discrepancies that appeared in the MEBT region are due to higher mesh resolutions used for the later calculations, in which the local field is better captured. The hot spot found at SRF in figure 9 is likely due to the simple model used in this calculation, while the shielding becomes much thicker around the beam line in the detail SRF model in figure 10.

3.1.6. Radiations from the HEBT. HEBT scraper is a critical source of residual doses for maintenance, with a hotspot of radiation during beam-on clearly seen in figure 7. In the maintenance phase, the HEBT scraper is removed first by robotic arms, with the replacement of a new scraper. Removing the scraper has a strong impact on the radiation doses, as the residual doses shown in figure 11 decreased significantly from 1 mSv h-1 surrounding the scraper shielding, to the value of 100 µSv h-1 except for the beam pipe vicinity. This will allow the hands-on operations at the scraper surround for a short period, and avoid complicated remote operations.

Figure 10. Residual dose (µSv/h) of SRF combined with the source from RFQ and MEBT area (horizontal and vertical axis with a unit of 10 m).

<!-- image -->

Figure 11. Residual dose rates after 2 d cooling. Contour lines at 100 (yellow) and 1000 (red) µSv/h. (A) With scraper and shielding closed. (B) scraper removed and shielding open.

<!-- image -->

The Fast Safety Isolation Valves (FSIVs) are two safetyclass machine protection valves installed in the HEBT, placed in the Radiation Isolation Room (RIR) right before the Target Interface Room (TIR) wall, to address both Anticipated Operational Occurrences and Design Basis Accidents. These valves contain radiation-sensitive components, which may imply their replacement after a period of use.

Despite their accommodation in the RIR, the expected lifetime of the valves due to the radiation doses to the actuators was around 6 years. An ALARA study was conducted to increase the lifetime of the FSIVs. Several measures illustrated in figure 12 were considered to reduce the doses absorbed by the FSIV radiation-sensitive components. The following measures were taken, firstly, on beam pipe diameter reduction of 1 cm to provide 'shadow' shielding against the highly collimated neutrons from TC and TIR. And a secondary approach on a dogleg for blocking those streaming gaps for the RIR-TIR shielding plug, and then local shields of lead and boron carbide surrounding the FSIV actuators. With these three measures, the lifetime of the FSIVs increases from 6 years to 16 years.

3.1.7. Radiations from the TC. In addition to the source produced from the deuteron along the accelerator system, the neutron back-streaming from the TC also serves as an important source for the accelerator rooms, especially the Target Interface Room (TIR) where the HEBT end section and Lithium diagnostics in the secondary beam duct are placed. These neutrons are separately computed using the TS model, and presented in figure 13. The strong neutron flux is streaming through the 27 × 12 cm 2 Through Wall Beam Ducts (TWBDs), with the dose rate estimated to be 10 10 µSv h-1 side of the beam pipe, and 10 7 µSv h-1 overall in the TIR. To facilitate the simulation of these neutron and photon contributions, a surface source is created with the recording of particle tracks coming out from the beam ducts, used for the calculations in the accelerator rooms discussed in the previous sections.

Figure 12. The shielding optimization for the FSIV with three shielding options.

<!-- image -->

Figure 13. The neutron dose rate (µSv/h) in the TIR contributed only from the TC neutrons, without considering the HEBT structures.

<!-- image -->

For the lithium diagnostics system, particularly the InVessel Viewing System (IVVS) placed in the position of TWBD2 shown in figure 13, the estimation of absorbed doses to the sensitive components such as the mirror is key for estimating the diagnostics lifetime. The maximum absorbed dose found in the IVVS silica prism reaches 0.6 MGy/FPY (full power year, 365 d operation) from photons, and 1.13 MGy/FPY as a total from both neutrons and photons. Taking into account the limiting values of 4.88 MGy (photon) and 10 MGy (total) from experimental works [39], the IVVS lifespan could be ∼10 years without considering other factors.

3.1.8. Water activations. Water is used for cooling the accelerators, and strong activation is expected in the first HEBT scraper. For the second HEBT scraper located in the TIR, helium is used to avoid the possible entrance of water into the beam pipe and prevent water reaction with Li. Activation of the cooling water is computed using the actual HEBT scraper model with the inclusion of the flowing paths, taking precisely into account the mass flow rate and water circuit. Based on the calculation, it is estimated that the water activation in the HEBT scraper is not a major concern, which is due to the short water activation time of a few seconds, the short half-life of the resulting radioisotopes, and the long distance of more than 12 m to the exit of the AS vault. The specific activity is at the level of 10 5 Bq kg-1 , dominated by N-16 (7.1 s) from the O16 (n,p)N-16 reaction, as well as O-15 (122 s) from the O-16 (n,2n)O-15 reaction at the threshold energy of 16 MeV. ACPs from the water corrosion on CuCrZr scraper blades are considered less significant due to the low corrosion rate at the low operation temperature of 20 ◦C-30 ◦C [40].

3.1.9. Air activations. The accelerator vault and RIR are filled with air, and TIR is filled separately with Argon. They will be activated by neutrons, producing mainly Ar-41 (1.8 h)

from the Ar-40(n, γ) reaction. Simulations based on the current design of the Heating, Ventilation, and Air Conditioning (HVAC) system indicate that, the level of Ar-41 in the AS vault will reach the equilibrium value of 10 7 Bq within 17 min. For the TIR, a high activity of 8.2 × 10 10 Bq can be expected before reaching equilibrium after 19 h. This requires proper room isolation and a decay time to reduce contamination. Activation of gas also happens inside the beam pipes, admitting low gas density in the vacuum atmosphere. There are amount of Argon and D2 gases inside the beam pipe, and the activation is dominated by deuteron activation of argon, resulting in a total activity rate of 3.0 × 10 4 Bq s-1 , which produces several short-lived isotopes, including Ar-41.

3.1.10. Radiations to the neighbouring cells through penetrations. It is important to assess the radiation conditions in rooms adjacent to the accelerator room during operation and comply with the radiation classification for the rooms. Penetrations in walls and slabs used by various systems are critical for understanding radiation streaming from the accelerator vault to neighbouring rooms. Those penetrations include the RF waveguides, HVAC openings, cable trails, water and helium supplies, etc. The radiation analyses require a proper assumption on the locations and dimensions of those penetrations, taking into account various radiation source contributions, and further optimization calculations for shielding options.

Currently, the HVAC opening and RF waveguide are taken into account in the building geometry, while other penetrations are still missing in the building design. The simulation includes all source contributions from the accelerator and the back-streaming radiation from the TC. In terms of biological dose values during accelerator operation, all the neighbouring rooms evaluated in this study are classified as free permanent controlled areas (green zone, 3-10 µSv h-1 ), except for room R109-1 where the RF waveguides penetrate through, which is classified as a limited permanence controlled area (yellow zone, 10-1000 µSv h-1 ). From figure 14 it is clear that the radiation in neighbouring rooms is well within the given limit, with the HVAC opening right at the boundary of yellow and green zones. Radiation in the room above and below the accelerator vault has also been computed, and confirmed to be less than 10 µSv h-1 . Follow-up analyses will be continued on the updated building model with the missing openings.

Figure 14. Radiation levels indicated by colours as per radiation classification of building areas in different accelerator and neighbouring rooms (first 6 plots), and radiation to the room above the accelerator (last plot).

<!-- image -->

## 3.2. Nuclear analysis for test systems

For TSs, we have performed simulations such as neutron and gamma fluxes, radiation damage, gas production, and nuclear heating, presented for both a standard beam size of 20 × 5 cm 2 and a reduced beam size of 10 × 5 cm 2 . The deposition and distribution of the 5 MW total beam power inside the TC are summarized. For the TC, heating maps, Displacements Per Atom (DPA), and gas production in the shielding are also plotted, with a primary focus on providing radiation protection to adjacent cells. Water activation is in the cooling system and air activation in the existing gaps is also analysed. The STUMM, as a key component in the final commissioning phase, is modelled and analysed.

Figure 15. Geometry of the TC and internal components.

<!-- image -->

3.2.1. Geometry of test systems. The geometry of the TS is shown in figure 15, admitting that the target system is part of the Li systems (LS) but not TS. The TC, which houses the key components of the TA and the HFTM, consists of massive shielding structures. It consists of a 2535 mm steel liner made of SS316L for atmosphere and safety confinement, and Removable Biological Shielding Blocks (RBSBs) with a 10 mm steel shell filled with heavy concrete (HC) and embedded with cooling water pipes. A concrete bucket surrounding the RBSBs provides structural support for the RBSBs, as well as additional shielding against the neutrons and photons. The upper part of the TC is covered with a helium-cooled Lower Shielding Plug (LSP), and an Upper Shielding Plug (USP) filled with HC. A Test Cell Cover Plate (TCCP) provides atmospheric sealing and additional shielding against the radiations through the gaps. The helium pipe, heater cables and diagnostics cables for the test modules go from TC through the Pipe and Cabling Plugs (PCPs), which are zig-zag concrete blocks to mitigate radiation streaming. The beam is injected through the 27 × 12 cm 2 Through Wall Beam Ducts (TWBD). The neutron beam is passed through a tube in 150 mm diameter, controlled by the neutron beam shutter (NBS) at the exit for complementary experiments.

The neutronics model in figure 15 presenting the TS was created modularly, providing multi-level envelopes for the components with clear geometry boundaries. The TA and HFTM are reserved with tailored envelop solids inside the inner TC space. Similarly, envelopes are built for the RBSBs, LSP, USP and PCPs, with the inner space filled with concrete and piping. The rest of the geometries, such as liners and buckets, are directly created without complex envelopes.

Figure 16. Neutron flux (n/cm 2 /s) at the target region under 20 × 5 cm 2 beam.

<!-- image -->

Figure 17. Photon flux (p/cm 2 /s) at the target region under 20 × 5 cm 2 beam.

<!-- image -->

3.2.2. Neutron productions from the target. The d-Li reaction produces neutrons through Li(d, xn) stripping reactions, with a total yield of ∼6.8 × 10 16 n s-1 estimated from McDeLicious with FZK-2005 data [8], and a broad peak around 14 MeV emitted at the forward angle. Another peak was observed at around 1 MeV, which are neutrons produced isotropically from the evaporation process [41]. The neutron and photon flux in figures 16 and 17 give a neutron flux of 1-5 × 10 14 n/cm 2 /s and a photon flux of 5 × 10 13 - 2 × 10 14 p/cm 2 /s in the centre four columns of the HFTM capsules, where the material samples are loaded.

The accelerator has flexibility in adjusting the beam footprint between the nominal size of 20 × 5 cm 2 and the reduced size of 10 × 5 cm 2 . It is aimed at balancing the irradiation intensity, and gradient, if required, to speed up the irradiations. The reference beam footprint which is the one used in the IFMIF Engineering Validation and Engineering Design Activities (IFMIF/EVEDA) phase [2] (figure 18), was adopted as the baseline beam profile since the project started, and it was recently validated through beam dynamics simulations. A validated beam profile with a similar shape to the IFMIF/EVEDA profile has been produced from the simulation, with slightly better DPA-volume performance. Currently, the new profile is still under neutronics and thermal studies on its impacts on the TA [42].

Figure 18. The IFMIF/EVEDA 20 × 5 cm 2 beam profile (left side) and the new beam profile with a centre-peak (right side). Reproduced from [5]. CC BY 4.0. Values are shown in arbitrary units.

<!-- image -->

Figure 19. Deuteron heat deposition (W cm-3 ) in the lithium target. Reproduced from [43]. CC BY 4.0.

<!-- image -->

The deuteron beam is fully stopped by the Li target, giving the Bragg peak at the depth of 2.0 cm, and the deuteron track ends after 2.1 cm in depth. The power deposition in figure 19 shows that the peak heating expected in the target reaches 100 kW cm-3 , with a total power of 4856 kW and an average power of 24 kW cm-3 over the footprint volume of 20 × 5 × 2.0 cm 3 . The deuteron heating is concentrated at the footprint volume, which is much stronger than neutron and gamma heating at the level of 10 kW (table 4).

## 3.2.3. Irradiation performances of HFTM

3.2.3.1. Geometry. As the key component for material sample irradiation, the HFTM is focused in this study on the nuclear responses, material damage and neutron diagnostics. The material specimens will be placed in the rigs, each containing a capsule of 81 mm in height (z-direction), 40 mm in width (y-direction) and 16 mm in thickness (xdirection). Previous neutronic studies [4] considered most of the time homogenous mixtures of 75% EUROFER and 25% Sodium for the specimen volume. Recently, we created a detailed specimen model with the distribution Capsule Loading Configuration (CLC) version 2.0 [44] (figure 20), in which EUROFER-97 volume fraction is 84.8%, and sodium 12.9%. There are five types of specimens (tensile, fatigue, impact, fracture toughness and fatigue crack growth) designed based on the Small Specimens Test Techniques [45]. The MCNP geometry of the HFTM with the CLC v2.0 loading was created and integrated into the TSs model, considering the same structure for all rigs.

Figure 20. Geometries of the HFTM and materials samples in the CLC v2.0.

<!-- image -->

3.2.3.2. Neutron fluxes and spectra. For the nuclear analyses, McDelicious code was used with IFMIF-EVEDA profile in two footprint sizes, the nominal one, 20 × 5 cm 2 , and the reduced one, 10 × 5 cm 2 . The mesh tallies used have a resolution of 2.5 × 2.5 × 2.5 mm 3 while the specimen region and 1.0 × 1.0 × 1.0 mm 3 , when considered the specimen stack [44]. The nuclear data library used for the neutron transport is FENDL.3.1d, and JEFF3.3/DPA [29] for the primary displacement damage (abbreviated as DPA) in NRT dpa model. The full power year is defined as full power irradiation over 365.25 d. All the results reach good statistical relative error lower than 0.05 in all the mesh cells.

The neutron flux map of the HFTM is shown in figure 21. The highest neutron flux, around 1-5 × 10 14 n/cm 2 /s, is in the central rigs. The asymmetry is due to the 9◦ incidental angle of the beam. The neutron flux is reduced to 2 × 10 13 n/cm 2 /s in the farthest rigs away from the source. The neutron spectra in the HFTM are compared with the DEMO first wall spectra of Helium Cooled Pebble Bed (HCPB), Dual Coolant Lithium Lead (DCLL) and Water Cooled Lithium Lead (WCLL) blankets figure 22, which shows that the neutrons produced in IFMIF-DONES resemble the 14 MeV fusion neutrons by a broad peak around 14-15 MeV. At high energies, the neutron flux is up to one order of magnitude higher in rig 45 than in rig 13. The neutron flux at the HFTM in different energy ranges is estimated to be: 3% with energy &lt; 0.1 MeV, 32% between 0.1-1 MeV, 51% between 1-14 MeV, and 14% above 14 MeV.

3.2.3.3. Displacement damage doses. In order to meet the required irradiation performance of DONES, it is essential to achieve DPA per full power year (dpa/fpy), with sufficient volume in the HFTM. The DPA is computed by integrating the neutron flux with the EUROFER97 displacement cross section.

The primary displacement damage rate distribution in the HFTM is presented in figure 23 for the two beam footprints. The centre 4 columns receive a high DPA of 20 dpa/fpy at the front rigs, and increase to 30-40 dpa/fpy by focusing the beam to the 10 × 5 cm 2 footprint to accelerate the damage dose with fewer irradiation volumes. The value at the positions of rig 11 is less than 1 dpa/fpy, which makes it less valuable for irradiating structure materials.

Figure 21. Neutron flux [n/cm 2 /s] distribution on the horizontal cut-plane at the middle of the deuteron beam. Reprinted from [44], Copyright (2025), with permission from Elsevier. (a) 20 × 5 cm 2 and (b) 10 × 5 cm 2 footprint size. Location of the rig 11, 13 and 45 is shown in (a).

<!-- image -->

Figure 22. Neutron spectra in the rigs 13 and 45 and in DEMO blanket first-walls Reprinted from [44], Copyright (2025), with permission from Elsevier.

<!-- image -->

The volume available at different values of DPA is presented in figure 24, by integrating the irradiation volume as a function of the primary displacement damage rate. Two different volumes are presented, the 'Specimen region' which counts the continuous volume in HFTM, and the 'Specimen stack' consider only the space available in the capsules. The volume for the parasitic volume occupies more than half of the HFTM space, thus making the irradiation volume more valuable.

3.2.3.4. Gas production and ratio to DPA. The gas productions have a direct impact on the diffusion of damage effects on materials and a synergistic effect with the primary displacement damage rate. Helium productions from RAFM steel are contributed mainly by quasi-threshold reactions of neutrons of several MeV, thus the ratio of He production to the damage dose rate, i.e. the He-DPA ratio, is higher in fusion reactors compared with that of fission reactors, yet lower than that in the spallation sources due to its high neutron energies.

Figure 23. Primary displacement damage rate [dpa/fpy] distribution on the horizontal cut-plane at the beam level. Reprinted from [44], Copyright (2025), with permission from Elsevier. (a) 20 × 5 cm 2 and (b) 10 × 5 cm 2 footprint size.

<!-- image -->

<!-- image -->

Figure 24. Integrated irradiation volume as a function of primary damage dose rate [dpa/fpy].

<!-- image -->

The figures 25 and 26 show the gas distribution for He and H respectively in the HFTM. For helium (He), the values in the first row are around 14 He-appm/dpa for the 20 × 5 cm 2 beam footprint and exceed 14 He-appm/dpa for the 10 × 5 cm 2 footprint. For hydrogen (H), the values range from 50 H/dpa for the nominal beam to 60 H-appm/dpa for the reduced beam footprint. The estimated value for DEMO is between 11-14 Heappm/dpa and 45-55 H-appm/dpa, which is overlapped with the IFMIF-DONES irradiation conditions. A higher gas-DPA ratio is expected in the centre compared to the lateral rigs.

3.2.3.5. Nuclear heating. The distribution of nuclear heating in the HFTM is presented in figure 27. It is obtained by meshing on that volume with mixed material in each voxel. The heating peak is 15 W cm-3 at the HFTM front structure, which is close to doubled in a reduced beam heat map. The void inside the voxel is the reason for underestimations of heating near the cooling channels, thus a superimposed heating map for a specific material such as EUROFER is also computed for thermal analyses. The contribution of photon heating is comparable to neutrons heating near the target, while it becomes dominant for the downstream and lateral area, due to a larger amount of gamma produced from (n, γ) reactions.

Figure 25. He-DPA ratios (He-appm/dpa) on the horizontal cut-plane at the middle of the deuteron beam; (a) 20 × 5 cm 2 and (b) 10 × 5 cm 2 footprint size.

<!-- image -->

Figure 26. H-DPA ratios (H-appm/dpa) on the horizontal cut-plane at the middle of the deuteron beam; (a) 20 × 5 cm 2 and (b) 10 × 5 cm 2 footprint size.

3.2.3.6. Detectors and response analyses. To determine the dose that each specimen will receive within the HFTM, two main types of diagnostics are considered: Self Powered Neutron Detectors (SPNDs) and activation foils. SPNDs provide an online electrical signal produced from the radiation, while activation foils (AFs) offer offline measurements after irradiation [46]. Additionally, the foils are very thin sheets that can be easily placed inside the HFTM, whereas SPNDs are cylinders with several millimetres in diameter and require designated space in the centre of the rig and cable connections.

Figure 27. Total Nuclear heating distribution (W cm-3 ) plotted at the beam level; (a) 20 × 5 cm2 and (b) 10 × 5 cm2 footprint size.

<!-- image -->

Table 2. Results of the estimated signal current and uncertainties (in brackets) in the SPND inside rigs 11 and 45 of the HFTM.

| Estimated current (nA)  Rig  Rig 11  Rig 45  (n, β-)  5.37(3)  42.75(11)  (n, γ, e-)  2.34(13)  92(3)  (γ, e-)  21.90(3)  523(8)  Total  29.6(5)  659(11)   |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------|

The baseline configuration of the SPND with a Rhodium emitter provides electric signals which have been estimated using MCNP6 code from the neutron and photon flux and spectra. The signal currents are given in table 2, calculated assuming an isotropic cylindrical source surrounding the detector. From it, we can find that the neutron prompt (n, γ) signal contributes only 14% of the total signal, while most signals are from gamma, and neutron delay signals from (n, β-). In addition, the prompt (n, γ) reaction is prominent in the thermal and epithermal neutron energy, which makes the Rhodium emitter less suitable for the HFTM environment. Such behaviours were observed similarly in a SPND simulation presented in [47]. Further emitter materials currently are being studied, as well as other alternative online diagnostics.

Activation foils made of Au, Ni, Y, Co, and Fe were selected based on the several criteria-sufficiently long half-life of the resulting radioisotopes, response energy ranges, characteristic gamma spectra, and material properties such as melting points. The dominant dosimetry reactions and resulting activities under the HFTM neutron flux and spectra are provided in table 3. Due to the strong radiation in the HFTM, the foils will be over-activated and thus require methods to reduce the counting of the gamma, e.g. reducing the mass of the foils, increasing the measurement distances etc.

3.2.4. Test cell shielding and nuclear responses. TC has missions of shielding the high-energy neutrons and gammas coming out from the target, providing a controlled atmosphere and temperature, removing the nuclear heating deposited on the structures, and providing a safety barrier in case of accidents. The radiation dose maps are provided in figure 28. The neutron dose rate decreases from 10 12 µSv h-1 inside the TC to the level of 1000 µSv h-1 behind the NBS, and to the level of &lt;0.5 µSv h-1 at the lateral side of TC. Radiation streaming to the Access Cell (AC) above TC is evident, which partially exceeds the dose limit of 1 mSv h-1 . A recent update of the TC resolved this issue by blocking the streaming path with a dog-leg shape on the RBSB. The gamma dose contribution is not significant compared with the neutron dose, while this contributes an increase in the concrete shielding due to the (n, γ) reaction in the thermal and epithermal energy range. The neutron flux spectra at typical locations are illustrated in figure 29 Compared with the neutron flux in the HFTM, the neutron flux in the TC inner space and the concrete part are dominant in the neutron at 1 MeV and the epithermal energy, which is due to the scattering of neutrons. For the spectrum at the CER entry, the peak at 14 MeV is obvious, because the angle of the tube is exactly aligned with the beam direction. Also, a small peak of thermal neutrons is observed, resulting from the moderator block placed at the tube exit.

The TC components are aimed for the lifetime of the facility, except for the TA and HFTM. Nevertheless, maintenance is feasible for the shielding plus and the RBSBs for the rare failure of those components. Nuclear responses are computed for the inner TC, on the nuclear heating of concrete and SS, damage doses, helium production, and Silicon absorbed doses (figure 30). The results in figure 30(a) is computed on a mesh with mixed material in the voxel, while other figures are computed using a superimposed mesh assuming the material is filled fully in the mesh. From the heating maps, it is noted that the nuclear heating is mostly deposited in the first 1 m of the concrete (except downstream), considering the heat density less than 10-6 W cm-3 is negligible low [48]. The heating maps on the material SS316L are used for estimating heating on SS-made components e.g. TC Liner, RBSB cladding, bucket liner, etc. The damage doses (Fe-equivalent) on the TC inner surroundings are overall less than 0.05 dpa/fpy, which is not a significant number of &lt;1 dpa on the liner after 20 years of operations. Helium production is expected to be 1 appm/fpy at the beam downstream, and up to 0.1 appm/fpy at the upstream, which can be potentially an issue because a cumulative value of &gt;1 appm is the current limits applied for the re-welding of SS316L [49]. The absorbed dose of Silicon is higher than 50 MGy/fpy, which imposes strong challenges on the electronics and sensitive components in diagnostics and connectors, as they are usually resistant to irradiation up to 10 MGy e.g. for the silica and PEEK (polyetheretherketone). Thus materials selections for the connector insulation are recommended to use alumina, which is able to resist up to 5 × 10 4 MGy of radiation [50].

Table 3. The resulting activities of selected foils under HFTM irradiations for one year [46].

| Dosimetry reaction Melting Point Half-life Energy range Mev Spec. activity Bq/mg  93 Nb(n,x) 88 Y  2477  106.7 d  27-55  3.36 × 10 03  55 Mn(n,2 n) 54 Mn  1246  312.3 d  12-40  4.09 × 10 04  nat Ni(n,x) 57 Co  1455  271.8 d  11-55  4.65 × 10 04  nat Ni(n,x) 60 Co  1455  5.27 y  12-55  4.10 × 10 02  nat Ni(n,x) 54 Mn  1455  312.3 d  17-55  4.00 × 10 03  89 Y(n,2n) 88 Y  1552  106.7 d  14-45  4.47 × 10 04  nat Fe(n,x) 54 Mn  1538  312.3 d  3-55  4.48 × 10 04  59 Co(n,2nα) 54 Mn  1495  312.3 d  27-55  4.12 × 10 03  59 Co(n,3n) 57 Co  1495  271.8 d  22-55  2.26 × 10 04  197 Au(n,3 n) 195 Au  1064  186.1 d  16-40  2.51 × 10 04   |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

<!-- image -->

Figure 28. The neutron dose maps (µSv/h) of the TC with the neutron beam shutter closed, horizontal cut at beam level (top) and vertical cut at target centre (bottom).

<!-- image -->

The total power of 5 MW delivered by the deuteron beam was deposited mostly in the Li target, with the rest spread in the inner TC components, liner and shielding. The integral heat deposition is presented in table 4. The total heat deposited in the TC inner structures and shielding is 130.6 kW. As mentioned above, the heat is mostly deposited in the inner structures and the first 1 m layer of the shielding, with around 2 kW deposited in the rest of the structure e.g. bucket and its liner. The decay heat of the TC components is shown in figure 31 as well, in which we can see that the total decay heat in the TC is 1-2 kW within 1 h of cooling, around 1% compared to the heat during operations.

## 3.2.5. Radiation from TC to the adjacent rooms

3.2.5.1. Radiation to the access cell. TheAC located above the TC is classified as a yellow zone, where the dose rate is limited to &lt;1 mSv h-1 . The shielding analyses revealed the radiation hot spots on the AC floor due to the leakages through the gaps between the RBSBs and shielding plugs, as shown in figure 32. To mitigate the radiation leakages, the RBSB shielding is optimized to block the gaps. The modification impact on reducing dose is further confirmed by neutronics analyses.

Figure 29. Neutron flux spectra at several locations of the test cell.

<!-- image -->

Figure 30. Nuclear responses computed for the inner TC and the shielding. Reprinted from [51], Copyright (2019), with permission from Elsevier. (a) Total neutron and photon heating (W cm-3 ); (b) Total neutron and photon heating (W cm-3 ) on SS316L; (c) Fe-equivalent damage dose rate (dpa/fpy); (d) helium gas production (appm/fpy); (e) and (f ) Silicon absorbed dose (MGy/fpy) at vertical and horizontal position.

<!-- image -->

For the needs of defining the maintenance operation for the cooling pipes located between the USP and TCCP, the residual gamma doses right after shutdown are evaluated by taking into account the source of activated components HFTM, TA, Li quench tank (QT), and TC Liner, assuming LSP and USP are still in place. The biological dose rate with the TC

closed is shown in figure 33. Even though the statistical error at the location of interest is not perfect, the dose value is clearly below the level of 10 µSv h-1 with good confidence. Further improvement of the statistics will be dedicated in the future.

3.2.5.2. Radiation to the lithium loop cell. The Test Cell Lithium System Interface Cell (TLIC) is an isolated cabinet located in the Lithium Loop Room (LLC) below the TC, where the thermal expansion sections of the input and output lithium pipes are housed. The TLIC is in principle an extension of the TC internal volume to the LS region, with the atmosphere connected to the inner TC. Two apertures with leak-tight air lock hatches or doors are set aside on the TLIC wall for RH operations on the lithium pipe flanges. The high intensity neutron and gamma radiation produced from the TC and streaming through the Li pipes are the main source of radiation during beam-on for TLIC, as well as resulting activations.

Table 4. Heat deposition in the TC components.

| Heat (kW)  D+ beam power in Li Target 4855.9  Neutron and photon heat in Li 10.37  TA Structures  6.93  HFTM  16.9  TC liner  15.2  RBSBs  77.3  Bucket liner  0.2  Bucket  1.6  PCPs  2.6  LSP  9.9  USP  0.01   |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

Figure 31. Decay heating (kW)of the components inside the TC.

<!-- image -->

After computing the neutron and gamma fluxes using the McDeLicious with the variance reduction tools ADVANTG, the total biological doses were obtained in figure 34. Most of the radiation stays close to the pipes, where the total value reaches 1 Sv h-1 before dropping to 10 mSv h-1 outside TLIC. The activation analysis in figure 35 shows the contact dose for the pipes is in the range of 10 µSv h-1 during a maintenance period of 1-20 d, dominated by Mn-54 (312 d) and Co-60 (5.27 y). The activations of TLIC structures are lower overall than the pipes. For the residual doses, the contribution from TC is expected to be a similar level of 10 µSv h-1 near the pipes when Li pipes are empty [52], which is at a consistent level shown in figure 35. Nevertheless, the contribution from Be-7 and ACP in the Li film attached to the pipes remains to be analyzed.

3.2.5.3. Radiation shielding for the complementary experiments room (CER). The collimated neutrons from the TC will be supplied to the Complementary Experiments Room (CER) located downstream, for the IFMIF-DONES users to conduct a variety of neutronics experiments. The neutron beam enters the CER through a neutron tube of 150 mm in inner diameter embedded in the TC shielding. Neutronics modelling and analyses of the neutron beam tube (NBT) and the NBS with the two design configurations of the NB shutter: (1) Open NB shutter; and (2) Closed NB shutter, have been performed with the created TSs model, shown in figure 15. During shutter close, it is required CER to be in a limited permanence-controlled area (yellow zone, 10-1000 µSv h-1 ), while during the shutter open for experiment, the room is access forbidden (red zone, &gt;100 mSv h-1 ).

Assuming HFTM is in place without any additional irradiation modules, the total neutron flux through the NBT is shown in figure 36. The rough estimation of neutron flux at the exit of the NBS opening is up to 2 × 10 10 n/cm 2 /s. The neutron spectra at the NBS exit are shown in figure 29, in which we can see a large fraction of the high-energy neutron above 10 MeV, with a small tail of thermal neutron below 1 eV, which is scattered by the moderator block placed right after the beam exit.

Studies were made for selecting the materials for the NBT, depending on their impact on the outgoing neutron spectra. Currently, zirconium Zircaloy-4 is used for the tube, with other materials of interest-SS316, copper, nickel, aluminium alloy PA4, lead and graphite. The last two choices of material must be cladded by SS. The results are shown in figure 37, in which no clear differences were found between those spectra in important energy ranges. Therefore, the takeaway is that the neutron spectra are not sensitive to these material selections for the NBT. In addition, different tube angles compared to the baseline 9◦ were analysed with their impact on the outgoing total neutron flux and flux spectra. NB tube is rotated around the target centre for 6◦ , 4◦ , and 0◦ positions. Results shown in figure 37 give the conclusion that the impact of differences is 10%-20% by adjusting the angles to 4◦ and 0◦ , mainly at the peak energy. By adopting a 6◦ angle, for example, we can avoid hitting the beam against the pillar and leave more space in the room for experiments.

So far, no routine experiment has been planned in CER. A polyethene (PE) moderator cuboid block with 50 cm on each side is placed right behind the exit of the tube, aiming to use the thermal neutrons for useful nuclear experiments. The high neutron fluxes provided for other nuclear experiments in CER, without local shielding, will cause problems from the radiation protection of this room. Most of the neighbouring rooms are classified as green zones (below 10 µSv h-1 ).

The baseline concrete thickness was 100 cm for the CER walls, floor and ceiling. However, the biological dose rate in the adjacent rooms and the corridor significantly exceeds the limits (figure 38). The total dose rate is determined by neutrons since the photon contribution is overall below 3%. Several concepts were studied to improve the shielding and reduce the dose in the regions of issue. The first idea was to extend the walls up to 150 cm. The dose rate was decreased but not sufficiently. The additional attempt to add a labyrinth wall turns out to be unfavourable due to the reduction of work zones. Besides the walls, additional layers of 50 cm of borated PE are needed to decrease the dose for rooms above the ceiling and below the floor. This option is currently under discussion due to the potential impact during seismic events, by those large and heavy blocks of PE attached to the ceiling.

Figure 32. Neutron dose rate (µSv h-1 ) streaming from the TC to the AC, plot at the position of the RBSB gaps.

<!-- image -->

Figure 33. Residual dose rate (µSv h-1 ) induced by the sum contributions of activated HFTM, TA, QT and TC Liner toward the USP, immediately after shutdown. The yellow contour indicates the dose level of 10 µSv h-1 with good statistics.

<!-- image -->

Figure 34. Total dose rate map at the TLIC location.

<!-- image -->

Figure 35. Specific contact dose rate (Sv h-1 ) of TLIC inlet pipe.

<!-- image -->

Further calculations showed that the dose in the corridor can be reduced below 10 µSv h-1 when the rear wall of CER is 200 cm thick with a neutron beam dump (1.5 m × 1.5 m × 3.0 m polyethylene cuboid with 5 cm thick lead shield) placed at the beam downstream (figure 38). Further study will be continued on the local shielding for the ventilation penetrations, as well as an optimization of shielding for the ceiling and floor.

3.2.6. TC water activations. Heat removal systems are required for the TC liner and RBSBs, which will experience high neutron flux. Water will flow through pipes to cool the components, before travelling to the heat exchangers (HXs) which may lie in worker-occupied areas. Reactions with isotopes in water are known to generate products N-16 (7.13 s) and N-17 (4.1 s) with half-lives on the order of seconds and minutes: O-16(n,p)N-16 emitting 6-7 MeV gamma rays, and O-17(n,p)N-17 emitting secondary neutrons. Due to the highenergy tail of the DONES neutron spectrum, the 15 MeV threshold reaction O-16(n,2 n)O-15 creates a longer-lived O15 (122 s) source of 511 keV gamma rays, which is not present in fusion reactors. In addition, corrosion products activate with much longer half-lives. The TC water cooling system (WCS) may therefore carry activated material to areas outside the primary biological shielding. It is important to understand the source term, to mitigate if necessary.

Figure 36. The neutron flux (n/cm 2 /s) from the TC to the CER through the NBT during shutter open.

<!-- image -->

The activation of the TC-WCS was assessed with the ActiFlow fluid activation code developed at UKAEA [21], which allows the user to create a fluid circuit including paths through neutron flux meshes, and circulate a unit of material around this circuit using the FISPACT-II inventory code for activation [14]. This has previously been validated for simple circuits not accounting for fluid dynamics. As part of this analysis, the functionality of ActiFlow was extended to incorporate basic corrosion effects. Adopting constant corrosion product release rates of 4.0 × 10-4 gm-2 h-1 (SS 316L) and 2.5 × 10-3 gm-2 h-1 (CuCrZr) consistent with experimental data at comparable temperatures [40], the corroded material was mixed into the water inventory accounting for wetted surface area and water volume. Figure 39 shows the evolution of the activity concentration of water leaving the highest-activity RBSB. The results show that the water radionuclides dominate over ACPs at short decay times, and that the choice of flow rate significantly affects the activity, which is around 110 GBq kg-1 at short decay times but is close to 10 MBq kg-1 at long decay times in all cases. The analysis demonstrated the multiple variables affecting the water inventory: slower flow speeds result in more decay of short-lived N-16, but result in more build-up of longer-lived O-15, which requires a larger decay volume to remove. As N-16 emits high-energy gamma rays, it is critical from a safety perspective and its concentration in the circuit should be minimised. If a 3500 L decay coil is inserted into the system outside the TC, ActiFlow results suggest that the contact dose rate at the coil outlet could be reduced by a factor of 40 by reducing the RBSB flow rate from 23.2 kg s-1 to 5 kg s-1 . This would significantly reduce the dose rate around pipes in the rest of the cooling circuit.

Figure 37. Neutron flux spectra at the exit of the NBS impacted by different materials (top) and angles (bottom).

<!-- image -->

Figure 38. Biological dose rate map of CER at the beam level before (top) and after (bottom) shielding improvements.

<!-- image -->

3.2.7. Atmosphere activations. Helium is the atmosphere gas for the inner TC, thus it will not cause any activation. However, the air in the gaps between the liner and the RBSBs is highly activated by neutron flux in the range of 10 10 - 10 12 n/cm 2 /s. The gaps are 40 mm between those RBSBs, 80 mm between RBSBs and TC liner, and 150 mm in diameter for the NBT, thus approximately 22.8 m 3 in total volume. These airs are not actively circulated or isolated.

Figure 39. Activity concentration (Bq kg-1 ) in water at RBSB-11 outlet, by radionuclide, for four different RBSB mass flow rates.

<!-- image -->

Figure 40. Air activation in the TC gaps after 1 year (left) and 20 years (right) operations.

<!-- image -->

Activation analysis has been done using FISPACT-II on the air volume considering 1 year and 20 year operations (figure 40), based on neutron fluxes and spectra for those gaps. After 1 year of operations, the total activity is at the level of 5.0 × 10 10 Bq, assuming no circulation. The activity decreases to ∼10% at 1 day cooling with the decay of Ar-41, then is dominated by Ar-37 (35 d), H-3 (12.3 y), and C-14 (5700 y). These long-lived isotopes will increase with more years of operations, resulting in a total of up to 5.0 × 10 11 Bq after 20 years of operations without any circulation, around 10 times more than one year of operation and will decay slowly. Therefore, air leakage and pressure control need to be defined to prevent the activated air from contaminating the room adjacent to the TC, and contamination control is strongly recommended during the maintenance of the RBSBs.

The air activation for the CER is different from TC gaps, due to the ventilation provided for this room. When the neutron shutter is open, neutrons pass through the NBT from the TC to the CER and activate the air inside. Ar-41(1.8 h), which is a β-emitter, is produced from neutron-induced air activation in CER by Ar-40(n, γ)Ar-41 nuclear reaction. The volume estimated in this room is about 2380 m 3 , and an air ventilation rate of 7867 m 3 h-1 is designed. After a conservative assumption of 345 d of opening the NBS for the experiment, the results are estimated in table 5 for the situations of an empty room and a moderator block in place, with and without ventilation. The time for reaching the equilibrium level is 12 h without ventilation, and 80 min with ventilation. The Derived Air Concentration (DAC) value is estimated based on [53] for Ar41. The activity after saturation is at the level of 10 8 Bq without ventilation and around ten times less if ventilation is taken into account.

Table 5. Calculated Ar-41 saturation activities (Bq) in CER.

| Ar-41 saturation activity  Without ventilation With ventilation  [Bq]  DAC  [Bq]  DAC  Moderator block 9.56·10 7  0.88  9.84·10 6  0.09  Empty room  1.32·10 8  1.22  1.36·10 7  0.13   |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

## 3.2.8. Activation and decay gamma sources database.

Two databases have been established for archiving the source terms of activated components. The first one is an activation inventory database which includes tables and graphs on total and specific activities, contact doses, decay heat, dominant isotopes, and other inventories for those highly activated components. Currently, the HFTM, TA, liner, RBSB and shielding plugs in TS, and HEBT scraper in AS have been included. More data can be produced for other components e.g. HPBD, HEBT components, etc. by automation scripts developed based on the FISPACT-II API.

The second database compiles available decay gamma sources produced from the previous calculations on those activated components and aims to be further used in simulations of radioactive waste transport. This can reduce the need for repetitive and time-consuming Rigorous 2-step (R2S) shutdown dose calculations. Currently, the components in TS are mostly covered, with the rest of the data from AS being continuously integrated.

3.2.9. Commissioning using the STUMM. STUMM is a module dedicated to the commissioning Phase 4 [54]. The STUMM will be positioned at the DONES TC exactly at the same position as the HFTMmodule, to measure in advance the radiation field. The main mission is to characterize the neutron source, and radiation conditions in the high flux region, and verify the neutronic calculations. The STUMM module will host in the container region, with in total of 240 detectors included, which are Micro Fission Chambers (MFC with U238 or U235), Ionization Chambers (IC), SPNDs, Thermocouples, Gamma Thermometers (GTs), and Rabbit Systems for activation measurements.

The Neutronics model of STUMM was created using the GEOUNED program based on complex CAD models with detailed diagnostics and structures and was integrated into the TS model. This model has passed the geometry test with less than 1 per million lost particle rates. The neutron flux calculated for STUMM is shown in figure 41. It shows that the maximum fast neutron flux expected in this region is up to 4.4 × 10 14 n/cm 2 /s while photon flux is up to 1.5 × 10 14 p/cm 2 /s. Results for thermal energy neutrons show a rather flat distribution, which is 3.7 × 10 10 n/cm 2 /s in the front area and up to 5.4 × 10 10 n/cm 2 /s in the back area. The total nuclear heating reaches a value of up to 15.4 W cm-3 in the central front region of the container, using the nominal beam profile of 20 × 5 cm 2 .

Energy deposition was calculated for GT and IC. In the case of GT, the nuclear radiation energy is deposited in SS316 steel, whereas in the case of IC in Argon. The maximum energy deposition in the SS316 steel is expected in the front area and is up to 0.639 W g-1 for neutrons, and 0.423 W g-1 for gammas. The maximum expected value of energy deposition in Argon is up to 0.444 W g-1 for neutrons and 0.375 W g-1 for gammas. The responses for the SPNDs and MFCs are to be computed in future work.

<!-- image -->

Figure 41. The spatial distribution of fast (&gt;1 MeV) and thermal neutron (&lt;0.4 eV) fluxes at the STUMM diagnostic region.

<!-- image -->

## 3.3. Nuclear analysis for lithium systems

Lithium systems (LSs) provide a 25 mm-thick and 260 mm wide stable lithium target to stop and remove total beam power of 5 MW, and produce neutrons through d-Li reactions. Figure 42 shows that the LS includes four subsystems: the Target System (TSY), the Heat Removal Loops (HRL), the Impurity Control System (ICS) and the Lithium System Ancillaries.

The TSY provides a concave channel for the Li jet with a high speed of 15 m s-1 , building a free surface and at the same time increasing the Li pressure by centrifugal force to avoid boiling and significant evaporation. The HRL consists of a triple heat removal loops- a lithium-oil loop, an oil-oil loop, and an oil-water loop. The primary lithium loop system located in the Li Loop Cell (LLC) consists of a primary HX, electromagnetic pumps, dump tanks, and hot-leg and cold-leg pipes. The ICS is an indispensable part of the LS, consisting of cold traps (CTs) to remove the radioisotopes 7Be and ACP, hydrogen traps for removing H-3 (12.3 y), and chemical traps for removing other impurities.

Figure 42. Schematic view of the lithium systems. Reproduced from [55]. © 2025 The Author(s). Published by IOP Publishing Ltd on behalf of the IAEA. CC BY 4.0.

<!-- image -->

The neutronics model of the LS is relatively simple compared with the AS and TS, since they are mostly piping and containers. The Li inside is modelled explicitly, in order to define the source.

3.3.1. Radiation source in Li. Be-7 (53.2 d) is a gamma emitter produced from the d-Li interaction through the reactions Li-6(d,n)Be-7 and Li-7(d,2n)Be-7, which are around 15% and 83% respectively [56]. It emits 477 keV gammas in 10.4% of intensity. The production rate of 7 Be 0.75 g/fpy (9.7 × 10 15 Bq/fpy) is estimated in [57], computed using the FZK2005 evaluation. It reaches an equilibrium inventory of 0.15 g (2.0 × 10 15 Bq) after 1 fpy of DONES operation.

Another important source term is Tritium (H-3), which is estimated to be 3.78 g/fpy (1.35 × 10 15 Bq/fpy) in production rate. The main contributions are 80% from d-Li reactions (calculated with the FZK-2005 evaluation) and 20% from nLi reactions. The estimated results using other libraries could be different from these values, as the uncertainties from the evaluations and experimental data are high [58].

Be-7 has a significant impact on radiation safety, and its distribution in the lithium loop in the form of Be3N2 varies with the operating temperature TLi , Nitrogen content CN, mass flow rate QCT of the CT, and trap efficiency η. Currently, the lithium operating condition is optimized to TLi = 300 ◦C, η = 75%, CN = 30 wppm (weight part per million, or 14.85 appm), and QCT = 2% [1, 55], thus a significant amount of Be-7 is deposited in the CT. The rest of Be-7 is dissolved in the Li, which is estimated around 3.25 × 10-5 appm at 300 ◦C in the primary loop, and around 1.07 × 10-7 appm at 190 ◦C and CN = 10 wppm in the impurity control loop based on the calculation in [59].

As for the activated erosion and corrosion products (ACPs), they are estimated from a coupled activation and mass transfer analysis on the primary loop. The dominant radioisotopes of ACPs are summarized through activation analysis, using FISPACT-II on both EUROFER and SS316L. The reaction rates are obtained by collapsing the multigroup cross section of TENDL-2017 with deuteron and neutron flux spectra. In more details, the deuteron reaction rates are computed with a deuteron flux average on the footprint area, and neutron reaction rates are computed in several segments of the lithium loop. These reaction rates are used as an input for mass transfer simulations of ACP, considering the corrosion rate measured from experiments at different rates of flow speed, and the solubilities of those elements in Li under different temperatures. The ACP estimated for different parts of the primary Li loop is shown in table 6.

3.3.2. Radiations in lithium loop cell. The LLC is the room containing the primary lithium loop. Gamma photon emission inside the LLC contributes to the decay of Be-7 and ACPs. The deuterons and the produced neutrons activate the corrosion products circulating in the lithium loop. Each segment of the primary loop, as well as the CT, defines a distinct radiation source characterized by radionuclides dissolved in Li and deposited in walls, structural shielding, and working conditions. The 3.3 × 10-5 appm of Be-7 at 300 ◦C is assumed for the cold leg, and 7.5 × 10-5 appm at 318 ◦C is used for the HX. However, it is found that the contribution of Be-7 to the doses is not significant compared to other radioisotopes from ACP. Radionuclide distributions are determined by mass flow parameters, radionuclide trapping efficiencies, and the applied corrosion model.

To assess the radiological impact, biological dose rates were computed (figure 43), and particles streaming through shielding walls were analysed. For source term construction, a novel CAD-based source modelling tool CAD2CDGS [22] was used to define the source distribution on the Li containers and pipes with different radioisotope concentrations. Within the LLC, biological dose rates near the room walls range from 1 mSv h-1 at the inner boundary to 0.1 Sv h-1 close to the HX. The radiation from this room is mainly contributed by ACP dissolved in Li, as the CT collect the major amount of Be-7 radionuclides. Be-7 is not a main contributor to the dose rates compared to the other radionuclides shown in figure 44, as the contact dose from Be-7 is orders of magnitude lower. Cold leg pipes in the LLC are an important contributor to the dose rates compared to HX, despite lower Li volume, due to weaker shielding and higher concentrations. For the CT, because it is considered that major amounts of the total 0.15 g Be-7 are deposited here, the radiation doses reach 10 Sv h-1 in contact and are larger than 100 mSv h-1 overall in the trap cell. The beam-off dose map is currently under calculation, which requires making proper assumptions about the lithium film attached to the pipe walls. Note that the design of the LLC

Table 6. Activated corrosion products and distributions in the primary Li loop.(Sum. Wall: total amount on component walls, Sum. Li: average concentration in the Li full loop, LiHX: amount in the heat exchanger, CL: amount in the Cold Leg outside TC, CL\_TC: amount in the Cold Leg pipes inside TC). Note that the ICS is not modelled during this simulation.

| Element Sum. Wall [mg] Li avg. mg/kg LiHX [mg]  CL [mg]  CL\_TC [mg]  Fe-55  4.01 × 10-01 8.66 × 10-05  1.66 × 10-01  1.77 × 10-01  5.77 × 10-02  Mn-51  0.00 × 10 00  2.80 × 10-11  0.00 × 10 00  0.00 × 10 00  0.00 × 10 00  Mn-52  0.00 × 10 00  2.05 × 10-07  0.00 × 10 00  0.00 × 10 00  0.00 × 10 00  Mn-52m 0.00 × 10 00  2.43 × 10-10  0.00 × 10 00  0.00 × 10 00  0.00 × 10 00  Mn-54  0.00 × 10 00  3.30 × 10-05  0.00 × 10 00  0.00 × 10 00  0.00 × 10 00  Mn5-6  0.00 × 10 00  9.61 × 10-09  0.00 × 10 00  0.00 × 10 00  0.00 × 10 00  Cr-51  3.19 × 10-03 6.88 × 10-09  2.38 × 10-04  9.54 × 10-04  2.00 × 10-03  Ni-57  0.00 × 10 00  8.47 × 10-08  0.00 × 10 00  0.00 × 10 00  0.00 × 10 00  Co-55  0.00 × 10 00  2.58 × 10-08  0.00 × 10 00  0.00 × 10 00  0.00 × 10 00  Co-56  0.00 × 10 00  2.23 × 10-05  0.00 × 10 00  0.00 × 10 00  0.00 × 10 00  Co-57  0.00 × 10 00  7.13 × 10-05  0.00 × 10 00  0.00 × 10 00  0.00 × 10 00  Co-58  0.00 × 10 00  2.08 × 10-05  0.00 × 10 00  0.00 × 10 00  0.00 × 10 00  Co-58m 0.00 × 10 00  8.20 × 10-08  0.00 × 10 00  0.00 × 10 00  0.00 × 10 00  Co-60  0.00 × 10 00  3.39 × 10-06  0.00 × 10 00  0.00 × 10 00  0.00 × 10 00  Co-60m 0.00 × 10 00  8.33 × 10-11  0.00 × 10 00  0.00 × 10 00  0.00 × 10 00  W-181  3.76 × 10-06 1.61 × 10-12  5.22 × 10-08  0.00 × 10 00  3.86 × 10-07  V-52  0.00 × 10 00  4.59 × 10-12  0.00 × 10 00  0.00 × 10 00  0.00 × 10 00  A-l28  0.00 × 10 00  2.71 × 10-11  0.00 × 10 00  0.00 × 10 00  0.00 × 10 00   |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

and trap cell was recently modified, and the Li volume has been increased, thus the exact dose maps will be renewed, but similar levels of dose rates are expected.

## 3.4. Nuclear analysis for building and plant systems

3.4.1. Main building and the global neutronics model. The neutronics geometry of the main building is used for many applications of confirming the radiological classification, radiation to the workers, handling, transporting and storing the activated components, as well as assessment of public doses contributed via sky-shine and direct exposure. The main building MCNP model was developed on the CAD model released in February 2022, using the CAD tool SpaceClaim for model simplifications, and then SuperMC [60] for MCNP geometry conversions.

Since the neutronics models of AS and TS are created independently from the main building model, the need for a global model for neutron transport simulations was recognized for analysing the radiation cross-talks of different systems. The challenge was addressed by creating a model in which the geometry is divided into space reservations for sub-models, defining them for systems and components with clear boundaries. The sub-models are inserted into the model using the MCNP universe functionality.

The main driving force for the creation of space reservations, in which sub-models can be easily inserted, was the simplicity of the geometry interfaces. In this way, the model is prepared in the SpaceClaim® CAD tool and then converted to MCNP geometry, and adding the new geometry into the space reservations when required. The space reservations in the current global neutronics model are shown in figure 45. Currently, the global neutronics model of the IFMIF-DONES facility, shown in figure 46, consists of approximately 46 000

geometric cells, including sub-models for the accelerator and TSs components. The model is still evolving, and additional sub-models will be added as required.

3.4.2. Sky-shine and direct exposure analyses. Sky-shine and direct exposure to the public is a challenging study required by the regulatory body in assessing the annual doses to the public at the site boundaries. The facility itself is located within the Metropolitan Industrial and Technological Park of Esc´uzar, near Granada, Spain, with other buildings in proximity. The facility, in particular the TC, produces highintensity neutron fluxes and streaming through several penetrations, which will lead to an increase in radiation levels in several areas of the facility. Adequate shielding must therefore be provided in order not to expose on-site personnel. Since the neutron and gamma fields are quite focused, possibilities exist for dose rates to exceed the general population limits of 1 mSv y-1 [61] outside its perimeter.

The analysis was performed using the MCNP6 code with ad-hoc McDelicious code, employing the weight windows mesh (WWM) produced by ADVANTG [23]. Apart from the available tools and data library, a multi-group nuclear data library extending up to 60 MeV was prepared based on the FENDL-3.2b evaluations using the NJOY [62] and TransX [63] to generate ANISN formatted libraries used for ADVANTG. Volumetric, angular and energy distributions of source particles were obtained using source particle track recording functionality and a new fixed source description has been reconstructed for WWM generations. In addition, we utilized the contribute-on field calculations [64], which highlight the importance of the different parts of the phase space in order to obtain the ambient dose equivalent H∗10 [65] at the ground level of the facilities' perimeter. This analysis helped us to establish the required extent of the model towards in the upper direction (towards the sky) at 200 m to consider the entirety of the sky-shine effect.

Figure 43. Dose rate map (Sv h-1 ) during operation in the LLC, provided in XY plane at the middle of Z direction. HX outline is visible at the bottom. The cold trap is located in the top right of the figure.

<!-- image -->

Figure 44. Contact dose rates from 1 kg of Li with Be-7 and ACP inventory dissolved inside. Radionuclide evolution corresponds to the 10 year decay period.

<!-- image -->

Figure 45. Sub-model structure of the global model.

<!-- image -->

Sky-shine radiation is computed together with the direct contribution from the neutron and gamma produced from the target. The highest contribution is found directly behind the outside wall at the beam downstream, where the expected dose rate from neutrons is 0.1 µSv h-1 and the uncertainty below 5% shown in figure 47. The maximum contribution from gammas is in the same order of magnitude, in particular at the beam level shown in figure 48. Shielding is currently being investigated to be placed in those hotspots to reduce exposure. Further refinement on the WWM is foreseen, as well as confirmation calculation using e.g. MC-based variance reduction techniques.

Figure 46. Global MCNP model of the DONES facility created using the sub-model approach.

<!-- image -->

## 3.5. Nuclear analysis for radioactive material treatment

During maintenance, the highly activated HFTM has to be transported entirely from the opened TC. The TS and the inner component in TC are included in the computation of shutdown dose after 1 year of operation. The residual dose maps are shown in figure 49 with an opened TC and transported HFTM in the AC. This results in biological dose rates of 10100 Sv h-1 near the HFTM and 1-10 Sv h-1 from the opened TC at 1 day after shutdown. The gamma doses result in high absorbed doses to the electronics, radiation to neighbouring rooms.

Figure 47. Neutron H∗ 10 ambient dose-rate equivalent (Sv h-1 ) at ground level.

<!-- image -->

Figure 48. Photon H∗ 10 ambient dose-rate equivalent (Sv h-1 ) at the beam level.

<!-- image -->

Figure 49. Shutdown dose rate (µSv h-1 ) during TC opened and HFTM transportation after 345 d of operation and 1 day cooling. Left: considering only the HFTM gamma source, and Right: with contribution from opened TC and HFTM.

<!-- image -->

Due to the HFTM's lifetime limitation, some material samples may need re-irradiation to reach their required accumulated damage doses. These irradiated samples will be encapsulated in new capsules and placed inside a fresh HFTM. A complete post-irradiation process and sample reloading procedure need to be studied, including estimating the decay gamma radiation to define operational procedures. Therefore, the biological dose rate and the absorbed dose rate in silicon induced by the activation of the most irradiated HFTM capsule (Rig 45 indicated in figure 21) for 1 year duration have been obtained. As can be seen from figure 50 at 1 day cooling, the dose rate is close to 1 Sv h-1 at the 0.5 m distance to the sample, which does not decrease significantly. The residual doses of HFTM are dominated by Co-58 (70.8 d) and Mn-54 (312 d), thus the residual doses remain rather strong from one day to one year. This imposes strong requirements for the handling of the radioactive materials samples, as well as the encapsulation of the samples for additional irradiation campaigns.

For the accelerator components during maintenance, to assess the feasibility of allowing personnel and electronic components to remain in rooms and corridors during the transport of the activated HEBT scraper to the waste treatment room, the accumulated biological dose and dose to silicon were computed for the planned transport route. In this study, we take the activated HEBT scrapers after 2 years of operations and compute the accumulated doses after 1 d of shutdown along the transport path from the accelerator vault to the basement storage room scheduled by the logistics design. Total transport time is 25 min.

Figure 50. Biological dose rate (top) and silicon absorbed dose rate (bottom) of irradiated Rig 45 for 1 year and cooling for 1 d and 1 week.

<!-- image -->

These nuclear responses were determined using the D1SUNED code, which enables the calculation of timeintegrated doses from a moving radiation source. This method involves generating an independent file to track the source's trajectory and creating a 'source universe' separate from the 'transport domain universe' within the same file. Firstly, for creating the source, gamma particles are initially sampled in the source universe filled with activated components, transporting the gammas to its boundary. Then, the source universe is transferred to a specific position in the transport domain universe, where it continues to transport. One potential drawback of this approach is, that it may lead to underestimation of the accumulated dose in areas where the source universe travelled. Because the gammas are sampled from the source universe boundary emitting to the outside, the gammas coming back to the source area are underestimated. Furthermore, particles scattered in the transport domain that cross the source path do not interact with the source geometry. This has less impact on the radiation map except in the area where the source travels. To mitigate these effects, the source universe size has to be minimized as much as possible.

The steel container wall thickness is assumed to be 5 mm for biological dose and Si absorbed dose calculations. Doses shown in figure 51 were found between 10 µSv and 400 µSv in rooms along the container path, with adjacent rooms showing values between 0.1 µSv and 10 µSv. For the dose to silicon, revealing doses between 10 µGy and 0.3 mGy along the container path, and between 0.01 µGy and 10 µGy in adjacent rooms. The underestimation of doses along the position of the moving path can be seen from the map, while not affecting the reliability of results in the surrounding. Scaling analysis with 10 mm and 20 mm-thick containers estimates a decrease of biological doses by roughly 20% and 50%. The spatial distributions computed show that the radiation transmission to adjacent rooms is mainly due to the openings between the rooms.

## 4. Developments of tools, data and experiments

## 4.1. Development of tools

In facilities like DONES, a fraction of the beam will be lost in a vacuum pipe and intercepted by scrapers for beam shaping and beam instrumentation, which produce secondary particles and material activation. Computational tools such as MCUNED and D1SUNED allow for assessing the radiation fields in both the beam-on prompt radiations and the beam-on decay gammas transport. As one highlight of recent developments, the MCNUED-Plus [66] has been developed by harmonizing these two simulation codes into one, as an extension of MCNP6, aiming to enhance light ion transport capabilities for prompt radiation evaluation and to include new capabilities for the calculation of residual radiation.

The enhancement of prompt radiation simulation capabilities is achieved by firstly a new variance reduction to bias the production of secondary particles based on the methodology proposed in [67]. Figure 52 shows the acceleration of the convergence speed achieved with this variance reduction. In addition, an improvement in the accuracy of the emission of particles after breakup reactions was used in the methodology proposed in [68]. Figure 53 shows how the new model improvement allows a better agreement of the improved TENDL data with the experimental data, compared with the original TENDL 2021 file.

Figure 51. Accumulated biological doses and silicon absorbed doses along the transport paths.

<!-- image -->

Figure 52. Evolution of the total neutron flux and relative error behind a 10 cm thick copper slab irradiated by a perpendicular 9 MeV deuteron beam, normalized by source particle.

<!-- image -->

Additionally, the srcUNED-Ac module [9] has been developed to provide the MCNP code with the required capabilities to reproduce the secondary radiation sources, without the need to transport the primary deuterons. srcUNED-Ac only launches the secondary particles based on (1) the intensity and orientation of the beam interacting with materials given in an input file, and (2) the double-differential spectra of the secondary particles precompiled into separate files. The precompiled files are obtained with a preliminary calculation where a small object with the desired material is irradiated with a monoenergetic unidirectional beam at the chosen energy figure 54. The irradiated object needs to be thick enough to fully stop the beam, but small enough to minimize the interaction with the emitted particles. The actual size of the object will depend on the material and beam energy. The double differential spectrum of the secondary particles can be tallied, processed and stored in the srcUNED-Ac separated files.

Figure 53. Spectrum of the neutrons emitted at 0◦ during a 40 MeV deuteron irradiation of natural copper compared against experimental data from [69].

<!-- image -->

Figure 54. Illustration of a point source with tally surface and plan segmentations.

<!-- image -->

Figure 54 shows an approximate representation of a test case. A small sphere of niobium (2 mm radius) is irradiated with a collimated and thin beam of 40 MeV deuterons with a total power deposition of 1 W. The neutron flux and the Ambient Dose Equivalent (according to ICRP-74) are computed on a spherical surface of 1 m radius, centred in the origin. The sphere is segmented by 19 parallel planes equally separated similarly to those in figure 54. This allows binning both magnitudes at different emitting angles with respect to the beam direction. Figure 55 shows a comparison of the results obtained with MCNP and srcUNED-Ac. Almost all the results lie within the expected variability of the statistical errors. Some slightly larger errors (4%) are caused by the piece-wise constant methodology of srcUNED-Ac. However, MCNP required 388 min of CPU time to achieve a statistical error lower than 1%, while srcUNED-Ac only required 0.1 min of CPU time. This tool allows quick calculations and flexible source definition along the accelerator, thus being very useful for accelerator analysis with charge particles fully contained in the beam-facing material.

Figure 55. Results for the validation test of srcUNED-Ac versus MCNP code for the test case shown in figure 54.

<!-- image -->

To determine the SDDRs, the R2S method is implemented by UKAEA with the MCR2S code [17]. This involves firstly transporting neutrons with a time-independent calculation using MCNP and tallying their interactions in a mesh throughout the region of interest. Then, the tallied voxels are passed through the time-dependent inventory code, FISPACT-II, which determines the resulting gamma flux caused by the neutron interactions at each chosen time point. Finally, with each voxel as a gamma source term, the produced photons are transported through the area of interest and collected in mesh tallies to produce a radiation map.

Another, more recently developed, process to determine SDDRs is the Novel 1 Step (N1S) method [38]. This approach differs from the R2S procedure as it removes the requirement of a separate inventory calculation and transports the decay photons in the same simulation as the source neutrons, thus allowing it to be conducted with a single MCNP run. To allow N1S to work, MCNP is modified to read in a predefined irradiation schedule and is given time stamps after shutdown to determine the radiation field at that time. Neutrons are sampled from the source and, when they interact with a nucleus during transport, metastable state data along with decay data are read in from the chosen nuclear data library to create time correction factors, i.e. the probability of a photon being emitted at the decay times of interest. The probability is used to weight the photons, which are later transported and tallied with flux mesh tallies to create a radiation map.

Quantitative comparisons have been made between the two methods by producing dose rate maps of the 5th cryomodule in the SRF. For this comparison, one full powered 365 day year irradiation time was assumed, and only a single source definition for this cryomodule was used. A comparison of the fluxes between the two methods is shown in figure 56. The shape of the distribution is consistent for both methods. MCR2S produces higher flux rates than N1S for all values, albeit only with average increases of 5%-8% and overall, less than 15%. This indicates that these two codes provide a consistent prediction of the shutdown doses taking the assumptions.

Figure 56. N1S and MCR2S calculated dose rates after one week of shutdown (along the last cryomodule in figure 10).

<!-- image -->

## 4.2. Nuclear data validations and assessments

4.2.1. Deuteron nuclear data. Starting the discussion from deuteron data, d-Li neutron production is probably the most important foundation that the neutronics analyses rely on. Currently, reference data are FZK-2005 d-Li evaluation [8], which is well validated by several experimental data sets. Recently the deuteron libraries in JENDL/DEU-2020 [31] (included later in the JENDL-5) include Li data produced from DEURACS code [70]. Comparison of their differences with the experiments by Mendoza et al is presented in [71]. The visual comparison of these data is shown in figure 57 for the total neutron yield at different angles, and the neutron spectrum at the forward angle of 0◦ . An uncertainty of roughly 15% is estimated on the energy range of several mega-electronvolts energy range, in which the material damage is relevant for fusion and the DONES environment. The integral simulations on the DONES HFTM and the neutron fluxes and DPA in figure 58 show that, the expected difference is ∼10% for the centre capsules where the samples are mainly placed, while it differs by up to 30%-40% for the lateral capsules, where the DPA level is not attractive. The high discrepancies in these areas are likely due to the difference of 1 MeV neutron energy peak shown in figure 57, where the neutron production from the evaporation process is dominant. In the 1 MeV region, FZK-2005 tends to overestimate experimental values, and results in a higher total neutron yield. Further data evaluations and experimental efforts are still needed to justify the selection of d-Li data and quantify and reduce the uncertainties expected for these key analyses.

The activation cross-section data are crucial for calculating the radioactivity inventories generated in materials under irradiation, thus directly influencing the predicted radiation sources, safety impacts, licensing, decommissioning, and waste management processes.

A brief summary of the deuteron activation is that, firstly strong efforts from the fusion community contributed to the deuteron-induced activation cross sections in the European Activation File (EAF) [72], based on physic model calculations by the TALYS code [28]. The strategy within the EUROfusion consortium is to adopt the TENDL data library as the source data library for activation cross-sections [30]. The TENDL library is also based on automated calculation of the TALYS code, but it considers the latest developments and advanced modelling approaches [73]. Recent comparisons concerning neutron production in deuteron libraries have shown some problems in different TENDL files [74], and the JENDL-5 seem to better fit the trend of the experimental data available [33].

Figure 57. Neutron yields as a function of the emission angle obtained in the irradiation of a thick Li sample using 40 MeV deuterons (left side), and the neutron spectra at the 0◦ forward angle (right side). Reproduced from [71]. © EURATOM 2022. CC BY 4.0.

<!-- image -->

Figure 58. Neutron flux and DPA comparison between the results using FZK-2005 and JENDL/DEU-2020 data, computed by integrating the value in the HFTM over the -4 and +4 cm in the vertical range of the capsules. Reproduced from [71]. © EURATOM 2022. CC BY 4.0.

<!-- image -->

However, JENDL-5 has two main drawbacks for deuteron activation analysis. The first issue is that only nine nuclides (Li-6, Li-7, Be-9, C-12, C-13, Al-27, Cu-63, Cu-65, and Nb-93) are currently available, although more isotopes could be available in the near future. The second issue is, that the JENDL-5 deuteron files present are provided in ENDF6 format, where all the reactions are collapsed in one channel. Normally, these types of files are considered not useful for activation calculations due to the lack of partial reaction cross sections. However, JENDL-5 does provide the reaction product yield per particle interaction, thus the activation cross sections were extracted from the available JENDL-5, and compared against the other available deuteron libraries and experimental information. The comparison for some reactions of interest is shown in figure 59.

The comparison has been carried out for the materials that can be irradiated by deuterons in the current design of the IFMIF-DONES, as well as for new candidate materials that are being considered for different components. The studied materials comprise copper, aluminium, and iron shown in figure 59. EAF is a library based on a previous version of the TALYS code, and it has not been updated for more than a decade. However, it seems that the latest developments in TALYS [73] have not been employed in TENDL releases, so these files feature a relevant underestimation in the production of important long-lived radioisotopes like Zn-65 or Na-22. Finally, JENDL-5 deuteron data library results are promising. But at this moment, the reduced number of isotopes available and the cumbersome procedure to extract the required information imply a limitation on applications.

4.2.2. Neutron cross sections. The IFMIF-DONES facility will generate approximately 13% of neutrons above 14 MeV. This means that while the testing of nuclear data libraries performed for fusion reactors in mind provides important insights, additional testing at higher energies is also required. To this end, FENDL-3.2b was compared with FENDL-3.1d and JEFF-3.3 [76] using two sets of benchmarks.

In the first benchmark, the JADE tool [77] was used to compare the libraries on a simple leakage sphere with a neutron source corresponding to the neutrons from IFMIFDONES. A result of numerical benchmarking with a JADE tool, neutron leakage spectra from a sphere with Fe-56, is shown in figure 60, while figures on other nuclei are skipped.

There are some main findings from benchmarking using a high-energy leakage sphere with JADE. For B-10 and B-11, significant differences were observed above 20 MeV. For the Chromium isotopes, the differences are up to a factor of 1.5 (below 20 MeV) and 0.5 (above 20 MeV) between the JEFF3.3 and both FENDL libraries. The important element Iron is another one that showed different behaviour in all three libraries. The FENDL libraries for Fe-54 generally give higher results for the energy range in question, while for Fe-56 they generally give lower results. The results of simulations with FENDL-3.1d results also show significantly higher results in the energy range between 15 MeV and 20 MeV. The Fe-57 evaluations in FENDL produce higher results for the energy range in question. As for other nuclides from the two FENDL libraries performing identically or very similarly, the differences compared to JEFF-3.3 are significant and should be investigated further. Nuclides that need to be pointed out are Li-6, Li-7, Be-9, Si-28, Ni-58, Ni-60, W-180 and W-183.

The second benchmark consisted of an IFMIF-DONES TS model and results of typical tallies such as neutron spectra, nuclear heating, DPA and total neutron and gamma flux were compared. An example of a comparison between the libraries can be found in figure 61, where typical results at representative locations in the model calculated with FENDL3.1d are compared with the results with FENDL-3.2d.

Figure 59. Comparison of deuteron data libraries against experimental information from the EXFOR [75] database.

<!-- image -->

<!-- image -->

Figure 60. Neutron leakage spectra for Fe-56 calculated with JEFF-3.3 (blue), FENDL-3.1d (orange) and FENDL-3.2b (green) together with 1 sigma statistical uncertainties and ratios between the reference library (JEFF-3.3) and the two tested FENDL libraries. This is an example of a result from a JADE tool.

<!-- image -->

Some of the key findings of the benchmarking results using the IFMIF-DONES neutronics model are summarized. For neutron spectra, the differences in results between the two FENDL libraries and JEFF-3.3 in the energy range in question, i.e. between 10 MeV and 55 MeV, are up to about 10%. Between 15 MeV and 20 MeV, however, the results of FENDL-3.1d deviate considerably from the results of FENDL-3.2b, namely by up to 40%. After examining the results of the leakage sphere, it is suspected that the difference in the 56 Fe nuclear data is the cause. As for the integral results shown in figure 61, depending on the location, the integral nuclear responses between the two FENDL

Figure 61. Ratio of typical nuclear responses calculated with FENDL-3.1d and FENDL-3.2b nuclear data libraries at different representative location in the model. The listed uncertainties are combined 1-sigma statistical uncertainties of the two simulations.

libraries differ by up to 8%. For neutrons, the largest differences in target and HFTM are for nuclear heating, where FENDL-3.2b gives higher results. While for the neutron damage (DPA in EUROFER) calculated under concrete neutron spectra, FENDL-3.1d gives higher results. The differences in gamma flux results are slightly smaller, with the highest difference of 7% in gamma flux in the target and HFTM area. In this case, the results of FENDL-3.2b are higher. These findings provide important hints for neutronics simulation to suggest sufficient safety margins with the uncertainties coming from the nuclear data.

Figure 62. The relative uncertainty of the DPA cross-section in natural Fe for different reaction (MT) numbers as a function of incident neutron energy. KIT evaluation with JEFF-3.3 as base library [3].

<!-- image -->

4.2.3. Uncertainties studies in DPA and gas production. Although the damage doses have been evaluated and discussed through the article, a clear understanding of the uncertainty expected for damage doses is yet to be provided. An assessment of the uncertainties in the calculated values of DPA and gas production in the HFTM due to uncertainties in the nuclear data was attempted.

As shown in figure 62 for the natural Fe, the cross-sections are subject to relatively high uncertainties across all energies for displacement data based on the MD based arc-dpa model (MT = 900) and the NRT model (MT = 901).

To obtain representative values for the relative uncertainties in the calculated DPA values, we took neutron spectra from IFMIF-DONES HFTM, an HFTM of a simplified model of IFMIF-DONES, together with spectra of representative invessel components of the EU-DEMO model [4] with HCPB and WCLL tritium breeding blanket. The uncertainties in the transport cross-sections were neglected, which are much smaller compared to the DPA uncertainties. With this in mind, the relative uncertainties were calculated using these spectra with SANDY [78], a code that generates perturbed files for nuclear data based on covariance matrices and is used to propagate uncertainties using a brute-force method, and RR\_UNC [79], a code based on a first-order deterministic sensitivity analysis. Due to the relatively flat energy dependence of the uncertainty in the DPA cross-sections, the resulting values between the codes and the spectra of HFTM and DEMO blankets (see table 7) do not differ significantly and it can be concluded that, based on the available data, relative uncertainties of about 30% and 23% are expected for the arc-dpa model and NRT model, respectively.

Regarding gas production, however, large discrepancies between the libraries were also found. Since there are no reaction numbers (MT numbers in ENDF-6 format) for the total hydrogen and helium production, the components had to be calculated as sums of the individual contributions. When evaluating uncertainties, it was found that for most nuclear data libraries uncertainties are missing or incomplete for use in IFMIF-DONES. In figure 63. JEFF-3.3 and FENDL-3.1b uncertainties are only given for incident neutron energies up to 20 MeV, for TENDL-2021 uncertainties are given for incident neutron energies up to 30 MeV. As for JENDL-4.0 and ENDF/B-VIII.0 uncertainties are either not given at all or are missing for reactions with large contributions to the total gas production cross-section. This implies that covariance data have to be further developed by the nuclear data communities to further proceed with the uncertainty assessments.

## 4.3. Mock-up experiment of concrete

The objective of this work was to optimize and evaluate structural and shielding concrete for the IFMIF-DONES building. Primarily, magnetite HC design has been assumed to be used in RBSBs and shielding plugs for the TC as a bio-shield and heat-removing layer, and ordinary concrete (OC) will be used in any structure of IFMIF-DONES depending on the neutron shielding efficiency requirements as well.

4.3.1. Concrete development and property measurements. To compare the performance of both types of concrete against radiation, OC for structural concrete and magnetite HC based on pure magnetite aggregate for heavy-weight radiation shielding concrete have been chosen. The reference for concrete materials design was the one used in the ITER project which was designed for shielding purposes [80]. The design of a concrete C40/50 with consistency in a range of S3/S4 according to EN 206 [81] standard was studied. Two types of concrete were designed with the same dosage but varying the aggregates [5]. The OC with limestone-dolomitic aggregates from the area where IFMIF-DONES will be located, and HC with heavy aggregates from the Scandinavian peninsula, based on magnetite. The dosage for 1 meter cubic of OC consisted of 2000 kg of total aggregates, 360 kg of cement, water cement ratio (w/c) of 0.44 and 2.88 kg of superplasticizer, whereas the dosage for HC was generally the same as OC regarding cement and w/c ratio but the aggregates amount raised to 3571 kg and in order to eliminate the segregation possibility, the starch-based viscosity modifying admixture was used as well.

After different trial batches, the final dosage was determined for each type of concrete with very promising and better than the reference ITER concretes of 96.65 MPa and 95.5 MPa of compressive strength for OC and HC respectively (table 8).

Hydrogen content in the concrete, in particular the hydrogen coming from chemically bounded water that maintains relatively good stability, plays a key role in moderating and absorbing the neutrons. The references on chemical (atomic) composition in ITER documentation show the possibility of determination of hydrogen content by two different methods: by measurement in a thermal conductivity detector after sample burning and separation of combustion gases through a chromatographic column (called direct measurement), or by estimation from bound water determined by thermogravimetric analysis (TGA) [82]. The interpretation of results of TGA is sensitive to the temperature range taken for hydrogen content calculation (figure 64). The hydrogen can be estimated either from fixed temperature ranges or based on an intensity signal that is composed of H2O and CO2 emissions. As a result, water and hydrogen content values vary a lot when different temperature ranges are taken. Therefore, such an estimation from TGA has high uncertainty. Therefore the results from the chromatographic column are recommended to be the reference for the next investigations and atomic composition calculation (table 9), as they have been used for ITER and they are close to the previous estimations, assuming that the hydrogen source is the chemically bounded water in amount of 20% in relation to cement mass [76, 83]. The measurement of atomic composition provides important input data for the shielding mock-up experiment in the next step.

Table 7. The relative standard deviations for MD-based arc-dpa model (MT = 900) and the NRT model (MT = 901), for four different representative spectra calculated using two different codes.

| Relative standard deviation (SANDY) Relative standard deviation (RR\_UNC)  Case  MT = 900  MT = 901  MT = 900  MT = 901  Simplified IFMIF-DOENS 31.0%  21.7%  30.2%  23.4%  IFMIF-DONES  31.0%  21.7%  30.2%  23.4%  DEMO HCPB  30.8%  21.6%  29.8%  23.3%  DEMO WCLL  30.6%  22.1%  29.0%  23.2%   |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

Figure 63. The relative uncertainty of the gas production cross section as a function of incident neutron energy for JEFF-3.3 (FENDL-3.1b) and TENDL-2021 ND libraries.

<!-- image -->

Table 8. Technical and mechanical properties and hydrogen content of OC and HC.

| Concrete  OC  HC  Consistency [cm]  17  19  Density [g cm-3 ]  2.55  3.94  Compress. strength 365 d [MPa]  96.65  95.5  Hydrogen content  Chromatographic column  [%]  0.35  0.322  [g cm-3 ]  0.0089  0.0121  TGA  Intensity-based  [%]  0.1  0.24  [g cm-3 ]  0.0025  0.0092  Temperature range  [%]  0.34  0.21  [g cm-3 ]  0.0089  0.0082   |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

4.3.2. Shielding mock-up experiment. To characterize the shielding performance of OC and HC in the DONES TC environment, the neutron source in the NPI ˇReˇz in the Czech Republic was selected for this experiment. The cyclotron U120M accelerates a proton beam up to currents of 15 µA and energies of 35 MeV. The proton beam impinges onto a Be target, producing a continuous neutron spectrum up to 33 MeV

Figure 64. Thermal decomposition profiles by TGA, with total sample mass loss along temperature increase. m/z-atomic mass to atomic number, e.g. for H20 is 18, CO2 is 44. The right axis presents the intensity of emissions of these two gases. Left: ordinary concrete (OC); right: heavy concrete (HC).

<!-- image -->

<!-- image -->

Table 9. Atomic composition of ordinary concrete (OC) and heavy concrete (HC) (weight fraction).

| H  C  O  Na Mg Al  Si  OC 0.0035 0.1029 0.4966 - 0.0987 0.0075 0.0199  HC 0.0030 - 0.2860 0.0018 0.0027 0.0069 0.0257  P  S  Cl K  Ca  Ti  Fe  OC - 0.0107 0.0002 0.0006 0.2416 0.0005 0.0173  HC 0.0045 0.0013 0.0001 0.0017 0.0470 0.0003 0.6190   |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

[84] and flux up to 10 9 n/cm 2 /s at the sample face. The concrete slabs had dimensions of 50 × 50 × 5 cm 3 , forming a mock-up with effective dimensions of 70 × 70 × 100 cm 3 shown in figure 65. The additional slabs surrounding the centre blocks served as shielding and reflectors to reduce neutron leakage and room scattering effects. Fe, Al, Ti, Au and In dosimetry foils were installed in the full depths of the mock-ups to capture neutron fluxes and spectra at different locations. Five foil sets were used in the OC experiment at 0, 25, 50, 75 and 100 cm. For the HC, 8 locations were used for foils: 0, 25, 35, 45, 55, 65, 75 and 90 cm. For both experiments, the irradiations were split into an initial 2 hour irradiation and a subsequent 24 hour irradiation. For the 2 hour irradiation, the easily activated foils such as low/non-threshold reaction foils and foils towards the front of the mock-up were inserted, to avoid too much activation for manual handling and gamma spectrometry saturation after a longer irradiation. The remaining foils were inserted for 24 hour irradiation. The criteria for foils to become sufficiently active was that the dominant gamma decay would give greater than 10 4 gamma spectrometry counts according to calculations, corresponding to a statistical uncertainty on the gamma spectrometry result of 1%.

For simulations, MCNP models of the mock-ups were created from CAD models. The deviations between the model and the experiment for HC, since postprocessing such as polishing, are not considered in the mock-up manufacturing. Also, additional diagnostic holders account for the model deviations. This meant that the allocated positions for the diagnostics in the models did not align with the experiment. The JENDL4.0/HE library was used for proton transport in MCNP6.2, and the FENDL-3.2b library was used for neutron transport.

Figure 65. Shielding mockup design (right) and experiment setup (left).

<!-- image -->

Reaction rate tallies on the foils were included to determine the reaction cross-sections using the IRDFF-II dosimetry library. The neutron spectra and the reaction cross-sections were used in FISPACT-II to calculate the activation of the foils at decay times corresponding to the gamma spectrometry measurements. The C/E results at the front of the mock-ups (0 cm) were consistently low, approximately 0.5. This implied a discrepancy in the source modelling since this position had no effect from neutron attenuation in the mock-up. The proton library was changed to ENDF/B-VII and this gave better C/E agreement at the 0 cm position. The C/E results using ENDF/B-VII are shown in figure 66. Apart from the 0 cm position, the results show discrepancies and particularly over-predictions by the calculations. This implies the concrete provides more neutron shielding than the simulation model. Work is ongoing to improve the accuracy of the C/E results and quantify the sensitivities and uncertainties in the modelling. Ongoing investigation covers modelling the neutron source, neutron transport libraries, geometric modelling of the mock-up and variance reduction.

## 4.4. Neutronics tools validation in LIPAc facility

Another experiment activity was conducted in Rokkasho, Japan. The simulation tools and data applied for DONES design and safety analyses have to be validated in a similar radiation environment. The LIPAc under the European and Japanese collaboration framework Broader Approach phase II is a good candidate to prove that the simulation tools are adequate for future application in DONES. The LIPAc is currently under commissioning with a 125 mA deuterium beam at 5 MeV (RFQ) and 9 MeV (SRF and RFQ), which will produce source neutrons with energies higher than 4 MeV of up to 2.7 × 10 13 n s-1 during 5 MeV beam and 5.4 × 10 14 n s-1 during 9 MeV full beam commissioning through the d-Cu interaction at the BD [85].

For the simulations, the first step was the development of a modular and detailed neutronic model fully based on the engineering CAD model and component material data. The model was developed for commissioning Phase B+ without the SRF module, while the drift line can be easily replaced by the SRF cavities for future phases. Then the neutron and photon fields from different radiation sources of HPBD, the HEBT scraper, the diagnostic plate (DP) and the beam losses at different locations were calculated. Figure 67 shows the total neutron flux due to the main radiation source from the HPBD and due to a secondary source from DP. The total intensity of the neutron flux will be estimated based on the DC in which LIPAc is operating.

Figure 66. The C/E results for the OC (top) and HC experiment (bottom).

<!-- image -->

Figure 67. Total neutron flux (n/cm 2 per incident deuteron) due to the irradiation of the HPBD top) and DP (bottom).

<!-- image -->

For the measurements, A series of activation foils made of Au, In, Ni and Al have been installed to measure the production of radioisotopes at key locations of LIPAc shown in figure 67. The foils took into account the reactions of different neutron energies for reactions Al-27(n,α)Na-24, Ni-58(n,p)Co-58, In-115(n,n′ )In-115 m, and Au-197(n,γ)Au198. Currently, the measurement for commissioning at 0.1%

DC operated during March 2024 is done, and the postirradiation analysis is still ongoing.

## 5. Summary and discussions

In this work, various aspects of IFMIF-DONES neutronics are discussed, covering nuclear analyses performed on key DONES systems in recent years, the tools and nuclear data used, and the experiments that support the validation of these tools and data.

For the accelerator system, biological and absorbed doses were calculated during three commissioning phases, as well as during regular operations and maintenance, focusing on different components of the accelerator. This analysis was based on a detailed MCNP model converted from CAD geometries. Assumptions regarding beam losses and depositions, which generate several secondary sources, are discussed, particularly for the Injector, RFQ, MEBT, SRF, and HEBT, which contain critical components such as HPBD and scrapers. Critical radionuclides were analysed to explain the behaviour of residual doses over time. Radiation contributions from the TC through beam ducts, and radiation to neighbouring cells through waveguide and HVAC penetrations, were assessed and included in radiation cross-talk analyses. The lifetime of sensitive components, such as the FSIV in the RIR and the mirror in the IVVS in the TIR, was estimated based on specific absorbed doses in those materials. The activation of structural components, cooling water, and atmospheric gases was also analysed to address needs for maintenance, waste management, and contamination control.

For the TS, including the target system, the entire simulation geometry was built on modularized components and assemblies. Neutron and gamma fluxes, radiation damage, and gas production in the HFTM, as well as nuclear heating, are presented for both the nominal beam size (20 × 5 cm 2 ) and a reduced beam size (10 × 5 cm 2 ). Beam power depositions in the target and the consequent heat distribution within the TC are summarized. Given the intense neutron field produced and shielded within the TC, heating maps, DPA, and gas production in the TC shielding are presented, with a focus on radiation effects on neighbouring cells such as the AC above, the LLC below, and the CER at beam downstream. Water activation in designing TC auxiliaries is evaluated, and air activation in the TC gaps is also considered. STUMM, a key component in the final commissioning phase, has been modelled and analysed.

For other systems, such as the LSs and building plant systems, activated products and decay represent the main source terms. Be-7 and ACP inventories are presented for current lithium loop operations, with a focus on resulting dose maps in the LLC. Activated components and decay gamma doses during maintenance and waste handling phases are calculated for HEBT scrapers, the TC, the HFTM, and its samples. These analyses are based on the main building geometries with updated designs, recently integrated with the accelerator and TS to form a global neutronics model of DONES.

These analyses are supported by a comprehensive set of tools that allows simulations on various particles, systems, and facility phases. Recently developed tools tailored for DONES needs include MCUNED-plus, srcUNED-AC, and N1S for deuteron transport and residual dose simulations. Nuclear data evaluation, especially for deuteron data based on TENDL and JENDL, neutron cross-sections from FENDL, and DPA and gas production data, is also critical, with an emphasis on consistency with experimental data, cross-comparisons of different evaluations, and uncertainty analysis. Experimental benchmarks focus on shielding mock-up experiments and neutronics validation activities in the LIPAc facility, providing potential validation for material shielding, simulation accuracy, and radiation protection assessments with radiation fields similar to those in DONES.

Important notes for future activities are that, although the activities are covered in many aspects of DONES neutronics, there are still some open points for further progress. Key points include refining accelerator system simulations, which currently rely on conservative assumptions for beam losses, as accurate loss values and source distribution remain challenging to incorporate. Additionally, residual dose uncertainties remain high due to deuteron activation data uncertainties, which may improve with TENDL updates for DONESspecific deuteron activation. Further work is needed on penetrations and corresponding radiation streaming analyses. For the TS, key aspects of material irradiation depend on uncertainties in nuclear data, particularly d-Li neutron yield and neutron displacement cross-sections. The consequential impact on d-Li activation, especially Be-7 and tritium inventories, is also critical for the radiation and contamination in the lithium loop. Recently, d-Li experiments on measuring the Be-7 and Tritium production are under active preparation. To characterize material damage in the HFTM, neutron diagnostics during operations and cumulative dose measurements on samples remain open points. Given SPND limitations, methods like activation foils and indirect approaches for estimating neutron fluence on specimens are under discussion.

For the assessment of ACP in lithium by neutron and deuteron, not only nuclear data but also mass transfer studies is important, as impurity control systems are yet to be integrated in the ACP assessment. These results will impact radiation dose assessments in LS rooms and will need reassessment if source inventories change. For waste management dose analysis, case-dependent analyses are needed, such as HFTM sample extractions. Direct exposure and sky-shine from the DONES facilities are studied with sources from the TS, while source contributions from accelerator systems remain to be addressed. In summary, further validation of codes, improvements in nuclear data, and relevant experimental support are key aspects requiring active preparation in the upcoming phase of the project.

## Acknowledgment

This work has been carried out within the framework of the EUROfusion Consortium, funded by the European Union via the Euratom Research and Training Programme (Grant Agreement No 101052200-EUROfusion). Views and opinions expressed are however those of the author(s) only and do not necessarily reflect those of the European Union or the European Commission. Neither the European Union nor the European Commission can be held responsible for them.

We gratefully acknowledge Poland's high-performance computing infrastructure PLGrid (HPC Centers: ACK Cyfronet AGH) for providing computer facilities and support within computational Grant Nos. PLG/2023/016742 and PLG/2023/016338.

This scientific paper has been published as part of the international project co-financed by the Polish Ministry of Science and Higher Education within the programme called 'PMW' for 2024.

This work has been also supported by the European Union's FEDER program, IFMIF-DONES Junta de Andalucia's program at the Universidad de Granada and by MCIN/AEI/10.13039/501100011033/FEDER, UE (PID2022137543NB-I00).

We acknowledge support from the KIT-Publication Fund of the Karlsruhe Institute of Technology.

## ORCID iDs

- B. Bie´nkowska  https://orcid.org/0000-0003-1103-3441 H. Chohan  https://orcid.org/0000-0001-6412-0528 A.J. Lopez-Revelles  https://orcid.org/0000-0001-7952-
2. [2829](https://orcid.org/0000-0001-7952-2829)
- F. [Mota  https://orcid.org/0000-0002-1337-2482](https://orcid.org/0000-0002-1337-2482)
- T. [Piotrowski  https://orcid.org/0000-0002-2547-7601](https://orcid.org/0000-0002-2547-7601)
- A. [Serikov  https://orcid.org/0000-0003-2053-7879](https://orcid.org/0000-0003-2053-7879)
- G. [Stankunas  https://orcid.org/0000-0002-4996-4834](https://orcid.org/0000-0002-4996-4834)
- A. [Tidikas  https://orcid.org/0000-0002-4008-7310](https://orcid.org/0000-0002-4008-7310)
- G. [Tracz  https://orcid.org/0000-0003-0384-480X](https://orcid.org/0000-0003-0384-480X)
- D. [Jimenez-Reyhttps://orcid.org/0000-0003-1559-2179](https://orcid.org/0000-0003-1559-2179)
- E. [Mendoza  https://orcid.org/0000-0002-2843-1801](https://orcid.org/0000-0002-2843-1801)
- J. [Malec  https://orcid.org/0000-0002-9322-8631](https://orcid.org/0000-0002-9322-8631)

## References

- [1] Królas W. et al 2021 The IFMIF-DONES fusion oriented neutron source: evolution of the design Nucl. Fusion 61 125002
- [2] Simakov S.P., Fischer U., Kondo K. and Pereslavtsev P. 2012 Status of the McDeLicious approach for the D-Li neutron source termmodeling in ifmif neutronics calculations Fusion Sci. Technol. 62 233-9
- [3] Fischer U., Bienkowska B., Drozdowicz K., Frisoni M., Mota F., Ogando F., Qiu Y., Stankunas G. and Tracz G. 2019 Neutronics of the IFMIF-DONES irradiation facility Fusion Eng. Des. 146 1276-81
- [4] Qiu Y., Arbeiter F., Fischer U. and Schwab F. 2018 IFMIF-DONES HFTM neutronics modeling and nuclear response analyses Nucl. Mater. Energy 15 185-9
- [5] Qiu Y. et al 2024 Overview of recent advancements in IFMIF-DONES neutronics activities Fusion Eng. Des. 201 114242

- [6] Sauvan P., Sanz J. and Ogando F. 2010 New capabilities for Monte Carlo simulation of deuteron transport and secondary products generation Nucl. Instrum. Methods Phys. Res. A 614 323-30
- [7] Werner C.J. 2017 MCNP users manual-code version 6.2 Report la-UR-17-2998 Los Alamos National Laboratory
- [8] Pereslavtsev P., Fischer U., Simakov S. and Avrigeanu M. 2008 Evaluation of d +6,7Li data for deuteron incident energies up to 50 MeV Nucl. Instrum. Methods Phys. Res. B 266 3501-12
- [9] Ogando F. 2022 Advanced Monte-Carlo method for prompt and residual radiation calculations in light-ion accelerators SATIF-15: 15th workshop on Shielding aspects of Accelerators, Targets, and Irradiation Facilities (SATIF) (East Lansing, Michigan, USA, 20-23 September 2022)
- [10] Lu L., Qiu Y. and Fischer U. 2016 Improved solid decomposition algorithms for the CAD-to-MC conversion tool McCad Fusion Eng. Des. 124 1269-72
- [11] Wu Y., Song J., Zheng H., Sun G., Hao L., Long P. and Hu L. 2015 CAD-based Monte Carlo program for integrated simulation of nuclear system SuperMC Ann. Nucl. Energy 82 161-8
- [12] Catalán J.P., Sauvan P., García J., Alguacil J., Ogando F. and Sanz J. 2024 GEOUNED: a new conversion tool from CAD to Monte Carlo geometry Nucl. Eng. Technol. 56 2404-11
- [13] Travleev A. Numjuggler (available at: https://github.com/inrkit/numjuggler)
- [14] Sublet J.-C., Eastwood J.W., Morgan J.G., Gilbert M.R., Fleming M. and Arter W. 2017 FISPACT-II: an advanced simulation system for activation, transmutation and material modelling Nucl. Data Sheets 139 77-137
- [15] Sanz J., Cabellos O. and García-Herranz N. 2008 ACAB Inventory code for nuclear applications: user's manual V. 2008 NEA-1839/01
- [16] Bailey G., Foster D., Kanth P. and Gilbert M. 2021 The FISPACT-II user manual Culham Cent. Fusion Energy (CCFE), Culham, UK, Tech. Rep. UKAEA-CCFE-RE vol 2
- [17] Eade T., Colling B., Naish J., Packer L.W. and Valentine A. 2020 Shutdown dose rate benchmarking using modern particle transport codes Nucl. Fusion 60 056024
- [18] Travleev A., "R2Smesh-at: implementation of R2S method for SDDR (available at: https://github.com/travleev/r2smesh-at)
- [19] Sauvan P., Catalán J.P., Ogando F., Juárez R. and Sanz J. 2016 Development of the R2SUNED code system for shutdown dose rate calculations IEEE Trans. Nucl. Sci. 63 375-84
- [20] Lopez V., Sauvan P. and Ogando F. 2021 Shutdown dose rates calculations due to light ions induced activation using D1S methodology Fusion Eng. Des. 167 112298
- [21] Berry T.A., Nobs C.R., Dubas A., Worrall R., Eade T., Naish J. and Packer L.W. 2021 Integration of fluid dynamics into activation calculations for fusion Fusion Eng. Des. 173 112894
- [22] García J., Qiu Y. and Torregrosa-Martín C. 2024 Development of radiation sources based on CAD models for the nuclear analysis of IFMIF-DONES lithium loop Fusion Eng. Des. 202 114360
- [23] Mosher S.W. et al 2015 ADVANTG: An Automated Variance Reduction Parameter Generator
- [24] Zheng Y., Qiu Y., Lu P., Chen Y., Fischer U. and Liu S. 2022 Improvements of the on-the-fly MC variance reduction technique with dynamic WW upper bounds Nucl. Fusion 62 086036
- [25] Schnabel G. et al 2024 FENDL: a library for fusion research and applications Nucl. Data Sheets 193 1-78
- [26] "FENDL-3.1d: fusion evaluated nuclear data library Ver.3.1d (available at: www-nds.iaea.org/fendl31d/)
- [27] Koning A.J., Rochman D., Sublet J.C., Dzysiuk N., Fleming M. and van der Marck S. 2019 TENDL: complete
23. nuclear data library for innovative nuclear science and technology Nucl. Data Sheets 155 1-55
- [28] Koning A.J., Duijvestijn M.C. and Hilaire S. 2008 TALYS-1.0. EDP Sciences (available at: http://inis.iaea.org/search/ search.aspx?orig\_q=RN:41034220)
- [29] Konobeyev A.Y., Fischer U. and Pereslavtsev P.E. 2015 Evaluation of advanced displacement crosssections for the major EUROFER constituents based on an atomistic modelling approach Kerntechnik 80 7-12
- [30] Fischer U. et al 2020 Nuclear data activities of the EUROfusion consortium EPJ Web Conf. 239 21001
- [31] Nakayama S., Iwamoto O., Watanabe Y. and Ogata K. 2021 JENDL/DEU-2020: deuteron nuclear data library for design studies of accelerator-based neutron sources J. Nucl. Sci. Technol. 58 805-21
- [32] Iwamoto O. et al 2023 Japanese evaluated nuclear data library version 5: JENDL-5 J. Nucl. Sci. Technol. 60 1-60
- [33] Lopez V., Ogando F. and Sauvan P. 2023 Sensitivity to nuclear data of the design of the IFMIF-DONES beam dump Front. Phys. 11 1144057
- [34] Podadera I. 2021 et al The accelerator system of IFMIF-DONES multi-MW facility 12th Int. Particle Accelerator Conf. (IPAC 2021) (Foz do Iguaçu, Brazil., 24-28 May 2021) pp 2-5
- [35] Kondo K., Narita T., Usami H., Takahashi H., Ochiai K., Shinto K., Kasugai A. and Okumura Y. 2016 Neutron production and dose rate in the IFMIF/EVEDA LIPAc injector beam commissioning Fusion Eng. Des. 109-111 1104-8
- [36] Ferrari M., Senajova D., Kershaw K., Perillo Marcone A. and Calviani M. 2021 Selection of radiation tolerant commercial greases for high-radiation areas at CERN: methodology and applications Nucl. Mater. Energy 29 101088
- [37] Berry T. et al 2023 Recent nuclear analysis of the IFMIF-DONES phase 2 commissioning accelerator and MEBT Proc. IEEE Symp. on Fusion Engineering (SOFE) (Oxford, United Kingdom, 9-13 July)
- [38] Eade T., Bradnam S.C. and Kanth P. 2022 A new novel-1-step shutdown dose rate method combining benefits from the rigorous-2-step and direct-1-step methods Fusion Eng. Des. 181 113213
- [39] Neri C., Costa P., Ferri De Collibus M., Florean M., Mugnaini G., Pillon M., Pollastrone F. and Rossi P. 2011 Iter in vessel viewing system design and assessment activities Fusion Eng. Des. 86 1954-7
- [40] Belous V., Kalinin G., Lorenzetto P. and Velikopolskiy S. 1998 Assessment of the corrosion behaviour of structural materials in the water coolant of ITER J. Nucl. Mater. 258-263 351-6
- [41] Ohta M., Kwon S., Sato S., Ochiai K. and Suzuki H. 2019 Analysis of radionuclidic purity of medical isotope production with d-Li neutron in A-FNS Fusion Eng. Des. 146 207-11
- [42] Podadera I. et al 2024 Update of the 5 MW beam-on-target requirements for improvement of the materials irradiation performance at IFMIF-DONES Nucl. Mater. Energy 40 101691
- [43] Serikov A., Qiu Y. and Gordeev S. 2023 Nuclear analyses for the TC with the double layer RBSB concept (https://doi.org/ 10.21955/nuclscitechnolopenres.1115090.1)
- [44] ´Alvarez I. et al 2025 Comparative analysis of neutronic features for various specimen payload configurations within the IFMIF-DONES HFTM Fusion Eng. Des. 210 114729
- [45] Serrano M., Hernández R., Plaza D., Mu˜ noz A., Castellanos J. and Molla J. 2021 Assessment of SSTT Technology (available at: https://idm.euro-fusion.org/default. aspx?uid=2MLMCM)
- [46] Klix A., Arbeiter F., Majerle M., Qiu Y. and ˇStefánik M. 2019 Measurement of neutron fluence in the high-flux test

- module of the early neutron source by neutron activation Fusion Eng. Des. 146 1258-61
- [47] Raj P., Angelone M., Fischer U. and Klix A. 2018 Computational study of a chromium self-powered detector for neutron flux monitoring in the test blanket module of ITER Nucl. Instrum. Methods Phys. Res. A 908 10-17
- [48] Pampin R. and O'brien M.H. 2008 Analysis of near-term fusion power plant designs from the material management stance Fusion Eng. Des. 83 1419-23
- [49] Morishima Y., Koshiishi M., Kashiwakura K., Hashimoto T. and Kawano S. 2004 Re-weldability of neutron irradiated Type 304 and 316L stainless steels J. Nucl. Mater. 329 663-7
- [50] Vandergriff K.U. 1990 Designing equipment for use in gamma radiation environments (https://doi.org/10.2172/814580)
- [51] Qiu Y., Arbeiter F., Fischer U. and Tian K. 2019 Neutronics analyses for the bio-shield and liners of the IFMIF-DONES test cell Fusion Eng. Des. 146 723-7
- [52] Qiu Y. and Fischer U. 2020 Shutdown dose calculations for the IFMIF-DONES lithium loop cell using variance reduction techniques Fusion Eng. Des. 155 111508
- [53] Petoussi-Henss N. et al 2020 ICRP publication 144: dose coefficients for external exposures to environmental sources Ann. ICRP 49 11-145
- [54] Wiacek U., Curyło M., Gaba´nska B., Gierlik M., Igielski A., Kwiatkowski R., Prokopowicz R., Pytel K., Tarchalski M. and Zychor I. 2017 STUMM-Test module for a high intensity neutron stripping source Acta Phys. Pol. B 48 687-93
- [55] Nitti F.S., Maestre J., Dezsi T., Gordeev S., Holstein N., Brenneis B., Buligins L., Molla J. and Ibarra ´A. 2025 The lithium systems of the IFMIF-DONES facility Nucl. Fusion 65 122004
- [56] Frisoni M., Bernardi D. and Nitti F.S. 2020 Nuclear assessment of the IFMIF-DONES lithium target system Fusion Eng. Des. 157 111658
- [57] Simakov S.P., Fischer U. and Von Möllendorff U. 2004 Assessment of the 3 H and 7 Be generation in the IFMIF lithium loop J. Nucl. Mater. 329 213-7
- [58] Simakov S.P., Fischer U. and Konobeyev A.Y. 2020 Status and benchmarking of the deuteron induced tritium and beryllium-7 production cross sections in Lithium KIT Sci. Work. Pap 147
- [59] Ida M., Nakamura H. and Sugimoto M. 2007 Estimation and control of beryllium-7 behavior in liquid lithium loop of IFMIF Fusion Eng. Des. 82 2490-6
- [60] Wu Y. 2018 Multifunctional neutronics calculation methodology and program for nuclear design and radiation safety evaluation Fusion Sci. Technol. 74 321-9
- [61] RD783 2001 REAL DECRETO 783/2001, de 6 de julio, por el que se aprueba el Reglamento sobre protección sanitaria contra radiaciones ionizantes
- [62] Macfarlane R., Muir D.W., Boicourt R.M., Kahler Albert Comstock I.I.I. and Conlin J.L. 2017 The NJOY nuclear data processing system, version 2016 (https://doi.org/ 10.2172/1338791)
- [63] MacFarlane R.E. 1992 TRANSX 2: A Code for Interfacing Matxs Cross Sections Libraries to Nuclear Transport Code (Los Alamos National Laboratory)
- [64] Williams M.L. 1991 Generalized contributon response theory Nucl. Sci. Eng. 108 355-83
- [65] Brenner D.J. 2024 Reviewed work: conversion coefficients for use in radiological protection against external radiation by international commission on radiation units and measurements Radiat. Res. 151 509-10
- [66] Lopez V., Sauvan P., Sanz J. and Ogando F. 2024 New developments in the MCUNED-Plus code for radiation transport and coupled transport-activation computational simulations in accelerator-based facilities Fusion Eng. Des. 205 114565
- [67] Fensin M.L. and James M.R. 2016 Biasing secondary particle interaction physics and production in MCNP6 Ann. Nucl. Energy 94 618-25
- [68] Sauvan P. et al 2017 Implementation of a new energy-angular distribution of particles emitted by deuteron induced nuclear reaction in transport simulations EPJ Web Conf. 146 02010
- [69] Schweimer G.W. 1967 Fast neutron production with 54 MeV deuterons Nucl. Phys. A 100 537-44
- [70] Nakayama S. et al 2017 Development of a code system DEURACS for theoretical analysis and prediction of deuteron-induced reactions EPJ Web Conf. 146 100-3
- [71] Mendoza E., Cano-Ott D., Ibarra A., Mota F., Podadera I., Qiu Y. and Simakov S.P. 2022 Nuclear data libraries for IFMIF-DONES neutronic calculations Nucl. Fusion 62 106026
- [72] Sublet J.-C., Packer L.W., Kopecky J., Forrest R.A., Koning A.J. and Rochman D.A. 2010 The European activation file: EAF-2010 neutron-induced cross section library CCFE-R(10) 05
- [73] Avrigeanu M., Rochman D., Koning A.J., Fischer U., Leichtle D., Costache C. and Avrigeanu V. 2022 Advanced breakup-nucleon enhancement of deuteron-induced reaction cross sections Eur. Phys. J. A 58 1-13
- [74] Kwon S., Konno C., Ohta M. and Sato S. 2022 Problems on neutron production data of Be-9 in TENDL-2017 and -2019 deuteron sub-libraries Ann. Nucl. Energy 169 108932
- [75] Zerkin V.V. and Pritychenko B. 2018 The experimental nuclear reaction data (EXFOR): extended computer database and web retrieval system Nucl. Instrum. Methods Phys. Res. A 888 31-43
- [76] Plompen A.J.M. et al 2020 The joint evaluated fission and fusion nuclear data library, JEFF-3.3 Eur. Phys. J. A 56 1-108
- [77] Laghi D., Fabbri M., La Rovere S., Isolan L., Pampin R., Portone A. and Sumini M. 2023 Status of JADE, an open-source software for nuclear data libraries V&amp;V Fusion Eng. Des. 187 113380
- [78] Fiorito L., ˇZerovnik G., Stankovskiy A., Van den Eynde G. and Labeau P.E. 2017 Nuclear data uncertainty propagation to integral responses using SANDY Ann. Nucl. Energy 101 359-66
- [79] Trkov A. 2001 Program RR\_UNC-calculates uncertainties in reaction rates and cross sections (available at: www-nds. iaea.org/IRDFF/)
- [80] Barabash V. Recommended chemical composition of ordinary concrete, heavy concrete and heavy borated concrete for nuclear analysis 2019 (On ITER IDM(ITER\_D\_UJ4F5B v0.2)
- [81] EN 206:2013+A2:2021: concrete-Specification, performance, production and conformity 2021
- [82] Piotrowski T. et al 2024 Optimization and evaluation of structural and shielding concrete for IFMIF-DONES Nucl. Mater. Energy 38 101597
- [83] Ibarra A. et al 2019 The European approach to the fusion-like neutron source: the IFMIF-DONES project Nucl. Fusion 59 065002
- [84] Majerle M. et al 2023 Measurements of the neutron spectra from the p+Be neutron generator of the NPI CAS Nucl. Instrum. Methods Phys. Res. A 1053 168314
- [85] Bra˜ nas B. et al 2018 The LIPAc beam dump Fusion Eng. Des. 127 127-38