## Abstract

The IFMIF-DONES facility located at Escúzar in Spain will consist of an accelerator delivering 125 mA of 40 MeV deuterons onto a Lithium target. At the last part of the accelerator, when the beam footprint is almost shaped, different beam diagnostics are considered. In order to protect the machine against changes of the beam and give a safe interlock, a novel RF pickup made of eight electrodes is designed. This RF pickup is designed with the objective to sense displacements of the beam centroid as changes of the beam profile. In this paper a preliminary study is presented based on an analytical and CST simulation approaches. Both are compared considering pencil and real beams from TraceWin simulations. A sensitivity study of how different parameters affect the response is performed in CST simulations.

## INTRODUCTION

The IFMIF-DONES facility will be built on Escúzar site at Granada in Spain [1]. The objective of the facility is testing materials for the future nuclear fusion reactors as DEMO. For that, the facility will consist of a superconducting linear accelerator that accelerates a deuteron beam of 125 mA up to 40 MeV. These deuterons will impact onto a lithium target, producing a neutron flux of 10 15 n/cm 2 ·s. The damage produced by this neutron spectrum will simulate the irradiation conditions in fusion reactors.

In this study, we are concerned about measuring the beam properties at the target, when the beam impacts on the lithium target. The shape and the temporal distribution of a single bunch obtained in TraceWin simulations are shown in Fig. 1. The beam has a rectangular shape to meet the requirements at the lithium target [2].

Several diagnostics are considered at this point. First, an optical method capable of measuring the light produced when the deuteron beam moves into the liquid lithium surface (OTR and Fluorescence). While this method is useful to have a direct measurement of the beam profile, it has a slow response time (less than ms), due to the necessity of integrating the low signal. A second diagnostic is proposed, based on the RF pickup technology, in order to measure deviations of the beam centre and the beam profile. This RF pickup does not provide a direct measurement of the beam profile, but the response velocity is very fast (~10-100 μs), and it could be used to send an interlock signal.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

* This work has been carried out partly within the framework of the EUROfusion Consortium (Grant Agreement No 101052200 - EUROfusion), funded by the European Union via the Euratom Research and Training Programme, and also by the Regional Andalousian Government under the project TECHAC (ProyExcel\_00989).

## STUDY OF A NOVEL EIGHT ELECTRODES RF PICKUP*

J. Herranz, A. Ortega, I. Podadera, IFMIF-DONES España, Granada, Spain J. F. Valenzuela-Valdés, UGR, Granada, Spain C. Oliver, CIEMAT, Madrid, Spain

Figure 1: (Top) Beam profile at the end of IFMIF-DONES HEBT simulated with TraceWin [3]. (Bottom) Time evolution of a single bunch at the end of HEBT.

<!-- image -->

Figure 2: Design of an eight electrodes RF Pickup.

<!-- image -->

As shown in Fig. 1, the beam shape is not gaussian but rectangular. In order to accommodate the antennas to this shape, an eight electrodes RF pickup is designed to increase the number of symmetry planes (Fig. 2).

## THEORETICAL APPROACH

Considering a pencil beam in a circular beam pipe of radius b and solving the Laplace equation [4], it can be obtained the wall current density of each harmonic n of an angular frequency w0 induced at a position 𝛼 of the circular inner wall by a beam positioned at a polar position (𝑟, 𝜃). The expression of the beam wall current density for a certain harmonic 𝑖௪,௡ is [5]:

<!-- formula-not-decoded -->

where 𝐼௠ are the modified Bessel function of first kind of order m, 𝐴௡ the harmonic amplitude factor and

<!-- formula-not-decoded -->

being 𝛽𝑐 the velocity of the particles and 𝛾 the Lorentz contraction factor.

Integrating Eq. (1) over the limits of the RF pickup electrodes of angular with 𝜙, the image current at a frequency 𝜔 = 𝑛𝜔଴/2𝜋 of an electrode placed at 𝜙଴ is:

<!-- formula-not-decoded -->

## Real Beam Shape

In the previous theoretical approach, a pencil beam has been considered. A more realistic approach can be obtained by considering many particles distributed as the real beam shape. Each particle i, is thus considered to be a pencil beam positioned at (𝑟௜, 𝜃௜), leading to an induced intensity 𝐼௪,௜ with similar expression to Eq. (3), only changing the average intensity. The total induced intensity at a certain frequency 𝐼ௐ,௥௘௔௟ is then:

<!-- formula-not-decoded -->

## CST SIMULATION

An RF pickup is modelled in CST particle Studio [6]. The RF pickups is made of eight stripline electrodes uniformly distributed along the beam pipe. The material used for the electrodes is PEC (Perfectly Electric Conducting). The electrodes parameters are summarised in Table 1. The solver used is PIC solver, which is able to accept real beams as input.

Table 1: Parameters CST Simulation

| Parameter  Value  Stripline length  120 mm  Angular coverage  30°  Electrode thickness  5 mm  Outer radius  145 mm  Pipe radius  125 mm   |
|-------------------------------------------------------------------------------------------------------------------------------------------|

## COMPARISON

The figure of merit to compare theory and simulations will be the dB ratio between opposite electrodes:

<!-- formula-not-decoded -->

It will be calculated for different displacements of the beam in the horizontal axis. Four cases are considered:

-  Real beam (Theory): Using Eq. (4), and the positions (𝑟௜, 𝜃௜) given by the real beam input (Fig. 1, top picture). Displacements are obtained by applying the operator (𝑥, 𝑦) → (𝑥 +𝛿, 𝑦) to all the particles, being 𝛿 the displacement in mm.
-  Pencil beam (Theory): Using Eq. (3) to obtain the induced intensity. The parameters used are summarised in Table 2.
-  Pencil beam (CST): Using PIC solver simulator and a circular source with very low radius. Ten bunches separated T and with temporal width σ, given by Table 2.
-  Real beam (CST): Using PIC solver simulator and the real beam input (Fig. 1, top picture) as source. Ten bunches like the real bunch shape (Fig. 1, bottom picture) separated T time are simulated. Displacements are obtained by applying the operator (𝑥, 𝑦) → (𝑥 +𝛿, 𝑦) to all the particles, being 𝛿 the displacement in mm.

Table 2: Parameters Values for Calculations

| Parameter  Value  〈𝐼௕ 〉  125 mA  𝑓 = 1/𝑇  175 MHz  𝜎  3 ns  𝑒஽௘௨௧௘௥௢௡  1.6 · 10ିଵ଺ C  𝑁ଵ௕௨௡௖௛  4.46 · 10ଽ  𝛽  0.203  𝜙  30°   |
|--------------------------------------------------------------------------------------------------------------------------------|

Figure 3 shows the voltage monitors readings for CST. The voltage reading is in de order of 1 V. The comparison of CST and theory is shown in Fig. 4. It can be concluded that the four cases give similar results.

Figure 3: Voltage monitors readings in V for Real Beam (CST), δ = 0 mm.

<!-- image -->

<!-- image -->

Figure 4: Comparison between theory and CST. FOM dB ratio between left (H-) and right (H+) electrode, slope (sensitivity) and intercept at 0 are shown.

In the range observed, 0-20 mm shift, the linearity is conserved in all the cases and harmonics. For further displacement, the linearity is expected to be lost [7]. As theory predicts, the sensitivity increases as the harmonic frequency increases [8], and this can be observed in the four cases. Even though some differences are appreciable, sensitivities follow the same trends and have comparable values. The theory sensitivities are expected to match with simulations if an effective radius is used. There is an issue detected with the sensitivity of the Real beam (CST) at 525 MHz, as it gives a too high value in comparison with the rest of the trends. Regarding the intercept at zero position, the response of the figure of merit should be 0 dB as both electrodes measure the same intensity, being the beam symmetric. However, in the case of Real beam (CST), it is observed that for frequencies 350 MHz and 525 MHz, the intercept is at 2 dB and 4 dB respectively, while in 175 MHz the intercept is almost at 0. This phenomena comes from the simulation settings and does not correspond with real behaviour, as the intercept should be 0. A possible reason may be the mesh dimensions used for the simulation. Furthermore, apart from the issues detected for 350 MHz and 525 MHz, results from the fundamental harmonic 175 MHz are similar for the four cases and theory can validate CST simulations.

## SENSITIVITY ANALYSIS

Different parameters affect the response of the pickup signals. In this section we analyse the most relevant: beam energy, beam intensity and beam profile. In the case of beam profile, two profile distortions are considered. First, a beam expansion in the horizontal axis by applying the operator (𝑥, 𝑦) → (𝑥 · (1+𝛿), 𝑦), to all the particles. Second, a beam focusing in the vertical and horizontal axis by applying the operator (𝑥, 𝑦) → (𝑥 · (1-𝛿), 𝑦 · (1-𝛿)), to all the particles. CST with real beam is used to obtain the results. Results are shown in Fig. 5.

The monitors signals increase linearly with the beam energy and beam profile as described by the theoretical equations Eqs. (3) and (4). In the case of horizontal expansion, a significant increment is observed in the monitors H+ and H-. This means that these signals could be used to sense a horizontal expansion. Finally, when focusing the beam, it is observed again that the highest deviations are the monitors H+ and H-, in this case, lowering the signal.

Figure 5: Voltage monitors response to expansion and focus of the beam.

<!-- image -->

## CONCLUSIONS

Different approaches can be considered to simulate the pickups response from the beam induced fields. It is concluded that, for 175 MHz, CST simulations are in accordance with theory.

The final purpose of the RF pickup proposed is to protect the machine in case of deviation from nominal conditions. Many factors can vary the response of the pickups, being studied in this paper the beam energy, beam intensity and beam profile. As seen, pickups are sensitive to these parameters' variations. An approach to protect the machine could be to send the interlock in case a pickup signal exceeds a fixed threshold. Measurement of the horizontal antennas are the most sensitive to deviations in the beam profile. Further studies require to define the accident scenarios and perform simulations for those cases.

## REFERENCES

- [1] A. Ibarra et al., "The IFMIF-DONES project: preliminary engineering design", Nucl. Fusion, vol. 58, no. 10, p. 105002, Aug. 2018.
- [2] I. Podadera et al., "Update of the 5 MW Beam-on-Target Requirements for improvement of the materials irradiation performance at IFMIF-DONES", Nucl. Mater. Energy, vol. 40, pp. 101691-101691, Jun. 2024.
- [3] C. Oliver et al., "High Energy Beam Transport Line for the IFMIF-EVEDA Accelerator", in Proc. EPAC'08, Genoa, Italy, Jun. 2008, paper THPC028, pp. 3041-3043.
- [4] R. E. Shafer, "Beam position monitoring," AIP conference proceedings, vol. 212, pp. 26-58, 1990.
- [5] J. H. Cupérus, "Monitoring of particle beams at high frequencies," Nucl. Instrum. Methods, vol. 145, no. 2, pp. 219-231, 1977.
- [6] CST Particle Studio, Dassault Systemes, https://www.3ds.com/products/simulia/cst-studiosuite
- [7] M. Wendt, "BPM systems: A brief introduction to beam position monitoring", in Proc. CERN Accelerator School - Beam Instrumentation for Particle Accelerators '18, Tuusula, Finland, Jun. 2018. doi:10.48550/arXiv.2005.14081
- [8] R. E. Shafer, "Beam position monitor sensitivity for low-β beams", AIP conference proceedings, vol. 319, pp. 303-308, 1994.