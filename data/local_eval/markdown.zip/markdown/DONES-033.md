<!-- image -->

## Beam Instrumentation

## Eva Barbara Holzer

CERN, Geneva, Switzerland

## CAS

Introductory level course on Accelerator Physics

Eva Barbara Holzer CAS intr. Level course on Accelerator Physics

## Introduction

-  Beam Instrumentation is a very wide subject; with a large range of technologies and fields involved, including:
-  Accelerator physics
-  understand the beam parameters to be measured
-  distinguish beam effects from sensor effects
-  Particle physics and detector physics
-  understand the interaction of the beam with the sensor
-  RF technology
-  Optics
-  Mechanics
-  Electronics
-  Analogue signal treatment
-  Low noise amplifiers
-  High frequency analogue electronics
-  Digital signal processing
-  Digital electronics for data readout
-  Software engineering
-  Front-end and Application Software

Eva Barbara Holzer CAS intr. Level course on Accelerator Physics

<!-- image -->

September, 2014 1

September, 2014 2

## Introduction, cont'd

-  Harsh environment:
-  Radiation (single event effects, radiation ageing, activation)
-  Many sources of measurement noise and background
-  Place readout close to detector, but  radiation
-  RF heating by the beam
-  Accessibility and maintenance
-  Sometimes: cryogenic temperatures
-  Mostly: must operate in vacuum and be UHV compatible

Eva Barbara Holzer CAS intr. Level course on Accelerator Physics

## Introduction, cont'd

-  Aim: assist in commissioning, tuning and operating the accelerator and to improve performance  see tomorrow
-  Some instrument classifications:
-  LINAC and transport lines: Single pass, can have separate measurement lines ↔ Synchrotron: multi pass
-  Total Beam Energy (beam particles x particle energy) low ↔ high
-  Non-intercepting↔ Intercepting↔ Destructive (often depending on beam energy)
-  In this presentation:
-  Explain working principles of some of the most important instruments
-  Give indication on achievable performance
-  Give selected examples from operating machines and current developments

Eva Barbara Holzer CAS intr. Level course on Accelerator Physics

September, 2014 4

September, 2014 3

## Resources and References

-  Peter Forck: Lecture on Beam Instrumentation and Diagnostics at the Joint University Accelerator School (JUAS), see also the extended Bibliography.

http://www-bd.gsi.de/conf/juas/juas.html

-  CERN Accelerator Schools (CAS):

http://cas.web.cern.ch/cas/CAS%20Welcome/Previous%20Schools.htm and http://cas.web.cern.ch/cas/CAS\_Proceedings.html

-  Rhodri Jones and Hermann Schmickler: Introduction to Beam Instrumentation and Diagnostics, CERN-2006-002.
-  Daniel Brandt (Ed.), 2008 CAS on Beam Diagnostics for Accelerators, Dourdan, CERN-2009-005 (2009).
-  Heribert Koziol, Beam Diagnostic for Accelerators, Loutraki, Greece (2000), CERN/PS 2001-012 (DR), see also extended Bibliography.
-  Jacques Bosser (Ed.), Beam Instrumentation, CERN-PE-ED 001-92, Rev. 1994

Eva Barbara Holzer CAS intr. Level course on Accelerator Physics

## Measured Quantities

-  Beam intensity
-  Ideally: 6D phase space of the beam
-  Real measurements: mean values and 1D-projection, some 2Dprojections
-  Transverse position (mean x, y)  trajectory and orbit
-  Transverse profile
-  Bunch length, bunch shape
-  Mean momentum and momentum spread
-  Emittance and 2D phase space reconstruction (transverse and longitudinal)
-  Beam halo measurements
-  Tune, chromaticity, coupling, beta function, dispersion
-  Beam Losses
-  Polarisation
-  Luminosity

Eva Barbara Holzer CAS intr. Level course on Accelerator Physics

September, 2014 5

September, 2014 6

## Classification of Selected Devices

-  Different devices (techniques) to measure the same quantity ↔ Same device to measure different quantities

<!-- image -->

| PROPERTY MEASURED  Intensity/charge  tr. Position  tr. Size/shape  tr. Emittance  Effect  on  beam  N - + D  Current transformers    x  Pick-ups     x  Faraday cup    x  Secondary emission monitors     x x  Wire scanners     x  Scintillator screens    x x  OTR screen    x x  Residual-gas profile monitors    x  Beam loss monitors  x   |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

Effect on beam depends on circumstances

- N none
- slight
+ perturbing
- D destructive
-  Different Labs have different names for the same device!

Eva Barbara Holzer

CAS intr. Level course on Accelerator Physics

## Beam Position Monitors

Eva Barbara Holzer

CAS intr. Level course on Accelerator Physics

September, 2014 7

September, 2014 8

## Capacitive Pick-Ups for Bunched Beams

-  Among the most numerous instruments
-  Measurements:
-  Transverse beam position (typically next to focusing elements)
-  Beam trajectory or closed orbit
-  injection oscillations
-  Tune and lattice function in synchrotrons
-  Working principle:
-  Image current in vacuum chamber walls: equal size and opposite sign of the AC beam component
-  Monitor the induced charge with a plate inserted in the beam pipe
-  Adapt BPM electronics integration time
-  Single-bunch ↔multi-bunch
-  turn-by-turn (single pass) ↔multi-turn average

Eva Barbara Holzer CAS intr. Level course on Accelerator Physics

## Capacitive Pick-Up - The Principle

<!-- image -->

<!-- image -->

September, 2014 9

## Schematics and Simplified Equivalent Circuit

<!-- image -->

<!-- formula-not-decoded -->

<!-- formula-not-decoded -->

U im … voltage measured due to image current

R … amplifier input resistor

ω … frequency

βc … beam velocity

Eva Barbara Holzer

<!-- formula-not-decoded -->

<!-- image -->

<!-- formula-not-decoded -->

<!-- formula-not-decoded -->

Z t … longitudinal transfer impedance

High pass characteristics with a cut-off frequency, f cut

<!-- image -->

CAS intr. Level course on Accelerator Physics

## Transfer Impedance

<!-- formula-not-decoded -->

<!-- formula-not-decoded -->

-  large signal at lower frequencies
- high impedance
-  smooth signal transmission

September, 2014 11

P. Forck, JUAS

<!-- image -->

l = 10 cm long cylindrical pick-up with a capacitance of C = 100 pF and an ion velocity of β = 50%

 50 

Eva Barbara Holzer

CAS intr. Level course on Accelerator Physics

September, 2014 12

## Operational Regime Determines Signal Shape

<!-- formula-not-decoded -->

- shift phase no ,ሻݐሺ௠௔௘௕ܫ ∝ ሻݐሺ௠௜ܷ  ω &gt;&gt; ω cut : P. Forck, JUAS

l = 10 cm long cylindrical pick-up with a capacitance of C = 100 pF and an ion velocity of β = 0.5,

<!-- formula-not-decoded -->

Operational regime depends on the bunch length!

Eva Barbara Holzer CAS intr. Level course on Accelerator Physics

<!-- image -->

## Beam Position

-  Signal on each plate is proportional to the beam intensity
-  The difference signal (∆U), top - bottom, or left - right, is proportional to the position of the beam center of mass
-  Normalization to the sum signal (ΣU) gives the position:

<!-- formula-not-decoded -->

-  The difference signal (∆U) is normally at least a factor 10 lower than the sum signal (ΣU)
-  Difficult to do electronically without some of the intensity information leaking through
-  When looking for small differences this leakage can dominate the measurement
-  Resolution for typical apertures:
-  ≈ tens μm turn-by-turn
-  ≈ μmmulti-turn resolution

<!-- image -->

Eva Barbara Holzer

CAS intr. Level course on Accelerator Physics

September, 2014 13

September, 2014 14

## Example: Button Pick-up

-  Low cost most popular

## × Non-linear

-  requires correction algorithm when beam is off-centre
- 4 1 1 5 2 1 3 1 6 1 3 1 5 5 1 5 10 53 . 1 10 53 . 7 035 . 1 10 70 . 3 10 30 . 2 Y X Y X X X X X             

## LHC buttons

<!-- image -->

<!-- image -->

f cut

400

Z

1

2

C

R













A

2





c

a

t



Eva Barbara Holzer pF

8

1



50





2







MHz

12









5

2

mm

mm





 









2

.

1

8

.

24

pF

c



CAS intr. Level course on Accelerator Physics

## Shoebox Pick-up

-  ∆U gives linear position reading (no geometric correction)
-  Condition: Linear cut: projection on the measurement plane must be linear:
-  Various geometries have been built, example from GSI optimization study (P.Kowina et al., DIPAC 2005)

<!-- image -->

Eva Barbara Holzer September, 2014 15

<!-- image -->

R. Jones, CAS

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

CAS intr. Level course on Accelerator Physics September, 2014 16

2





C

e

## New LHC Collimators with Integrated BPMs

-  Beam-based setup currently with BLM signal  time consuming
-  Tighter tolerances will be required for future LHC operation
-  BPM integrated in the tapered end of the collimator jaws (10.6mm retraction from jaw surface)
-  Drastically reduce set-up time
-  Allow constant monitoring of beam position to jaw position
-  Successfully tested in the SPS (D. Wollmann, HB2012)
-  &lt;25 μm difference to BLM setup - believed to be dominated by the BLM setup method
-  single pass (transfer line): &lt;90μm rms
-  no disturbance observed from protons hitting the jaws or from shower particles

Eva Barbara Holzer CAS intr. Level course on Accelerator Physics

<!-- image -->

## Beam Current

Eva Barbara Holzer CAS intr. Level course on Accelerator Physics

September, 2014 17

September, 2014 18

## Faraday Cup

-  Measurement of the beam's electrical charges
-  Low energies only
-  Particles are stopped in the device
-  Destructive
-  Sensitive to low currents: down to 1 pA can be measured
-  Creation of secondary electrons of low energy (below 20 eV)
-  Repelling electrode with some 100 V polarization voltage pushes secondary electrons back onto the electrode
-  Absolute accuracy:
-  ≈ 1% (some monitors reach 0.1%)

## Faraday Cup at GSI LINAC, P. Forck, JUAS

<!-- image -->

<!-- image -->

Eva Barbara Holzer CAS intr. Level course on Accelerator Physics September, 2014 19

## Beam Current Transformer (BCT)

-  Measurement of the magnetic field of the beam
-  Non-interceptive
-  Independent on beam energy
-  Beam as primary winding of a transformer

<!-- image -->

## Current Transformers

<!-- image -->

<!-- image -->

Transformer Inductance

<!-- formula-not-decoded -->

Eva Barbara Holzer

-  Magnetic field of the beam is very low (Example: 1 μA, r = 10cm ⇒ 2 pT; compared to earth magnetic field of ≈50 μT)
-  Aim of the Torus:
-  Capture magnetic field lines with cores of high relative permeability
-  Signal strength nearly independent of beam position.
-  (CoFe based amorphous alloy Vitrovac: μ r = 10 5 )

CAS intr. Level course on Accelerator Physics

September, 2014 21

## Adapt Droop Time with Active Transformer

<!-- image -->

<!-- image -->

Bunch trains:

- Equal areas
- Baseline shift proportional to intensity
-  Use a trans-impedance amplifier (current-to-voltage converter) for observation of beam pulses &gt; 10 μs, e.g. at pulsed LINAC
-  Droop time constants of up to 1s
-  Longer rise times as well (to reduce high frequency noise of the amplifier

<!-- formula-not-decoded -->

H. Koziol, CAS

Eva Barbara Holzer CAS intr. Level course on Accelerator Physics

September, 2014 22

## Transformer Housing

-  Image current passing outside of the transformer torus
-  High permeability material shields the transformer against external magnetic fields

<!-- image -->

500 MHz Bandwidth; Low droop (&lt; 0.2%/ms)

Eva Barbara Holzer CAS intr. Level course on Accelerator Physics CERN SPS Fast Beam Current Transformer (FBCT)

<!-- image -->

R. Jones, DIPAC'03

September, 2014 23

## CERN FBCT Readings of LHC Type Beams in the SPS

-  4 batches each containing 72 bunches separated by 25 ns

<!-- image -->

Eva Barbara Holzer CAS intr. Level course on Accelerator Physics

September, 2014 24

## DCCT: DC Beam Current Transformer

-  DC current dB/dt = 0 ⇒ no voltage induced
-  Use two identical toroids
-  Take advantage of non-linear magnetisation curve
-  Modulation of opposite sign drives toroids into saturation
-  Sense windings measure the modulation signal
-  Signals from the two toroids cancel each other as long as there is no beam

P. Forck, JUAS

Eva Barbara Holzer CAS intr. Level course on Accelerator Physics

<!-- image -->

<!-- image -->

## DCCT Principle - Case 1: No Beam

<!-- image -->

September, 2014 25

<!-- image -->

<!-- image -->

## DCCT in the "Zero Flux" Scheme

-  The length of the pulses is a measure for the beam current
-  Zero-flux scheme: compensate for the beam current and measure the magnitude of the compensation current

<!-- image -->

Eva Barbara Holzer CAS intr. Level course on Accelerator Physics

## Performance

-  Achievable performance Fast Beam Current Transformers (FBCT):
-  Performance LHC DC Beam Current Transformers (DCCT):

-  Absolute accuracy:

1%

-  Reproducibility / relative precision:

0.1%

-  Dynamic range:

10 3 (10 4 )

-  Absolute accuracy:
-  Noise floor

0.2%

2 µA

-  Dynamic range

10 6 (µA - 1A)

Eva Barbara Holzer CAS intr. Level course on Accelerator Physics

September, 2014 30

P. Forck, JUAS

September, 2014 29

## Transverse Profile

Eva Barbara Holzer CAS intr. Level course on Accelerator Physics

## Overview - Beam Profile measurement

-  Methods which intercept the beam with matter:
-  Secondary emission (SEM) grids
-  Screens
-  Wire scanners
-  more or less perturbing to the beam
-  Energies/intensity threshold for safe operation
-  Material damage (e.g. wire sublimation, breakage)
-  Radiation to other machine components (e.g. quenching of superconducting magnets)
-  (Quasi) Non-Invasive Methods:
-  Synchrotron light monitors
-  Rest Gas Ionisation monitors
-  Luminescence monitors
-  Laser wire scanner
-  Electron beam scanner
-  Gas curtains, gas pencil beams
-  Beam Gas Vertex Detector

Eva Barbara Holzer CAS intr. Level course on Accelerator Physics

September, 2014 31

SEM grids and wire scanners:

Used as reference measurement for the other methods

September, 2014 32

## Secondary Emission (SEM) Grids

-  When the beam passes through a wire, secondary electrons are emitted, proportional to beam intensity
-  The current flowing back onto the wires is measured using one amplifier/ADC chain for each wire
-  Clearing field removes liberated electrons
-  Problem: thermal emission
-  Very high sensitivity, semi-transparent
-  Good absolute measurement
-  Spatial resolution limited by wire spacing to &lt;≈ 0.25mm
-  Dynamic range: ≈ 10 6

<!-- image -->

<!-- image -->

<!-- image -->

Eva Barbara Holzer CAS intr. Level course on Accelerator Physics

## Scintillation Screens

-  Typically for setting-up with low intensities, thick screens (mm)  emittance blow-up
-  Workshop in 2011 at GSI to look at resolution possible with various screen materials: http://www-bd.gsi.de/ssabd/home.htm
-  Sensitivities of different materials vary by orders of magnitudes

<!-- image -->

Approximate values for inorganic scintillators

P. Forck, JUAS

Eva Barbara Holzer CAS intr. Level course on Accelerator Physics September, 2014 33

September, 2014 34

## Optical Transition Radiation (OTR) Screens

-  Radiation emitted when a charged particle beam goes through the interface of two media with different dielectric constants
-  Surface phenomenon allows the use of very thin screens (≥ 0.25 μm)
-  Much less intercepting, but requires higher intensity

<!-- image -->

## Beam Profile Monitoring Using Screens

-  Combine several screens in one housing e.g.
-  Al 2 O 3 scintillation screen for setting-up with low intensity
-  Thin (≈10um) Ti OTR screen for high intensity measurements
-  Carbon OTR screen for very high intensity operation
-  Cameras:
-  CCD cameras are radiation sensitive
-  Analogue VIDICON camera can be used with high radiation

<!-- image -->

Eva Barbara Holzer CAS intr. Level course on Accelerator Physics

September, 2014 36

<!-- image -->

## Wire Scanners

-  A thin wire (down to 10 µm) is moved across the beam
-  Has to move fast to avoid excessive heating of the wire
-  Rotational scanner up to 10 m/s with special pneumatic mechanism (linear scanners slower)
-  Detection
-  Secondary particle shower detected outside the vacuum chamber e.g. using a scintillator/photo-multiplier assembly
-  Secondary emission current detected as for SEM grids
-  Correlating wire position with detected signal gives the beam profile
-  Wire vibrations limit position resolution
-  Less invasive than screen or SEM grids

Eva Barbara Holzer CAS intr. Level course on Accelerator Physics

<!-- image -->

## New Wire Scanner being developed at CERN

-  Design goals:
-  Spatial resolution of few µm (using high resolution angular position sensor )
-  Dynamic range: 10 4
-  Usage of sensor with large dynamic (diamond)
-  Automatic electronic switching of gain ranges
-  Minimize fork and wire deformations
-  Study of dynamic behavior of fork/wire system
-  Vibration mode optimized acceleration profile
-  Current Wire Scanners at CERN:
-  Dynamic range 100; accuracy 5-10%; spatial resolution 50 µm (linear type) and 200 µm (rotational)

<!-- image -->

Eva Barbara Holzer CAS intr. Level course on Accelerator Physics

September, 2014 38

September, 2014 37

## (Quasi) Non-Invasive Beam Size Measurement

Eva Barbara Holzer CAS intr. Level course on Accelerator Physics

## IPM (Ionization Profile Monitors)

-  Residual Gas Ionisation
-  dynamic range: up to 10 3
-  ≈ 10 times more sensitive than Luminescence
-  Image broadening due to space charge
-  More complicated to build
-  High voltage
-  Guiding magnetic field
-  Compensation magnets for the beam

T. Giacomini et al., GSI

Eva Barbara Holzer CAS intr. Level course on Accelerator Physics September, 2014 40

<!-- image -->

September, 2014 39

## Beam Loss Measurement for Protection and Diagnostics

Eva Barbara Holzer CAS intr. Level course on Accelerator Physics

## Common types of monitors

-  Long ionisation chamber (charge detection)
-  Up to several km of gas filled hollow coaxial cables
-  Longitudinal position information by arrival time measurement
-  e.g. SLAC - 8m position resolution (30ns) over 3.5km cable length
-  Dynamic range of up to 10 4
-  Cherenkov fibres
-  Time resolution 1 ns
-  Minimal space requirement
-  Insensitive to gamma background, E and B fields
-  Radiation hard (depending on type)
-  Combination fiber / readout can adapt to a wide dose range
-  Dynamic range 10 4 seems feasible

Eva Barbara Holzer CAS intr. Level course on Accelerator Physics September, 2014 41

September, 2014 42

## Common types of monitors cont'd

-  Short ionisation chamber (charge detection)
-  Typically gas filled with many metallic electrodes and kV bias
-  Speed limited by ion collection time - tens of microseconds
-  Dynamic range of up to 10 8
-  PIN photodiode (count detection)
-  Detect charged particle
-  Insensitive to photons from synchrotron radiation due to coincidence counting in two back-to-back mounted PIN diodes (K. Wittenburg, DESY)
-  Count rate proportional to beam loss
-  Speed limited by integration time
-  Dynamic range of up to 10 9
-  Scintillators plus photo-multipliers
-  etc. …

Eva Barbara Holzer CAS intr. Level course on Accelerator Physics

## LHC BLM System

-  Main purpose: prevent damage and quench
-  3600 Ionization chambers
-  Beam abort thresholds:
-  12 integration intervals: 40μs to 84s (32 energy levels)

<!-- image -->

Eva Barbara Holzer

-  1.5 Million threshold values
-  Each monitor aborts beam

September, 2014 43

<!-- image -->

-  One of 12 integration intervals over threshold
-  Internal test failed
-  Requirements and Challenges
-  High Dependability (Reliability, Availability, Safety)
-  Threshold precision (factor 2)
-  Reaction time 1-2 turns (100 - 200 μs)
-  Dynamic range: 10 8 (at 40µs 10 5 achieved - 10 6 planned)
-  Radiation hard: currently at CERN development of kGy radiation hard readout to avoid noise from long cables

CAS intr. Level course on Accelerator Physics September, 2014 44

<!-- image -->

<!-- image -->

## Set-up and validation of collimation performance

<!-- image -->

<!-- image -->