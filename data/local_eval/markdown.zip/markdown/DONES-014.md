<!-- image -->

WPENS-CPR(18) 20056

A Klix et al.

## Measurement of neutron fluence in the High-Flux Test Module of the Early Neutron Source by an activation foils method

Preprint of Paper to be submitted for publication in Proceeding of 30th Symposium on Fusion Technology (SOFT)

<!-- image -->

This work has been carried out within the framework of the EUROfusion Consortium and has received funding from the Euratom research and training programme 2014-2018 under grant agreement No 633053. The views and opinions expressed herein do not necessarily reflect those of the European Commission.

This document is intended for publication in the open literature. It is made available on the clear understanding that it may not be further circulated and extracts or references may not be published prior to publication of the original when applicable, or without the consent of the Publications Officer, EUROfusion Programme Management Unit, Culham Science Centre, Abingdon, Oxon, OX14 3DB, UK or e-mail Publications.Officer@euro-fusion.org

Enquiries about Copyright and reproduction should be addressed to the Publications Officer, EUROfusion Programme Management Unit, Culham Science Centre, Abingdon, Oxon, OX14 3DB, UK or e-mail Publications.Officer@euro-fusion.org

The contents of this preprint and all other EUROfusion Preprints, Reports and Conference Papers are available to view online free at http://www.euro-fusionscipub.org. This site has full search facilities and e-mail alert options. In the JET specific papers the diagrams contained within the PDFs on this site are hyperlinked

## Measurement of neutron fluence in the High-Flux Test Module of the Early Neutron Source by neutron activation

Axel Klix a , Frederik Arbeiter a , Mitja Majerle b , Yuefeng Qiu a , Milan Štefánik b

a Karlsruhe Institute of Technology, Eggenstein-Leopoldshafen, Germany b National Physics Institute, Řež, Czech Republic

The High Flux Test Module (HFTM) carries the specimen to be irradiated with the Early Neutron Source. The knowledge of the total neutron fluence on the specimen will be necessary for analysis. Neutron activation is a widely used method for neutron fluence measurement. We have tested a set of activation materials which seem to be suitable for application in the HFTM considering half-lives of the induced activities, the environmental conditions and the deployment time in the HFTM. Test foils were irradiated for 9.5 hours with a cyclotron of NPI Řež in a white neutron field with energies up to 35 MeV. The induced activities were determined 61 days after the irradiation. We present the resulting saturation activities with estimated uncertainties and draw conclusions on the application of the selected activation materials in the HFTM.

Keywords: Early Neutron Source, High Flux Test Modul, Neutron Activation, Neutron Flux.

## 1. Introduction

The DEMO Oriented Neutron Source DONES [1,2] is a neutron irradiation facility for experimental tests of DEMO reactor structural materials. These materials will be irradiated to damage dose levels up to 50 dpa. The neutron fluence exposure is a fundamental normalization parameter for the material specimens, and it must be therefore determined with high accuracy. The neutron activation foil method appears suitable for this purpose considering cost, low technical requirements and invasiveness as well as the inherent radiation hardness.

Small packages of thin activation foils can be placed in several locations: on the outer surface of the HFTM, on the outside of specimen capsules inside the HFTM or inside the specimen capsules. The latter would provide measurements very close to the specimens while the other two options require more corrections to determine the neutron fluence in the place of the specimen. Each location has a different access time after completion of the irradiation cycle. If the activation foils are mounted on the outer surface of the HFTM the estimated earliest access to them for measurement of the induced gamma activity would be approximately one week after shutdown. An activation foils package on the surface of a specimen capsule would be accessible about three weeks after shut-down while an activation foil package inside the specimen capsule becomes available two to three months after shut-down.

In this work we investigate a set of activation foils which appears to be suitable for application in the HFTM. The set consists of iron, cobalt, nickel, yttrium, and gold. The selected dosimetry reactions lead to radioisotopes with half-lives of several months up to a few years so that they would preserve neutron flux information over a year of operation without substantial saturation effects, and they cover the entire ENS neutron energy range. Tests of the measurement method were

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

performed with the cyclotron neutron source at NPI Řež which provides a white neutron spectrum with neutron energies up to 32 MeV. This is less than what expected in ENS (En&lt;55MeV), however, it does extend over the threshold energies of all considered dosimetry reactions.

## 2. Neutron field in the HFTM and activation material selection

## 2.1 The specimen capsules in the HFTM

The HFTM holds 32 capsules with specimens to be irradiated to neutron fluences up to approximately 10 22 cm -2 . The HFTM will stay in place for duty periods on the order of a year. Then it will be extracted and disassembled. A sketch of the HFTM with the specimen capsules is shown in Figure 1.

Fig. 1. The HFTM and the specimen capsules.

<!-- image -->

Three location for activation materials are considered. They could be placed on the outer surface of the HFTM. In this case a fast access after one week is possible. Another choice would be in a pocket on the outer surface of the specimen capsules with an access time of approximately three weeks after shut-down. The third option would be inside the specimen capsules. This version has the longest waiting time between neutron source shut-down and access to the activation probes with two to three months. It is clear that a minimum requirement for the choice of dosimetry reactions are half-lives of the induced radio-isotopes longer than the access time. However, there is another requirement in terms of half-life. The activation probes stay in place for the entire duty cycle of the HFTM. Therefore the halflives need to be chosen so that they are at least longer than 1/3 to ½ of the duty cycle to preserve neutron flux information over the entire duty cycle.

The neutron flux density in the HFTM reaches 2×10 13 cm -2 s -1 in the outer specimen capsules and up 5×10 14 cm -2 s -1 in the center capsules on the neutron source side of the HFTM, hence it changes over an order of magnitude within a few cm. A neutron flux density map calculated with the McDeLicious code [3] is shown in Figure 2, for details see Ref. [4].

It is desirable to measure the neutron flux in several positions in the HFTM to obtain this distribution with high accuracy. The neutron fluence reaches 10 22 cm -2 , therefore only small activation probes with masses of 1 mg or less will be required to facilitate the measurement of the induced activity after extraction.

Fig. 2. Neutron flux distribution in the HFTM calculated with the McDeLicious code.

<!-- image -->

Such a small size of the activation probe is in favor for placing activation probes inside the specimen cells. However, this small size will pose difficulties in handling of the activation probes.

## 2.2 Selection of dosimetry reactions

A set of dosimetry reactions for neutron flux measurements has been investigated by Simakov et.al. [5], similar studies are underway at the National Institute for Quantum and Radiological Science and Technology by Kwon et.al. [6].

Here we have started from the dosimetry reactions presented in [5] and selected only those which yield induced activities with half-lives longer than 100 days. Some additional reactions were included since their corresponding induced activities were measured in the experimental test described in the next section. Table 1 presents the selection of dosimetry reactions along with their parameters such as melting temperature of the activation material, the half-life and the energy range covered. The table contains also reaction paths which lead to the expected induced activities. These reaction paths were obtained with inventory calculations using the FISPACT-II code [7] and the EAF-2010 activation library [8]. Further input was an irradiation time of 330 days with a neutron flux density of 4×10 14 cm -2 s -1 and a neutron spectrum as expected in the specimen cells exposed to the highest neutron fluxes. This inventory calculation estimates relative contribution of each reaction in each reaction path to the final radio-isotope. In this way also a final specific induced activity was estimated as presented in the last column of Table 1.

## 2. Experimental test

A set of activation foils was experimentally tested with the aim to check the method practically. For this purpose foils of Au, Ni, Y, Co, and Fe were selected. Their masses were in the range of 0.3-3.8 g with a size of 2.5×2.5 cm 2 and a thickness of around 0.5 mm.

The irradiations were performed at the cyclotron of NPI Řež. The irradiation lasted for 9.5 h with a neutron flux density of 1.71×10 9 cm -2 s -1 in the position of the samples. Figure 3 shows the calculated neutron flux spectrum of ENS compared with the calculated and measured neutron spectrum of the d-Be neutron source at NPI for the case of a proton beam with 9.26 μA.

Fig. 3. Neutron flux spectrum in a center-front specimen box of the HFTM compared with the neutron flux spectrum at the experimental position at NPI.

<!-- image -->

Table 1. Selected dosimetry reactions, relevant physical parameters, reaction paths leading to the isotopes of interest and estimated specific activity after extraction from the HFTM.

Neutrons were generated with a proton beam bombarding a thick beryllium target. The total flux density is then four to five orders of magnitude smaller than in the HFTM and the maximum neutron energy was with 32 MeV lower than the expected 55 MeV in ENS but the threshold energies of all considered dosimetry reactions were well below this 32 MeV so that all reactions were included in the test.

The induced gamma activities in the irradiated foils were measured with a High-Purity Germanium (HPGe) spectrometer 61 days after the irradiation which was a waiting time similar to the waiting time expected in the real HFTM neutron fluence measurement and served also the purpose to reduce any background introduced by shorter living radio isotopes. The HPGe detector was controlled by the Genie-2000 software (Canberra) which provided also the full peak analysis of the photon spectra.

The relevant physical properties of the activation foils, the induced activities such as half-lives and gamma line intensities from the JEFF-3.3 nuclear data library, the induced activities and the saturation activities calculated from the induced activities are presented in Table 2.

The table includes also error estimates for the final activities. The error estimates were calculated from uncertainties of half-life and gamma line intensities from JEFF-3.3, an estimated uncertainty of 3% of the efficiency of the detectors system. Uncertainties of the activation foil masses and time measurement (irradiation, waiting time, measurement time) were neglected due to their small size. The partial relative uncertainties were combined with quadratic error propagation.

## 3. Discussion and conclusions

The determination of the neutron fluence to which the specimens in the HFTM of DONES are exposed to provides a fundamental parameter for further specimen analysis. The neutron fluence can be conveniently measured in principle with the neutron activation foil method. Purpose of the present work was an experimental test with suitable activation foils/dosimetry reactions utilizing a neutron source which provides a neutron spectrum sufficiently similar to the spectrum in DONES. All expected induced gamma activities could be measured after irradiation and a waiting time according to a scenario expected in DONES.

The selection of dosimetry reactions was based on an earlier work by Simakov et.al. for the characterization of the IFMIF neutron spectrum. For the application in the HFTM only those radioisotopes with a half-lives &gt;100 days were selected since the activation foil package must stay in place for the entire duty cycle of the HFTM.

Several of the dosimetry reactions are composed of up to four reaction paths with contributions of up to three dominant partial nuclear reactions in each path. An experimental verification of the corresponding cross sections in particular at energies above 20 MeV will be necessary since experimental values are very scarce or unavailable. This is in particular true for two reactions with threshold energies around 27 MeV.

Table 2. Masses of the test foils, relevant radioactive properties according to the JEFF-3.3 nuclear data library and results of the measurement of the induced gamma activity in the test foils at NPI Řež.

The masses of the activation foils considered in the present work were in the range of 0.3-2.8 g. All expected induced activities could be determined, the activities in the foils ranged from 2 Bq to 20 kBq requiring gamma measurement times from minutes to several hours to reach statistical uncertainties of 2-1 %. In the HFTM the neutron fluence will be up to nine orders of magnitude higher and so the corresponding specific activities. In order to measure the induced gamma activities with an off-the-shelve gamma spectrometer it will be necessary to post-process the activation foils. A practicable way seems to be the application of thin foils with a low mass and dissolving them after irradiation. A solution of the radioisotopes can be more precisely divided into small fractions thereby reducing the activity of the counting sample than fr example mechanical cutting of the foils. In summary, important indispensable next steps are therefore tests of the activation foils with (calibrated) neutron sources with energies up to 55 MeV and development of a chemical procedure to post-process the (then highly activated) activation foils into a form suitable for gamma counting.

## Acknowledgments

This work has been carried out within the framework of the EUROfusion Consortium and has received funding from the Euratom research and training programme 2014-2018 under grant agreement No 633053. The views and opinions expressed herein do not necessarily reflect those of the European Commission.

## References

- [1] J. Knaster, The accomplishment of the engineering design activities of IFMIF/EVEDA: the European-Japanese project towards a Li(d,xn) fusion relevant neutron source, Nuclear Fusion 55 (8) (2015) 086003.
- [2] A. Ibarra, et al., A stepped approach IFMIF/EVEDA towards IFMIF, Fusion Science Technology 66 (2014) 252-259.
- [3] S.P. Simakov, U. Fischer, K. Kondo, P. Pereslavtsev, Status of the McDeLicious approach for the D-Li neutron source term modeling in IFMIF neutronics calculations, Fusion Science and Technology 62 (2012) 233-239.
- [4] Y. Qiu. et.al., IFMIF-DONES HFTM neutronics modeling and nuclear response analysis, Nuclear Materials and Energy 15 (2018) 185-189.
- [5] S. Simakov et.al., Development of activation foils method for the IFMIF neutron flux characterization, Fusion Engineering and Design 82 (2007) 2510-2517.
- [6] S. Kwon et.al., Investigation on A-FNS Neutron Spectrum Monitor System, Nuclear Materials and Energy 16 (2018) 207-211.
- [7] J-Ch. Sublet, J. W. Eastwood, J. G. Morgan, M. R. Gilbert, M. Fleming, and W. Arter, "FISPACT-II: An Advanced Simulation System for Activation, Transmutation and Material Modelling," Nuclear Data Sheets 139 (2017) 77-137
- [8] J.-Ch. Sublet, L. W. Packer, J. Kopecky, R. A. Forrest, A. J. Koning and D. A. Rochman, The European Activation File: EAF-2010 neutron-induced cross section library, Report CCFE-R (10) 05, https://www.oecdnea.org/dbforms/data/eva/evatapes/eaf\_2010/EAF\_n\_Cro ss\_sections\_2010.pdf, accessed 24 Aug. 2018