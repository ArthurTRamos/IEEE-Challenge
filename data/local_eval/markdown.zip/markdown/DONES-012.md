<!-- image -->

WPENS-CPR(18) 20129

K Tian et al.

## Preliminary Analysis on A Maintainable Test Cell Concept for IFMIF-DONES

Preprint of Paper to be submitted for publication in Proceeding of 30th Symposium on Fusion Technology (SOFT)

<!-- image -->

This work has been carried out within the framework of the EUROfusion Consortium and has received funding from the Euratom research and training programme 2014-2018 under grant agreement No 633053. The views and opinions expressed herein do not necessarily reflect those of the European Commission.

This document is intended for publication in the open literature. It is made available on the clear understanding that it may not be further circulated and extracts or references may not be published prior to publication of the original when applicable, or without the consent of the Publications Officer, EUROfusion Programme Management Unit, Culham Science Centre, Abingdon, Oxon, OX14 3DB, UK or e-mail Publications.Officer@euro-fusion.org

Enquiries about Copyright and reproduction should be addressed to the Publications Officer, EUROfusion Programme Management Unit, Culham Science Centre, Abingdon, Oxon, OX14 3DB, UK or e-mail Publications.Officer@euro-fusion.org

The contents of this preprint and all other EUROfusion Preprints, Reports and Conference Papers are available to view online free at http://www.euro-fusionscipub.org. This site has full search facilities and e-mail alert options. In the JET specific papers the diagrams contained within the PDFs on this site are hyperlinked

## Preliminary Analysis on A Maintainable Test Cell Concept for IFMIFDONES

Kuo Tian a* , Frederik Arbeiter a , Mark Ascott b , Oliver Crofts b , Gary McIntyre b , Gioacchino Micciche c , George Mitchell b , Yuefeng Qiu a , Mátyás Tóth d , Angel Ibarra e

a Karlsruhe Institute of Technology (KIT), Karlsruhe, Germany

b RACE, Culham Science Centre, Abingdon, United Kingdom c ENEA C.R. Brasimone, Camugnano, Italy d HAS, Wigner Research Centre for Physics, Budapest, Hungary e Centro de Investigaciones Energeticas Medioambientales y Tecnologicas (CIEMAT), Madrid, Spain

A maintainable test cell (TC) concept, which targets replacing TC key components in case of damages, for the IFMIF-DONES (International Fusion Materials Irradiation Facility - Demo Oriented NEutron Source) facility is proposed to facilitate the maintenance of key containment and biological shielding components, i.e. the liner and the surrounding concrete walls. Unlike the current TC reference design which features permanent liner and concrete shielding walls, the new proposal decouples the components which suffer relative high failure possibilities from the ones which can stay as permanent construction structures. The former ones, that are expected to be replaced in case of damage, include removable section of the liner and part of the biological shielding materials. Fundamental mechanical solution of this configuration is briefly described, and technical feasibilities are preliminarily analyzed for the aspects of independent liner enclosure structure, maintenance scenarios using remote handling systems, and etc.

Keywords: IFMIF; DONES; Test Cell; Remote Handling; Maintenance

## 1. Introduction

The IFMIF-DONES (International Fusion Material Irradiation Facility- DEMO Oriented NEutron Source) is planned to deliver an intensive neutron source by the interaction of one 40 MeV 125 mA deuteron beam and a flowing liquid lithium (Li) target [1,2]. The engineering design of IFMIF-DONES is currently performed under WPENS (Work Package Early Neutron Source) project in the framework of EUROFusion activities.

In IFMIF-DONES facility, neutron irradiation experiments are confined and shielded by the Test Cell (TC), which is the meeting area of the end section of the accelerator, the lithium Target Assembly (TA), and the high flux test module (HFTM) [3]. The major functions of the TC include constructing a controlled leak-tight environment, providing sufficient shielding to surrounding areas against the in-TC neutron and gamma irradiations, and allowing media (mainly lithium and helium) and signal/power penetrations between TC inside and outside. The IFMIF-DONES TC design has been initiated based on the design of IFMIF-EVEDA phase [4, 5] and further developed [3, 6-8]. An exploded view of the current reference design is shown in Fig. 1 [8]. In the reference design, surrounding biological shielding walls, made of heavy concrete, are considered as part of the permanent facility building structure. A closed stainless steel liner, which covers the complete TC interior surfaces, is anchored to the concrete shielding walls. Active cooling pipes are embedded in the concrete walls in the first 1.0 meter thickness to remove nuclear heating due to neutron irradiation. The liner is also actively cooled by the water pipes which are welded at the back of the liner.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Fig. 1 Exploded view of IFMIF-DONES TC reference design with cross section of the TC surrounding wall [8]

<!-- image -->

Although the TC is designed to be fully functional for the complete IFMIF-DONES life span, there is still a possibility of defect, though very low, of the liner, the concrete, and active water cooling pipes, due to their exposure to intense neutron and gamma irradiations. Malfunctions (clogging, corrosion, break, and etc.) of these components may result in TC leakage, loss of cooling, components degradation and etc. As the main confinement of the TC environment, the reliability of the liner is of high importance. In the liner neutronic calculations estimated a peak value of 0.067 dpa/fpy [9] in damage rate, and 1.3 appm/fpy [9] in helium generation rate. However, the re-welding limit in helium concentration in 316 L is considered as 1 appm [10]. It must be pointed out that, the maintenance of the reference TC will be extremely difficult, or infeasible, in accidental cases (like a defect of the liner, concrete, or the active cooling pipes), due to the monothilic concrete and permanently attached liner configuration. This difficulty will also be significant in the decommissioning phase of the facility.

Hence, a maintainable TC concept is proposed to allow replacement of key TC components, i.e. the highly irradiated liner, concrete parts, and cooling pipes, in case of unexpected damages. In this proposal, both liner and concrete walls are divided to permanent parts, which are kept as part of the facility building, and removable parts, which can be maintained (mainly replaced). In this paper, the conceptual configuration of the maintainable TC concept is briefly described focusing on basic feasibility analysis on removable liner, and preliminary maintenance scenarios are discussed.

## 2. Maintainable Test Cell Concept

To improve the maintainability of biological shielding, the liner, as well as the cooling pipes (embedded in the concrete and attached to the liner), decoupling the TC liner, together with the attached cooling pipes, from the biological shielding walls is necessary for a replacement of the liner without damaging the concrete walls. In addition, separation of the concrete biological shielding walls that contain water cooling pipes from the facility permanent structures will ease the maintenance of these water cooling pipes.

A basic idea of the maintainable TC concept is sketched in Fig. 2 (side view). In this proposal, the internal shape of the liner keeps identical to that of the reference design, but the liner itself is almost completely decoupled to the surrounding biological shielding walls. Both of concrete walls and the liner are divided to removable sections and permanent sections. The former ones receive intense neutron irradiation and have higher failure possibility while the later ones receive very low neutron irradiation and have lower failure possibility. The removable sections mainly include Removable Biological Shielding Section (RBSS) and Removable Liner Section (RLS), while the permanent sections include Permanent Biological Shielding Section (PBSS) and Permanent Liner Section (PLS). The RBSS and PBSS are separated, however, the RLS and PLS are welded together to construct a closed vacuum confinement.

## 2.1 Removable TC Liner

One of the major purposes of the maintainable TC concept is to allow maintenance of the liner. As shown in Fig.2, the PLS is well shielded by the concrete blocks as well as in-TC shielding plugs (top shielding plugs and piping and cabling plugs), so that the received neutron irradiation is not so high. It is assumed that the PLS will not be replaced during the complete IFMIF-DONES life

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

span due to relatively low damage possibilities. Permanent connections, e.g. anchors in concrete, between PLS and PBSS are foreseen to bind these two permanent sections together. The RLS is integrated manufactured with PLS during the very beginning of the construction phase of the facility. However, the RLS has no connections to surrounding concrete shielding structures. As the vacuum boundary of the TC the RLS will be an open "box" structure with welded reinforcement ribs to withstand the pressure difference between inside and outside of the TC during irradiation and evacuation periods. The maximum pressure difference is 1 atm. A preliminary design of the TC RLS (with simplified geometry) is shown in Fig. 3 and the corresponding stress analysis can be found in Fig.4.

Fig. 2 Side view sketch of maintainable TC configuration

<!-- image -->

In this design, the RLS and the ribs are made of 316L stainless steel and feature 20 mm in thickness. The height of the ribs is defined as 60 mm. Preliminary FEM analysis, as shown in Fig. 4, indicates that the stress distribution of this design is well controlled under the over yield strength (200 MPa) under an inside-outside pressure difference of 1 atm.

Although the RLS and PLS are integrated during the first construction, it will be necessary to separated them when RLS is required to be replaced. Under this circumstance, the RLS will be cut off from the PLS so that it can be removed. After inserting of new RLS to the TC pit, re-welding between new RLS and PLS is required. The cutting and re-welding locations between RLS and PLS are preliminarily defined in Fig. 2. The exact separation positions between RLS and PLS will be defined based on more detailed neutronic calculation and taking into account the manufacturing and maintenance feasibilities.

Fig. 3 FEM simulation Model of the TC Removable Liner Section (RLS)

<!-- image -->

<!-- image -->

Fig. 4 Equivalent Stress of the TC RLS under inside-outside pressure difference of 1 bar

<!-- image -->

## 2.2 Maintainable Concrete Biological Shielding Walls

As shown in Fig. 2, the RBSS is the concrete part which is directly behind the liner and is supposed to receive higher activation during the operation of the facility, while PBSS is the concrete part which is shielded by the RBSS and is not so intensively activated. The PBSS is part of the building and is integrated with the civil structure of the facility. The RBSS includes several independent shielding blocks which can be removed after the RLS is removed. These RBSS blocks are supported by PBSS from bottom. Active cooling using water as coolant is applied to the RBSS blocks, while no active cooling to PBSS.

The separation locations between the RBSS and PBSS will be defined based on the activation level distribution of the concrete biological shielding and the cooling requirements. The RBSS will cover the high activated part and requires active water cooling, while PBSS only covers the low activated area, and does not need active cooling. Fig.5 shows the activation distribution of the TC downstream biological shielding (central line) after 30 years of DONES operation. It can be pre-defined that the thickness of the RBSS could be 1.5 meters. This configuration will in addition benefit the decommissioning of the facility because the PBSS can still keep hands-on accessible. Detailed geometries and arrangements of the RBSS blocks will be furtherly defined also taking into account that neutron streaming through the gaps is minimized and the routings of water cooling pipes are convenient in future design phases.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Fig. 5 Activation of down-stream biological shielding wall after 30 years of DONES Operation (based on reference TC design, hands on hands-on limit is defined in [11])

## 3. Preliminary Maintenance Scenario

## 3.1 Liner Removal

As mentioned in the previous chapter, the maintainable TC design has a single skin liner (RLS) with reinforcing and cooling pipes attached. The RLS must be cut from the PLS, and it also needs to be released from the TLIC and from the beam duct liner, as shown in Fig. 6 in case of maintenance. Before the RLS is required to be lifted, the beam duct will have to be removed from the target interface room (TIR) and the beam duct liner must be cut from the RLS from the TC side. Furthermore, specific remote handling (RH) Equipment will need to be designed for perform similar operations to detach RLS from TLIC wall. The corresponding cutting and re-welding points can be found in Fig. 2.

Fig. 6 TC Removable Liner detachment from TLIC and Beam Duct Liner

<!-- image -->

Different techniques have been investigated for releasing the RLS from the PLS and all are deemed practicable except for water lubricated mechanical cutting due to the possibility of lithium being present. Any cutting will inevitably produce active waste contamination and the challenge to the RH system is to minimize the production and spread of any solid waste as well as the extraction of activated gas or particulates released. With the expected damage to the 316L stainless steel referenced in [9] [10], the practicality of achieving a viable seal joint with the new liner is further reduced due to distortion during welding owing to its complex geometry. To maintain the shape of the TC, jigs and fixtures will be required to hold the geometry during welding but these will make limited access for the remote equipment. These fixtures will also hamper the Non-Destructive Examination needed to verify the integrity of the joint. It is essential that the first run of weld is examined before the remaining 9 runs being laid down to complete the butt weld.

There could also be a significant risk to implement a viable vacuum seal after replacing the RLS by means of welding. A mechanical seal using spring energized metal seal may be another option as a more practical and less time-consuming solution. Details will be investigated in next design phases.

## 3.2 RBSS Removal

As the RBSS blocks are removable they will only be required to support their own mass and cannot be a structural element of the building. The removable shielding to be replaced currently amounts to roughly 500t-600t of concrete, cladding, steel pipes and reinforcing, etc. It must be segmented into manageable sizes. As a biological shield, it is assumed that the blocks will need to be stepped to reduce neutron streaming. A general impression may be dissimilar to Fig.7a, making the challenge of removing the blocks more complex. The sections need to be jacked-up by means of hydraulic "flat jacks" (Fig. 7d/7e) to place slide bearings underneath the blocks (Fig. 7c) allowing horizontal movement to effect an unobstructed straight vertical lift. This equipment will require to be fitted and removed with every block as space and geometric shape does not allow the freedom to accommodate the equipment to lift and manoeuver the blocks simultaneously. Routing of the pipes from RBSS blocks to the connections to the TC water systems must be taken into account in designing the RBSS and defining the maintenance scenarios.

Fig. 7 TC RBSS Shine Path Mitigation Configuration

<!-- image -->

## 4. Summary

This paper proposes a maintainable IFMIF-DONES test cell concept which may ensure a replacement of the central confinement of the TC in extreme accident cases. This proposal features removable shielding and leak tight components which are decoupled from permanent structures. Compared with the permanent parts, the

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

removable ones have normally higher failure possibilities due to more intense neutron irradiation. Technical feasibilities of this configuration are preliminarily analyzed on the independent liner enclosure structure, maintenance scenarios using remote handling systems, and etc. Further feasibility studies together with detailed design of major components and numerical simulations are expected to be performed in next design phases.

## Acknowledgments

This work has been carried out within the framework of the EUROfusion Consortium and has received funding from the Euratom research and training programme 2014-2018 under grant agreement No. 633053. The views and opinions expressed herein do not necessarily reflect those of the European Commission.

## References

- [1] A. Ibarra et al., A stepped approach IFMIF/EVEDA towards IFMIF, Fusion Science and Technology, 66 (2014) 252-259
- [2] J. Knaster et al., IFMIF, the European-Japanese efforts under the Broader Approach agreement towards a Li(d,xn) neutron source: Current status and future options, Nuclear Materials and Energy, 9 (2016) 46-54
- [3] K. Tian et al. The test cell configuration under IFMIFDONES condition, Fusion Engineering and Design, 124 (2017), 1112-1117
- [4] J. Knaster et al., The accomplishment of the Engineering Design Activities of IFMIF/EVEDA: The EuropeanJapanese project towards a Li(d,xn) fusion relevant neutron source, Nuclear Fusion 55(8)(2015) 086003
- [5] K. Tian et al., Engineering design of the IFMIF EVEDA reference test cell and key components, Fusion Engineering and Design, 89 (2014) 1694-1698
- [6] Y. Qiu, et al., Neutronics assessment of different quench tank location options in IFMIF-DONES, Fusion Engineering and Design, 124 (2017), 1059-1062
- [7] K. Tian et al., Progress of Interface Design between Test Cell and Lithium Systems in IFMIF-DONES, presented in 27th Symposium on Fusion Engineering (SOFE), 4-8 June 2017, Shanghai, China
- [8] K. Tian et al., Overview of the current status of IFMIFDONES test cell biological shielding design, Fusion Engineering and Design, in press, online available under https://doi.org/10.1016/j.fusengdes.2018.03.043
- [9] Y. Qiu et al., Neutronics Analyses on the Bio-shield and Liner of the IFMIF-DONES Test Cell, accepted by 30th Symposium on Fusion Technology (SOFT 2018), Sept. 1621, 2018, Giardini Naxos, Sicily-Italy
- [10] Y Morishima, Re-weldability of neutron irradiated Type 304 and 316L stainless steels, Journal of Nuclear Materials 329-333(2004)663-667
- [11] F. Martín-Fuertes, M.E. García, S. García, Safety Specifications Guideline, EUROfusion IDM document:

EFDA\_D\_2NAS5Y (2017)

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ author's email: kuo.tian@kit.edu