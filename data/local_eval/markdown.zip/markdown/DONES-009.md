<!-- image -->

WPENS-CPR(17) 17297

K. Tian et al.

## Overview of the Current Status of IFMIF-DONES Test Cell Biological Shielding Design

Preprint of Paper to be submitted for publication in Proceeding of 13th International Symposium on Fusion Nuclear Technology (ISFNT)

<!-- image -->

This work has been carried out within the framework of the EUROfusion Consortium and has received funding from the Euratom research and training programme 2014-2018 under grant agreement No 633053. The views and opinions expressed herein do not necessarily reflect those of the European Commission.

This document is intended for publication in the open literature. It is made available on the clear understanding that it may not be further circulated and extracts or references may not be published prior to publication of the original when applicable, or without the consent of the Publications Officer, EUROfusion Programme Management Unit, Culham Science Centre, Abingdon, Oxon, OX14 3DB, UK or e-mail Publications.Officer@euro-fusion.org

Enquiries about Copyright and reproduction should be addressed to the Publications Officer, EUROfusion Programme Management Unit, Culham Science Centre, Abingdon, Oxon, OX14 3DB, UK or e-mail Publications.Officer@euro-fusion.org

The contents of this preprint and all other EUROfusion Preprints, Reports and Conference Papers are available to view online free at http://www.euro-fusionscipub.org. This site has full search facilities and e-mail alert options. In the JET specific papers the diagrams contained within the PDFs on this site are hyperlinked

## Overview of the Current Status of IFMIF-DONES Test Cell Biological Shielding Design

Kuo Tian a* , Begoña Ahedo b , Frederik Arbeiter a , German Barrera b , Lukasz Ciupinski c , Tamás Dézsi d , Jonathan Horne e , Dániel Kovács d , Joaquin Molla b , Fernando Mota b , Yuefeng Qiu a , Florian Schwab a , Marcin Siwek c , Mátyás Tóth f , Tamás Varga g , Angel Ibarra b

a Karlsruhe Institute of Technology (KIT), Karlsruhe, Germany b Centro de Investigaciones Energeticas Medioambientales y Tecnologicas (CIEMAT), Madrid, Spain c Warsaw University of Technology, Warsaw, Poland d Wigner RCP / C3D Ltd., Budapest, Hungary e RACE, Culham Science Centre, Abingdon, United Kindom f HAS, Wigner Research Centre for Physics, Budapest, Hungary g Wigner RCP / Fuziotech Ltd., Budapest, Hungary

The IFMIF-DONES (International Fusion Material Irradiation Facility - Demo Oriented NEutron Source) test cell (TC) biological shielding, including surrounding shielding walls, two top shielding plugs, six piping and cabling plugs (PCPs), TC floor, and removable shielding materials below the TC floor, is responsible of providing sufficient protect for the surrounding rooms and cells from intensive neutron irradiation and gamma radiation from inside of the TC. Based on the previous TC configuration, the design of the lower shielding plug has been further developed by defining the specifications of embedded helium active cooling systems with the support of neutronic simulations, CFD analysis, and remote handling requirements. The PCP design is updated to provide sufficient space for pipe and cable connections. A preliminary piping of the water cooling system inside the heavy concrete shielding walls has been performed to qualify the capability of removing volumetric nuclear heating during irradiation experiments. The geometry of TC surrounding shielding walls are adjusted according to the latest design of PCPs and LSP as well as the requirements of the active cooling pipes which are embedded in the TC surrounding walls.

Keywords: IFMIF-DONES, Neutronics, Fusion, Irradiation, Biological Shielding

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## 1. Introduction

As an intensive fusion-like neutron source with the objective of qualifying structural materials that will be used in the DEMO fusion reactor, IFMIF-DONES (International Fusion Material Irradiation Facility- Demo Oriented Neutron Source) facility is planned to deliver up to 10 14 n/(cm 2 s) neutron flux to material specimens by the interaction of one 40 MeV 125 mA deuteron beam and a flowing liquid lithium (Li) target [1,2]. The engineering design of IFMIF-DONES is currently performed under WPENS (Work Package Early Neutron Source) project in the framework of EUROFusion activities.

The Test Cell (TC) in the IFMIF-DONES facility is the central confinement to envelop the end section of the accelerator, the high flux test module (HFTM), the lithium Target Assembly (TA), and other lithium system (LS) components [3]. The major functions of the TC include: hosting fusion material irradiation experiments in a leak-tight controlled environment, providing sufficient shielding to surrounding rooms and cells against the in-TC neutron and gamma irradiation, and allowing media (mainly lithium and helium) and signal/power penetrations between inside and outside of the TC. The design of the IFMIF-DONES TC has been initiated based on the reference design of IFMIFEVEDA phase [4,5] and has been developed with further options to solve the potential issues of the lithium flow cavitation and neutron streaming to LS areas [3,6]. An updated IFMIF-DONES TC reference design has been proposed [6] and an exploded view of the cross-section of the IFMIF-DONES TC is shown in Fig.1. In the latest design, the quench tank has been relocated to TC inside, and a TC-LS interface cell (TLIC) has been defined below the TC floor to accommodate thermal compensation helium pipe sections and additional removable shielding materials [6].

Inside the TC, the high energy deuteron beam impacts on the flowing lithium flow inside the TA to generate intense neutron to perform irradiation experiments of material specimens inside HFTM. In the IFMIF-DONES building, the TC is planned to be surrounded by an access cell (AC) from above, the LS room underneath, and a target interface room, a tritium room, a helium room, a radiative waste storage cell, and a room for other physical applications at the same level. In the IFMIF-DONES design, all these rooms and cells are protected by TC biological shielding. The TC biological shielding includes: surrounding shielding walls of the TC, two top shielding plugs (TSPs), six piping and cabling plugs (PCPSs), the TC floor, and removable shielding materials below the TC floor and in the TLIC. The TSPs are separated to two layers, known as upper shielding plug (USP) and lower shielding plug (LSP) respectively, as shown in Fig.1. The removable shielding materials inside TLIC are not shown in the figure. In this paper, the specification of TC floor and the removable shielding materials are not discussed.

Fig. 1 Exploded view of IFMIF-DONES TC reference design with cross section of the TC surrounding wall

<!-- image -->

Due to intense neutron irradiation inside the TC, significant nuclear heating is applied to the biological shielding components. The nuclear heating analysis of the TC biological shielding in IFMIF-EVEDA condition can be found in [7]. In the current TC design, the surrounding shielding walls and TC floor are actively cooled by water, while the LSP is cooled by helium.

The development of the engineering designs of the current IFMIF-DONES TC biological shielding components are performed under closed collaborations of different research institutes in European Union. Latest updated have been focused on geometry adjustment of the surrounding shielding walls, definition of water cooling system for the surrounding shielding walls, reconfiguration of the PCPs, detailed design of the LSP, and etc. An overview of these updates is summarized in this paper.

## 2. Test Cell Top Shielding Plugs

The IFMIF-DONES TC is a blend hot cell which can be accessed from top. LSP and USP close the TC and provide major radiation shielding function (together with PCPs) to the AC during the irradiation experiments periods. The total thicknesses of the TSPs are designed to be 2.5 meters. The USP has a dimension of 5.5 m (L) X 4.4 m (W) x 1.25 m (H) and a weight of around 120 tons, while the LSP has a dimension of 4.8 m (L) x 3.6 m(W) x 1.25m (H) m and a weight of 86 tons. Both USP and LSP are made of heavy concrete and are covered with stainless steel claddings. For the convenience of RH operations on the TSPs, all the vertical TC biological walls which surround USP and LSP have 1.5° outwards slop. The side walls of the USP and LSP have a corresponding 1.5° as well.

The LSP is actively cooled by helium through embedded cooling pipes to remove volumetric nuclear heating (~ 10.5 kW) generated by neutron irradiation and convective heat (~ 5 kW) from the TC inner atmosphere. A volumetric heat map for the heavy concrete is shown in Fig. 2. The USP is not actively cooled due to low heat generation rate (peak value &lt;10 -5 W/cm 3 ) even in the IFMIF-EVEDA case [8].

Fig. 2 Nuclear heat map in the lower shielding plug during the irradiation operation status (view from bottom)

<!-- image -->

Fig. 3 illustrates the key internal structure of the LSP. 3 layers of pipes were embedded in the heavy concrete. The 1st (lowermost) layer is welded directly to the bottom cladding; the 2nd layer sits on the top of conduction ribs (not shown on Fig.3) to enhance conductive heat transfer; and the 3rd layer is embedded into the concrete, without metallic connection to the cladding. Reinforcement inside the LSP is not shown in Fig. 3.

Fig. 3 Sturcture of lower shielding plug (LSP), without showing concrete reinforcement

<!-- image -->

Fig. 4. Temperature map of LSP under helium active cooling condition in the vertical cross-section in the beam direction

<!-- image -->

Thermal hydraulic simulation of the LSP has been performed to validate the effectiveness of the helium cooling system during the irradiation operation status. A preliminary calculation result is shown in Fig. 4. In this calculation, the helium flow is supposed to has an inlet temperature of 20 °C, a mass flow of 190 g/s, an inlet pressure of 0.8 MPa. The calculated helium gas outlet temperature is 35.7°C. From Fig. 4 one can observe that the peak temperature in the LSP concrete is around 72 °C, which is blow the maximum allowable temperature (90 °C) of heavy concrete during irradiation operation statuses. FEM analysis is also performed for the LSP and will be presented in separate publications.

## 3 Piping and Cabling Plugs (PCPs)

As part of the shielding components, six removable and independent PCPs are arranged around the LSP and USP, similar as the TC design of IFMIF-EVEDA phase [5]. The functions of the PCPs also include accommodating all of cable and gas pipe penetrations from the HFTM. Because IFMIF-DONES only plans to irradiate one HFTM in the first irradiation phase, only PCP-1 and PCP-4 will be connected to HFTM with helium and wire connections. All other PCPs only bear shielding function. Respecting the similarity between the designs of the PCPs, only the PCP-1 design is described in this paper as an example, as shown in Fig. 5.

In the current IFMIF-DONES TC design, the PCPs are composed of heavy concrete and covered with closed stainless steel claddings. From the geometry point of view, the PCPs are designed to have several horizontal and vertical steps in all three directions to minimize neutron streaming from inside of the TC during the irradiation operation statuses [9]. Four inlet helium pipes (DN40), one outlet helium pipes (DN100), and one cable channel (DN100) is embedded in the PCP. Because the gas temperature inside the helium outlet pipe will be around 120°C during irradiation operation statuses, thermal insulation materials must be applied between the pipe wall and concrete materials to avoid additional heating release to the PCP. The total nuclear heating generated in PCP is around 300 W [7] in IFMIF-EVEDA case, and is supposed to be removed through the inlet helium flow (at 50°C), conduct heat transfer between PCP and TC liner, and heat rejection to other adjacent components, e.g. LSP. Detailed thermal and structural analysis (FEM) of the PCPs will be performed in the next design phases.

Fig. 5 Illustration of PCP design in IFMIF-DONES TC

<!-- image -->

In order to minimize neutron steaming through these hollow channels, each pipe/tunnel is designed to have several bends in different direction inside the PCP [9]. Compared to the previous PCP design in IFMIF-EVEDA phase [5], the lower end of the PCP has been extended in X direction to provide sufficient accommodation for pipe and cable tunnel connections. In spite of one step less in the X direction, neutron streaming is not foreseen significantly increased due to existing multi-stepped configuration of the PCP geometry. Correspondingly, the internal geometry of the TC walls is adjusted to accommodate the new designed PCPs. The Detailed and optimized piping inside the PCPs and neutron shielding function of the PCPs are subjected to be validated in future neutronic simulations.

## 4. Test Cell Surrounding Shielding Walls

The surrounding shielding walls of the TC are the primary biological shielding of the TC to protect the surrounding rooms and cells against neutron and gamma radiation. Magnetite concrete is selected as the primary material of the surrounding shielding walls. The thickness of the concrete surrounding shielding wall at the beam direction is designed to be 4.0 meters while at the lateral direction at least 3.5 meters to assure the dose outside the biological shielding below 7.5 µSv/h during the irradiation periods of the IFMIF-DONES. The wall thickness of the beam upstream direction is 3.0 meters and TC floor thickness is 2.0 meters. A dose map around the TC surrounding shielding walls during the irradiation operation status is illustrated in Fig. 6.

Fig. 6 Horizontal dose map in the surrounding shielding walls at the beam level during the irradiation operation status

<!-- image -->

It must be pointed out that the wall thickness of the TC can be further reduced depends on the final definition of the zoning of the surrounding rooms and cells. For instance, if the adjacent rooms in the beam direction is defined as red zone (&gt; 100 mSv/h), the wall thickness in the beam direction can be reduced to less than 3 meters.

The complete interior surfaces of the TC walls are covered by closed stainless steel liner as leak tight boundary and the second barrier for lithium flow. In the current TC design, the surrounding shielding walls as well as the liner of the TC are actively cooled by water to remove volumetric nuclear heating. Neutronic calculations have estimated a peak value of 68.2 mW/cm 3 volumetric heating in the concrete in beam's downstream direction. As the preliminary design, major technical specifications of water cooling system are identified, topology of piping is defined, and thermal hydraulic simulations on the effectiveness of the cooling system has been started.

The first simulation has focused on an "L"-shaped 1 meter thick concrete block wall section which covers part of the wall in the beam direction (X) and part of the lateral wall, as shown in Fig. 7(a) and (b). The upper surface of the selected volume is at the same height of the beam level, as shown in Fig. 78(b). Compared with other concrete parts of the surrounding walls, this section receives highest neutron irradiation and has the highest nuclear heating density. Fig. 7(b) shows the nuclear heating distribution in this selected concrete section.

<!-- image -->

(a)

Fig. 7 Top view of the concrete section to be analyzed (a), and the corresponding nuclear heating during irradiation operiation statuses (b)

<!-- image -->

The current piping topology and simulated temperature distribution in the controlled volume is shown in Fig. 8. The water cooling pipes are designed to be horizontally arranged inside the concrete along the development of the internal surface of the TC. Regarding the heat load distribution inside concrete, active cooling pipes are only arranged in the first 1 meter thickness of the wall. In the current design, the pipes are grouped to eight rows with different pipe density, as shown in Fig. 8. All pipes will be made of 316L stainless steel with an inner diameter of 20 mm and wall thickness of 1.5 mm. The internal corners of the TC internal surfaces is rounded off with a radius of 200 mm for convenient piping at the corner inside the TC wall. Cooling water is provided to the TC biological shielding at 30°C and 2 m/ s. Preliminary thermal hydraulic calculation results, as shown in Fig. 8, demonstrated that the peak temperature (44 °C) is far below the maximal allowable temperature of heavy concrete, i.e. 90 °C, under the current design configuration. The piping topology inside the TC wall in this region could be further optimized to reduce the number of pipes and number of pipe rows. The adjustment of a more balanced option will be investigated in in next design phases.

Fig. 8 Calculated temperature map in analyzed volume with indication of pipe topology

<!-- image -->

## 5. Summary

The engineering design of the IFMIF-DONES TC has been further developed with the emphases on design update of the major biological shielding components, the lower shielding plug (LSP), piping and cabling plugs (PCPs), and surrounding shielding walls. Helium cooling systems inside the LSP has been preliminary defined, thermal hydraulic calculation proves the helium cooling system is capable of removing nuclear heating and keeping the concrete temperature under limit. The design PCP is updated by expanding the lower section areas to accommodate pipe connections and cable tunnel entrance as well as to provide effective neutron shielding. The configuration of active water cooling pipes buried in the TC surrounding shielding walls are preliminarily defined, and the cooling capability of the system is proved by numerical thermal analysis on the concrete block which receives highest nuclear heating. The geometry of the TC interior surfaces has been adjusted to allow convenient arrangement of the pipes at corners and to accommodate newly designed PCPs. Further numerical simulations, including thermal hydraulic, neutronic, and FEM calculations, are expected to be performed in next design phases to optimize the design of neutron shielding components and the corresponding cooling systems.

## Acknowledgments

This work has been carried out within the framework of the EUROfusion Consortium and has received funding from the Euratom research and training programme 2014-2018 under grant agreement No. 633053. The views and opinions expressed herein do not necessarily reflect those of the European Commission.

## References

- [1] A. Ibarra et al., A stepped approach IFMIF/EVEDA towards IFMIF, Fusion Science and Technology, 66 (2014)

252-259

- [2] J. Knaster et al., IFMIF, the European-Japanese efforts under the Broader Approach agreement towards a Li(d,xn) neutron source: Current status and future options, Nuclear Materials and Energy, in press,
- [3] K. Tian et al. The test cell configuration under IFMIFDONES condition, Fusion Engineering and Design, in press
- [4] J. Knaster et al., The accomplishment of the Engineering Design Activities of IFMIF/EVEDA: The EuropeanJapanese project towards a Li(d,xn) fusion relevant neutron source, Nuclear Fusion 55(8)(2015) 086003
- [5] K. Tian et al., Engineering design of the IFMIF EVEDA reference test cell and key components, Fusion Engineering and Design, 89 (2014) 1694-1698
- [6] K. Tian et al., Progress of Interface Design between Test Cell and Lithium Systems in IFMIF-DONES, presented in 27th Symposium on Fusion Engineering (SOFE), 4-8 June 2017, Shanghai, China
- [7] K. Kondo et al., Neutronic analysis for the IFMIF EVEDA reference test cell and test facility, Fusion Engineering and Design, 89(2014) 1758-1763
- [8] K. Tian et al., IFMIF test cell design: Current status and key components, Fusion Engineering and Design, 88(2013) 635-639
- [9] K. Kondo et al., Shielding performances analysis for the IFMIF test facility based on high-fidelity Monte Carlo neutronic calculations, Fusion Engineering and Design, 98-99(2015) 1998-2002