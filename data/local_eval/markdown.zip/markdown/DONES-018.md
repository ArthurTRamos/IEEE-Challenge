## BEAM DIAGNOSTICS FOR THE MULTI-MW HADRON LINAC IFMIF/DONES ∗

I. Podadera † , B. Brañas, A. Guirao, A. Ibarra, D. Jiménez, E. Molina, J. Molla, C. Oliver, R. Varela, CIEMAT, Madrid, Spain P. Cara, Fusion for Energy, Garching, Germany

Abstract

In the frame of the material research for future fusion reactors, the construction of a simplified facility of IFMIF [2], the so-called DONES (Demo-Oriented Neutron Early Source) [1], is planned to generate sufficient material damage for the new design of DEMO . DONES will be a 40 MeV, 125 mA deuteron accelerator. The 5 MW beam will impact in a lithium flow target to yield a neutron source. The detailed design of the DONES accelerator is being pushed forward within EUROFUSION-WPENS project. One of the most critical tasks of the accelerator will be to identify the layout of beam diagnostics along the accelerator. This instrumentation shall guarantee the high availability of the whole accelerator system and the beam characteristics and machine protection. This contribution will describe the beam diagnostics selected along the accelerator, focusing on the High Energy Beam Transport line, in charge of shaping the beam down to the high power target. The main open questions will be analyzed and the path to obtain the detailed design by the end of the project described.

## ACCELERATOR DESCRIPTION

The linear accelerator for the DONES facility [1] will serve as a neutron source for the assessment of materials damage in future fusion reactors. Unlike the two coupled accelerators for the final IFMIF [2], DONES will be one accelerator, instead of two, accelerating deuterons up to 40 MeV at full CW current of 125 mA (Tab. 1). DONES is divided in three major systems: the particle accelerator, the target and the experimental area. The accelerator system is based on the design of LIPAC [3], which is currently in its commissioning phase [4]. The main sections are (Fig. 1):

- A Low Energy Beam Transport (LEBT) section at 100 keV to guide the low energy ions up to the RadioFrequency Quadrupole (RFQ) and match its injection acceptance.
- An RFQ to accelerate the ions from 100 keV up to 5 MeV.
- A Medium energy Beam Transport Line (MEBT) to match the RFQ extracted beam to the injection of the SRF Linac. It will also be used for matching the RFQ beam with the requirements of the Diagnostics Plate during the RFQ commissioning.

∗ This work has been carried out within the framework of the EUROfusion Consortium and has received funding from the Euratom research and training programme 2014-2018 under grant agreement No 633053

† ivan.podadera@ciemat.es

- An SRF Linac to bring the energy of the deuterons up to 40 MeV. It is made of four cryomodules, bringing the energy from 5 MeV up to 9 / 14.5 / 26 and 40MeV respectively at the exit of each cryomodule.
- A High Energy Beam Transport (HEBT) lines to transport the beam from SRF Linac towards the lithium target or the beam dump transport line (BDTL, in pulse mode).
- A Diagnostics Plate (DP) to commission the beam at medium and high energies. It will be located at the exit of the RFQ and SRF LINAC cryomodules during each beam commissioning stage.

Figure 1: Layout of the DONES accelerator system.

<!-- image -->

Table 1: DONES Main Beam Parameters

| Peak current  125 mA  RF frequency  175 MHz  Beam energy  0.1/5/9/14.5/26/40 MeV  β  0.01/0.073/0.097/0.12/0.165/0.2   |
|------------------------------------------------------------------------------------------------------------------------|

## BEAM DIAGNOSTICS REQUIREMENTS

The requirements of DONES pose several challenges to the beam diagnostics [5]. The normal operation mode of the accelerator will be in continuous (CW) mode, with an average beam current of 125mA at a bunch frequency of 175 MHz. An additional pulsed mode operation must be taken into account during the commissioning. The use of special interceptive diagnostics is required for this case (e.g. wire scanners, Faraday cups. . . ). A 0.1% duty factor is estimated for the pulsed mode, with a minimum pulse of 50 μs and a maximum one of 200 μs, as defined for LIPAC. The present plan assumes the operation with deuterons from the earliest stage. However a preliminary operation with protons is highly probable/almost mandatory, as it has been found/estimated beneficial at LIPAC. First of all, the availability of the accelerator system [6] is very important to guarantee the irradiation dose rate to the material samples. The monitors should be robust enough to monitor continuously and with high reliability the important beam parameters used to control and protect the machine during operation and tuning status. Therefore, the monitors should withstand the severe environment conditions of the beamline, especially regarding the high neutron and gamma radiation. On the other hand, due to the compactness of the design, special beam diagnostics devices cannot be integrated along the beamline.Therefore, the beam cannot be fully characterized once the accelerator is fully assembled. As a consequence of this design decision, it is of highly importance to well characterise each acceleration stage prior to move forward.

## BEAM DIAGNOSTICS LAYOUT

The beam diagnostics design is based on the monitors designed and installed for LIPAC. In the injector [7], the MEBT [8] and the first cryomodule of the SRF Linac [8, 9], the diagnostics integrated should be in principle identical to the ones used there.

## High Energy Beam Transport Line

The distribution of the monitors along the HEBT is based on the beam dynamics design [10]. The beamline can be divided in three sections (Fig. 2): a section S1 before the dipole which directs the beam to the target, a section S2 which transforms the beam phase-space using octupoles and dodecapoles, and a section S3 which makes the beam imping in the right spot. This section passes through two separate rooms: the Radiation Isolation Room (RIR) and the Target Isolation Room (TIR), before colliding with the target. Along section S1 the monitors are focused in monitoring the beam from the SRF Linac. The following properties should permanently monitored to be sured the right beam is delivered to the target: DC current, mean energy and transverse size. In section S2 it is very important to control the profile and position of the beam at each multipole magnet. In section S3 the essential points are: 1) to point the beam to the center of the target. This can be achieved by using RF pickups tuned to the fundamental frequency, 2) to control the size and uniformity of the transverse profile.

## PRELIMINARY DESIGN OF MONITORS

## Beam Position

BPM's in the HEBT will be longer than in LIPAC, due to the higher energy, and a bigger longitudinal space should be reserved in the beamline. In the last section of the HEBT, at least three beam position monitors should be located to steerer the beam into the target. In addition, due to the big beampipe aperture (at least 300mm) and the high debunching effect in this area, the measurement of the position will be challenging. First studies have been carried out in order to check the feasibility of BPM's in this area, without any need of installing a re-buncher cavity. Fig. 3 shows the signals in the electrodes simulated for a BPM in the last HEBT section. Using the real BPM stimulus, an output of around 20 mV is obtained, which should be enough for a reliable measurement. Once the distance to the acquisition electronics is set, it should be taken into account to evaluate the impact on the signal strength.

## Mean Energy

Figure 4 plots the accuracy of the energy measurement as function of the distance between pickups 1 and 2. A phase accuracy of 2° and a distance accuracy of 100 μm is assumed. With pickup separations above 0.5m, the error is kept below 1%, which represents 50 keV at 5MeV beam energy and 400keV at 40MeV. To get smaller values at high energy, the diagnostics plate should be longer than in LIPAC. A length between BPM's of 2.5-3m is proposed for the Diagnostics Plate during the commissioning. With 3m length, the error is kept below 50 keV for a phase accuracy of 2% and a length accuracy of 100 μm.

## Transverse Profile

One of the most specific instrumentation for DONES is the development of a transverse beam profile close to the 40 MeV lithium target, at the TIR of the HEBT at 40MeV. There, the DONES beam profile must have a rectangular shape of 20 cm wide and 5 cm height or alternatively 10 cm wide and 5 cm height. A non-interceptive monitor was already studied in the frame of EFDA-IFMIF activities [11]. The non-interceptive profiler should monitor permanently the square size of the target, the edges of the rectangular shape, and the flatness of the profile. At the moment two are the most promising candidates: a monitor based on the residual gas fluorescence [12], and one based in the residual gas ionization [13]. Both monitors are being installed in the HEBT beamline of LIPAC for comparison and feedback. In parallel, more experiments are planned to advance in the verification of the use of those monitors in DONES.

## CONCLUSIONS AND OUTLOOK

A complete list of the beam diagnostics for DONES has been elaborated and presented as a basis for the detailed design of the accelerator system. The list has taken into account all the important aspects of the accelerator: the availability and reliability of the system, the radiation resistance, the beam dynamics requirements, and the mechanical integration. For the more critical devices several simulations and calculations have been performed before validating the complete system.

Future activities will include the assessment of beam loss monitors along all the accelerator system, especially in the RIR/TIR areas. A very important work will be detailing the requirements and design of the beam profile diagnostics in the TIR. Feedback from the beam commissioning from LIPAC is of utmost importance for considering any change in the list and type of diagnostics proposed. Unlike LIPAC, there should be a risk assessment of the beam diagnostics proposed all along the accelerator, but especially inside the SRF Linac. Last but not least, a preliminary mechanical design of the more critical areas shal be elaborated in order to validate the integration of the diagnostics proposed.

Figure 2: Preliminary schematic of the beam diagnostics proposed at the exit of the cryomodule.

<!-- image -->

Figure 3: Simulation of the response of the last BPM in the TIR.

<!-- image -->

Figure 4: Accuracy of the mean energy measurement vs the distance between phase monitors for the different commissioning stages of the accelerator facility.

<!-- image -->

## DISCLAIMER

Views and opinions expressed herein do not necessarily reflect those of Fusion for Energy.

## REFERENCES

- [1] A. Ibarra et al., "DONES Conceptual Design Report", Apr. 2014
- [2] A. Ibarra et al., "IFMIF Intermediate Engineering Design report", Broader Approach, Rep. 23VD38, Jun. 2013
- [3] P. Cara et al., "The Linear IFMIF Prototype Accelerator (LIPAc) design development under the European-Japanese collaboration", Proc. of IPAC 2016, Busan, Korea.
- [4] J. Knaster et al., "The installation and Start of Commissioning of the 1.1 MW Deuteron Prototype Linac for IFMIF", Proc. of IPAC 2014, Shanghai, China.
- [5] J. Marroncle et al., "IFMIF-LIPAc Diagnostics and its Challenges", Proc. of IBIC 2012, Tsukuba, Japan, 2012.
- [6] J.M. Arroyo et al., "Hardware availability calculations and results of the IFMIF accelerator facility", Fus. Eng. Design 89, 9-10, pp. 2388-2392, 2014.
- [7] B. Bolzon et al., "Beam Diagnostics of the LIPAC Injector With a Focus on the Algorithm Developed for Emittance Data Analysis of High Background Including Species Fraction Calculation ", TUPB008, Proc. of IBIC 2015, Melbourne, Australia, 2015.
- [8] I. Podadera et al., "Status of the Beam Position Monitors for LIPAc", MOPC019, Proc. of IBIC 2013, Oxford, UK, 2013.
- [9] J. Marroncle et al., "R&amp;D on Micro-Loss Monitors for High Intensity Linacs like LIPAc's ", Proc. of HB2016, Malmo, Sweden, 2016.
- [10] C.Oliver et al., "Phase-Space Transformation for a Uniform Target Irradiation at DONES", LINAC 2016, 2016.

- [11] E. Surrey et al., "A beam profile monitor for IFMIF reference", EFDA TW5-TTMI-001, 2006
- [12] J.M. Carmona et al., "Measurements of noninterceptive fluorescence profile monitor prototypes using 9 MeV deuterons", Phys. Rev. ST Accel. Beams 15, 072801, 2012.
- [13] J. Egberts, "IFMIF-LIPAc BeamDiagnostics. Profiling and Loss Monitoring Systems", PhD Thesis, IRFU-CEA Saclay, 2012.