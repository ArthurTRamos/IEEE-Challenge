<!-- image -->

WPENS-CPR(18) 20013

S. Gordeev et al.

## Numerical study of conjugated heat transfer for DONES high flux test module

Preprint of Paper to be submitted for publication in Proceeding of 30th Symposium on Fusion Technology (SOFT)

<!-- image -->

This work has been carried out within the framework of the EUROfusion Consortium and has received funding from the Euratom research and training programme 2014-2018 under grant agreement No 633053. The views and opinions expressed herein do not necessarily reflect those of the European Commission.

This document is intended for publication in the open literature. It is made available on the clear understanding that it may not be further circulated and extracts or references may not be published prior to publication of the original when applicable, or without the consent of the Publications Officer, EUROfusion Programme Management Unit, Culham Science Centre, Abingdon, Oxon, OX14 3DB, UK or e-mail Publications.Officer@euro-fusion.org

Enquiries about Copyright and reproduction should be addressed to the Publications Officer, EUROfusion Programme Management Unit, Culham Science Centre, Abingdon, Oxon, OX14 3DB, UK or e-mail Publications.Officer@euro-fusion.org

The contents of this preprint and all other EUROfusion Preprints, Reports and Conference Papers are available to view online free at http://www.euro-fusionscipub.org. This site has full search facilities and e-mail alert options. In the JET specific papers the diagrams contained within the PDFs on this site are hyperlinked

## Numerical study of conjugated heat transfer for DONES high flux test module

Sergej Gordeev, Florian Schwab, Frederik Arbeiter, Yuefeng Qiu

Karlsruhe Institute of Technology, Karlsruhe, Germany

Helium flows at low pressure (3 bar) are used to cool the specimen capsules and the structure of the neutron irradiated High Flux Test Module (HFTM) of the DEMO-Oriented Neutron Source (DONES). The flow path includes inlet and outlet ducts with large cross sections, but also mini-channels with gap widths less than 1 mm, where a high velocity low Reynolds number flow influences the temperature of the irradiated specimens. The aim of the study was the achievement of thermal requirements to the HFTM. The large span of Reynolds numbers from laminar to fully turbulent is a significant challenge for the simulation of the complete HFTM. A number of turbulence models were tested using experimental results obtained in the ITHEX (IFMIF Thermal-Hydraulic Experiment) experimental facility. Reynolds Stress (RSM ) and k-ω Shear Stress Transport (SST) models are able to reproduce the heat transfer within the Reynolds number range between 4500 and 10000.

Simulations show that in case of 100% nuclear heating conditions the prescribed temperature of specimen can be achieved by justification of electrical power and variation of helium mass flow rate for each HFTM compartment..

Keywords: DONES, High Flux Test Module, heat transfer, mini channel flow, turbulence modeling.

## 1. Introduction

IFMIF-DONES (International Fusion Materials Irradiation Facility- DEMO Oriented NEutron Source) [1], [2] is a IFMIF-based neutron irradiation facility which aims at providing the irradiation data required for the construction of a DEMOnstration fusion power plant (DEMO). DONES consists of only one of the IFMIF

accelerators (40 MeV and 125 mA), and utilizes only the High Flux Test Module (HFTM) [3] for the irradiation of material specimens. The HFTM is the key component to provide the material irradiation data which fulfil the mission of DONES. The irradiation is planned at several blanket-relevant irradiation temperatures and shall accumulate structural damage of up to 50 displacements per atom (dpa) per campaign.

<!-- image -->

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

The overall structure of the HFTM is illustrated in Fig. 1. The space for irradiation is behind the 20 cm width x 5 cm height beam footprint, with a maximum neutron flux of 1×10 15 n/cm 2 /s and nuclear volumetric heating up to 1.82x10 7 W/cm³ [4]. In this region, the outside structure is a thin walled (2 mm) container subdivided by stiffening plates into 8 compartments. Each compartment contains 4 capsules with specimens. Mini-cooling-channels are integrated in the container walls and stiffening plates. The capsules and the container are cooled by a low pressure (0.35 MPa abs., 50 °C at inlet) high speed helium gas flow. The flow direction of the helium coolant is possible in two directions. In the current case the cold helium streams from the top through the attachment adapter and cooling channels into 8 outlet pipes. The mass flow rate for each compartment is controlled depending on the required specimen and container-structure temperature. To reduce the thermal resistance in the specimen stack, liquid sodium fills up the space within the capsule. Three sections of electric heaters are wound around the capsules with a total vertical heating length of about 120 mm. In between the heated capsules and cooled container walls is an insulation gap with stagnant helium. In beam direction the thickness of the insulation gap is variable between 0 and 1 mm. In lateral direction the insulation gap measures 2 mm.

The following requirements (rooting in irradiation objectives and facility boundary conditions) to the HFTM operation have been considered in the present study:

- Control the specimen temperature at defined levels between 250 and 550 °C. The temperature spread within the specimen stack of one irradiation capsule shall be limited to ±3% relative to the absolute (Kelvin) temperature (in 80% of the available volume - cold corners without specimen loading can be accepted);
- The maximal possible mass flow rate of helium should be less or equal t o180 g/s for all compartments;
- The maximal allowed electrical heating is 1000 W (180V) per heater coil;
- The temperature of the container structure is limited by 150°C (maintain strength and reduce swelling).

## 2. 2. CFD analysis of HFTM

## 2.1 Selection of turbulence models

The Reynolds (Re) number of the flow in HFTM cooling channels varies from 1000 to 10000. Previous works have explored those flow conditions and respective simulations [5]. The present validation activity is based on an up-to-date numerical tool, and focuses on the meshing requirements (to handle large models) and effects of secondary flows. A number of Reynolds-Averaged Navier-Stokes (RANS) turbulence models offered in the commercial CFD code StarCCM+ [6] were tested using

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

experimental results obtained in the ITHEX (IFMIF Thermal-Hydraulic Experiment) experimental facility [7]. The annular cooling channel of the ITHEX test section is formed by two concentric cylindrical bodies with embedded electrical heaters. The channel thickness of 0.6 mm is similar to those in HFTM. Four turbulence models have been selected for the validation, the Reynolds Stress transport (RSM) model known as second-moment closure model; the two equation Realizable k-ε (RKE) model; the k-ω Shear-Stress-Transport (SST) model and the four equation V2F model. More detailed discussion of all four models can be found in [3].

The grid dependency was studied using the near wall mesh spacing across the flow channel. The nondimensional wall distance y + was fixed by 0.2, 1 and 3 for the fine meshes and 20 for the coarse mesh.

The comparisons were made between the experiments and simulations for the inner and outer cylinder wall temperatures measured at six thermocouple positions. It was found that, for the Re number equal or less than 4500, the flow is essentially laminar. For Re numbers between 4500 and 6000, the flow has a transitional character. For Re of about 10000, the flow is turbulent. Simulation results show that RSM and SST models are appropriate for the full range of Re numbers. In the SST model the turbulent time scale is calculated using Durbin's realizability constraint, implemented into the eddy viscosity formulation. The best predictions have been achieved with the variable constraint with continuous decreasing from the standard value of 0.66 for "turbulent" case (Re=10000) down to 0.31 for the "laminar" case (Re=4500). Both, the RSM and the SST (non-linear formulation) models are able to reproduce the secondary flows in the channels with rectangular cross sections.

## 2.2 Geometry and boundary conditions of HFTM model

The 3D-CAD geometry model of HFTM developed in Karlsruhe Institute of Technology (KIT) [8] was used for the meshing. The computational domain (see fig. 2) includes the inlet adapter with two inlet pipes, 8 compartments separated by stiffening plates with minicooling channels and the outlet piping. As shown in fig. 2, 6 compartments are filled with capsules. Each compartment contains 4 capsules. Two other compartments contain reflectors. Each capsule is wrapped with three heaters modelled as 1 mm thick layer with a height of about 40 mm each. Structural material for capsules, reflectors and specimen is EUROFER-97, for compartment walls and heaters SS316 (AISI 316 LN). In between the capsules outer surface and the cooled stiffening plates there are insulation gaps with a maximum thickness of 1 mm in beam direction and 2 mm in the transverse direction. The insulation gap is modelled as solid medium with helium thermal properties. Thermal radiation across the insulation gaps is considered. The emissivity of 0.6 was taken into account for steel materials.

Fig. 2. Computational domain of HFTM

<!-- image -->

The thermal conductivity of solid materials varies with temperature. Helium is assumed as an ideal noncompressible gas. The viscosity and thermal conductivity of helium are also taken as a function of temperature.

The nuclear heating data for the simulation is obtained from neutronic calculations Y. Qiu et al.[9]. The nuclear heating distribution was subdivided in different regions depending on the structural materials used in the model:

- Eurofer for reflectors and capsules;
- 75% Eurofer and 25% Sodium for specimen stack;
- Mixed Eurofer and heater wires for heater layers;
- SS316L for the HFTM structure

The helium inlet pressure is 3.3 bar with a temperature of 50°C. The mass flow rate is adjusted depending on the required specimen and containment structure temperature. The required specimen temperatures for each compartment are shown fig. 2. Following initial helium mass flow rates were determined: for compartments 1 and 8 - 10g/s, for compartments 3 and 6 - 16g/s, for compartment 5 - 24 g/s and for compartment 4 - 32 g/s.

The heat transfer interaction between HFTM and the target was taken into account by modelling of the target back plate structure with the temperature distribution obtained from thermal-structural calculations performed in the University of Palermo [10]. Preliminary simulations have shown nearly stagnant helium flow in the 1 mm thick gap between the back plate outer surface and the HFTM container wall, so the conductive heat transfer will be dominating. For this reason the heat transfer within the gap is simulated using solid material with helium thermal properties. Also here the contribution of the thermal radiation was included in the heat transfer. The heat loss from the remaining outer surface of HFTM to the test cell

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

is simulated assuming a natural convection with the heat transfer coefficient of 5 W/m²/K ambient atmosphere temperature of 50°C.

The near wall y + value within the mini-cooling channels ranges from 0.8 to 3. The total cell number is about 30 million for the fluid domain and 20 million for the solid structure. The CFD simulations were performed with the SST turbulence model with realizability constant of 0.55.

## 2.3 Simulation results, thermal design optimization

The study was focused on the reference case with 100% nuclear heating. The total helium mass flow rate is 128 g/s, which accounts for 71% of the maximal mass flow rate allocated for the HFTM. The electrical heating was taken from previous "single compartment" simulations [7].

The first analysis of the temperature distribution in the specimen showed that in compartments 3, 6 (350°C), 5 (450°C) and 4 (550°C) exceed the intended values even when the electrical heaters in the middle position are deactivated. Since the heat transfer across the insulation gaps significantly impacts on the specimen temperature, reducing of the gap thickness can decrease the specimen temperature without increasing of the helium flow rate. On the other hand, in regard to the maximal allowed compartment temperature of 150°C, the increased heat transfer between the specimen capsules and compartment walls is not desired. Therefore the combination of two ways, increase of the helium mass flow rate and reducing of insulation gap thickness is applied. The mass flow rate for compartments 3 and 6 was increased up to 24 g/s and for compartments 4 and 5 up to 40 and 32 g/s respectively. Thereby the total helium mass flow rate accounts 160 g/s. The insulation gap thickness in compartments 3 and 6 was reduced down to 0.6 mm and in the compartment 5 to 0.8 mm. With the subsequent adaptation of the electrical heating powers, the required average temperatures are achieved in all compartments. The electrical heating power varies between 50 and 575 W. The maximal heating is generated by the electrical heater in the capsule placed in the last irradiation row of the compartment 4. The maximum and minimum temperatures of specimen are shown in table 1. In all capsules the specimen temperatures fit the requirement of the ±3% variation in temperature referred to absolute temperature. For compartments 3 to 6 the maximal temperature in capsules placed in the first irradiation row is located in the middle part of the specimen volume. In all of these capsules the power of the middle electrical heaters is limited by the minimal value of 50W. Further reducing of the electrical power is foreseen for the abnormal operation case with 110% of nuclear heating (is not considered in this study).

Table 1. Calculated temperature distribution in specimen

| Comp.  (Tref.)  Tmax.,  °C  Tmin.,  °C  ΔT,  K  ΔTmax,  % Tref.  K  ΔTmin,  % Tref. K  1 and 8  (250°C) 253  246  7.0 0.5  0.76  3 and 6  (350°C) 369  339  30.  0  3.0  1.76  4 (450°C) 465  435  30.  0  2.0  2.0  5 (550°C) 568  545  23.  3  2.2  0.61   |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

Fig.3. Temperature distribution in HFTM structure (left) hot spots on the inner container walls (right)

<!-- image -->

Figure 3 represents the temperature distribution in the container structure. On the surfaces of long side stiffening plates of the compartments 4 and 5 there are small areas with the slight overshot of about 7° C over the maximal allowed temperature for compartment structure material. Affected are the walls between capsules. The location of the hot spots corresponds with the position of the division walls between the mini-cooling channels. The reason is the insufficient cooling of the structure near the division walls. The reducing of the heat transfer is caused by the thickening of the boundary layer in the flow near the channel corners and thus reducing of the local mass flow rate. The intensity of secondary flows induced by channel

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

corners with the magnitude of about 2% of the primary flow velocity is not sufficient for the enhancement of the heat transfer at the division walls.

The axial velocity distribution on the cut-plane near the exit of mini channels is shown in fig. 4. Velocity magnitudes differ from compartment to compartment according to predefined mass flow rate in the outlet piping. Also inside of each compartment the helium flow is redistributed. Generally the velocity magnitude in the long-side channels is about 35% higher than in the shortside channels. As result of different axial velocities and different hydraulic diameters the Re numbers in channels vary from 1500 to 10200. Table 2 shows the Re numbers of the channel flow calculated near the exit (z=-90 mm).

Fig.4 Axial velocity (vector presentation) distribution on the cutplane near the exit of mini channels (z=-90 mm)

<!-- image -->

Table 2. Reynolds numbers of the channel flow near the exit

| Comp.  1, 8  3, 6  4  5  Re, Long-side 2300 6000  10200 8200  Re, Short side 1500 3800  6450  5200   |
|------------------------------------------------------------------------------------------------------|

Fig. 5. Wall normal distribution of the turbulent kinetic energy in channel flow near the exit (z=90 mm)

<!-- image -->

The diagram in fig. 5 shows the distribution of the turbulent kinetic energy in the cross section of mini channels near the exit. In channels of compartments 1 and 8, where Re &lt; 3000, the turbulent kinetic energy is close to zero (laminar flow). In the channels of compartments 3,

4 and 6 the flow have a transitional character and varies from nearly laminar flow in the short-side channel of compartments 3 and 6 to the developed turbulent flow in the long-side channels of compartments 4 and 5. The behaviour of the channel flow predicted by SST turbulence model is in agreement with validation results mentioned in the section 2.1.

Fig. 6 shows the absolute pressure drop for different compartments. Due to higher mass flow rate, the maximal pressure loss in compartment 4 is of about 0.7 bar, the minimal value of about 0.06 bar is observed in compartments 1 and 8.

Fig. 6. Absolute pressure drop downstream (from z=100 mm to z=-100 mm) of mini channels for different compartments.

<!-- image -->

## 3. Summary and Conclusions

Thermo-hydraulic analysis of whole DONES-HFTM was performed with the StarCCM+ SST turbulence model.

The ability of the SST model to predict the heat transfer in mini-channel flow for Re number range between 4500 and 10000 was tested and confirmed by comparing simulations with ITHEX experiments.

Simulations show that in case of 100% nuclear heating conditions the helium mass flow rate in the compartments 1 and 8 with the prescribed temperature of 250°C has to be kept by 10 g/s, in compartments 3 and 6 (350°C) by 24 g/s, in compartment 5 (450°C) by 32 g/s and in compartment 4 by 40 g/s. Additionally to avoid the overheating of specimen the insulation gap thickness in compartments 3 and 6 was reduced down to 0.6 mm and in the compartment 5 to 0.8 mm. As result, in all capsules the specimen temperatures fit the requirement of the ±3% variation in temperature referred to absolute temperature.

On the surfaces of long side stiffening plates of the compartments 4 and 5 there are small areas with the slight overshot of about 7°C over the maximal allowed temperature for compartment structure material. The location of the hot spots corresponds with the position of the division walls between the mini cooling channels. Possible solution for the avoiding of hot spots is the

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

removing of channel division walls in the lower part of the compartment.

The temperature distribution in the HFTM structure calculated for normal operational conditions serves as a basis for a subsequent thermo-mechanical structure analysis of the HFTM [8].

## Acknowledgments

This work has been carried out within the framework of the EUROfusion Consortium and has received funding from the Euratom research and training programme 20142018 under grant agreement No. 633053. The views and opinions expressed herein do not necessarily reflect those of the European Commission.

## References

- [1] Knaster et al., Overview of the IFMIF/EVEDA project, Nuclear Fusion, V. 57, Nr. 10P, 30 June 2017.
- [2] A. Ibarra et al., The IFMIF-DONES project: Preliminary engineering design, 2018 Nucl. Fusion in press, https://doi.org/10.1088/1741-4326/aad91f
- [3] F. Arbeiter, A. Abou-Sena, J. Averhals, et al. Design description and validation results for the IFMIF High Flux Test Module as outcome of the EVEDA phase. Nuclear Materials and Energy, 9, 59-65, (2016).
- [4] Y. Chen, F. Arbeiter, G. Schlindwein, A comparative study of turbulence models for conjugate heat transfer to gas flow in a heated mini-channel, Numerical Heat Transfer, Part A: Applications, 61(1):38-60, 2012
- [5] STAR-CCM+® Documentation, Version 12.06 2017. Siemens Product Lifecycle Management Software Inc.
- [6] F. Arbeiter et al., Mini-channel flow experiments and CFD validation analyses with the IFMIF hermoshydraulic experimental facility (ITHEX), Fusion Engineering and Design,V. 82, Issues 15-24, October 2007, Pages 2456-2461.
- [7] Personal communication, https://idm.euro-fusion.org/? uid=2MN6SR
- [8] Y. Qiu, F. Arbeiter, U. Fischer, F.Schwab, IFMIFDONES HFTM neutronics modeling and nuclear response analyses, Nuclear Materials and Energy, V. 15, May 2018, Pages 185-189
- [9] P.Arena et al., Thermomechanical analysis supporting the preliminary engineering design of DONES target assembly, Fusion Engineering and Design, in Press, https://doi.org/10.1016/j.fusengdes.2018.05.003
- [10] F. Schwab et al., Thermal-mechanical analysis and design optimizations of the IFMIF-DONES HFTM, Proceedings of the 29th Symposium on Fusion Technology 2018, manuscript in progress