<!-- image -->

Contents lists available at ScienceDirect

## Fusion Engineering and Design

[journal homepage: www.elsevier.com/locate/fusengdes](https://www.elsevier.com/locate/fusengdes)

## Estimation of activated lithium and corrosion product contribution to the dose rate in IFMIF-DONES lithium loop cell

<!-- image -->

Andrius Tidikas * , Gediminas Stank¯unas , Benjaminas Togobickij

Lithuanian Energy Institute, Laboratory of Nuclear Installation Safety, Kaunas, Lithuania

## A R T I C L E I N F O

Keywords: IFMIF-DONES Beryllium-7 ACP Activation Photon transport

## 1. Introduction

The International Fusion Materials Irradiation Facility - DEMO Oriented Neutron Source (IFMIF-DONES) is a proposed research facility designed to test materials under extreme conditions similar to those in future nuclear fusion reactors, such as DEMO. It plays a crucial role in assessing the structural integrity and long-term performance of reactor components exposed to high-energy neutron flux [1,2]

During operation, deuterons are accelerated to approximately 40 MeV and directed onto a flowing liquid lithium target, generating a high-intensity neutron spectrum through nuclear reactions. This neutron flux partially corresponds to the environment inside a fusion reactor: it is more intense, and the energy range extends beyond the deuterium-tritium reaction, allowing researchers to study material degradation and radiation-induced effects at an accelerated rate [1,2]

A significant fraction of the deuteron's kinetic energy is deposited in lithium, which requires efficient cooling and continuous circulation in a closed-loop system. However, lithium also becomes a source of radio­ active isotopes, notably beryllium-7, produced through deuteron-

## A B S T R A C T

To ensure the optimal design and maintenance of the IFMIF-DONES irradiation facility, it is imperative to conduct a thorough assessment of the lithium systems, given the presence of ionizing radiation sources. The flow of lithium within the target is impinged by the high-intensity continuous-wave (125 mA, 40 MeV) deuteron beam. The deuteron capture reaction in lithium leads to the production of the Beryllium-7 radioisotope and corresponding neutron emission. Beryllium-7 holds radiological importance due to its relevant half-life and subsequent decay gamma emission. Additionally, neutron emission, together with deuterons, results in the generation of various radioisotopes in the corrosion/erosion products of the structural materials, which are dispersed in the lithium flow.

In this study, we have used Be-7 and activated corrosion product estimates to assess the absorbed dose rates inside the lithium loop cell of IFMIF-DONES. High-efficiency Be-7 trapping in the lithium loop was considered with the assumption of a modest amount of Be-7 being dissolved homogeneously within the volume of lithium. For activated corrosion products, different quantities were used for the system components (heat exchanger, cold leg and cold trap). Gamma spectra and their evolution over one week were obtained using the FISPACT-2 code. Gamma photon transport calculations were performed with MCNP code. As a result, dose rate maps were created for the lithium rooms, photon leakage was assessed and hot zones were identified.

induced reactions with lithium isotopes 7Li(D,2n)7Be and 6Li(D,n) 7Be. Additionally, activated corrosion products (ACP) accumulate due to neutron capture by secondary emissions from structural materials such as SS316L steel piping and enclosures as well as EUROFER from Target Assembly components. These activation products pose radiation exposure risks during facility operation, maintenance, and waste man­ agement [3]

IFMIF-DONES will employ advanced radiation shielding, remote handling systems, and strict waste management protocols to mitigate these risks [1]

This work is mainly focused on estimating the radiological quantities associated with the expected operating conditions of the standalone segment of the lithium loop. Additionally, it addresses key aspects of the source origin and its description within this system. In general, accurate characterization of the IFMIF-DONES lithium system is still a work in progress, as uncertainties remain regarding the formation and disper­ sion of activated corrosion products (ACPs) within the system. To better manage the associated radiological risks, further adjustments to opera­ tional parameters or system design may need to be considered.

* Corresponding author. E-mail address: andrius.tidikas@lei.lt (A. Tidikas).

Received 17 January 2025; Received in revised form 25 June 2025; Accepted 18 July 2025

<!-- image -->

<!-- image -->

It is important to note that this work continues the study of radio­ logical estimates in the lithium loop cell, partially presented in Y. Qiu paper [3]. Previous results were based on a different operating scenario that considered only deposited beryllium and excluded dissolved beryllium, which led to the absence of radionuclides in part of the heat exchanger. Additionally, the ACP estimates have been significantly revised and expanded to include nearly twice as many species. Compared to the previously published study, this paper also provides a more detailed description of both the applied methods and the analysis of radiological estimates in the lithium loop cell.

Another point of emphasis is that, in parallel, efforts are underway to identify the optimal operating conditions, including lithium flow re­ gimes, trapping efficiency, design parameters, temperature settings, activation behavior, and corrosion modelling, to improve predictions of radionuclide distribution within the system.

## 2. Methodology

## 2.1. Model geometry

A simplified model (Fig 1.) of the primary lithium loop circuit was utilized to simulate the activated flow in the lithium loop cell (LLC). This small model is integrated into the IFMIF-DONES main building [4]. It consists of 3 main parts: cold leg (CL), cold trap (CT) and primary heat exchanger (HX). Primarily heat exchanger is used to maintain the desired temperature in the primary lithium loop as specific temperature ranges are required for the lithium flow and the subsequent removal of impurities. Cold leg is an outlet pipe of HX and it is further down con­ nected to the other auxiliary systems such as electromagnetic pumps and branches of the impurity control systems such as cold trap and yttrium trap. Cold trap is a vessel with inner structure made of a series of steel wire meshes that serves to capture Be-7 and other undesired impurities (Oxygen, Nitrogen, Carbon, Hydrogen in form of lithium compounds) from the lithium stream. The cold leg is represented as a pipe structure with a lithium volume; the cold trap is a tank in a separate cell with an inner volume containing trapped Beryllium-7 radionuclides, and the heat exchanger is a cylinder with an internal volume that contains ho­ mogenized material representing inner piping with a certain fraction of HB-40 oil, steel and lithium (HB-40:34.28 %, SS316L: 20 % Lithium: 45.71 %). The initial calculation lithium loop model was prepared by Y. Qiu [5]. Some model modifications were later performed concerning source volume segmentation: source volume inside HX was extended and additional source cells were created.

## 2.2. Source term definition

Each part mentioned in the model is a specific gamma photon source with its shape and radionuclide concentration. Generally, sources are comprised of two groups of radionuclides representing either activated lithium or activated corrosion products.

For dissolved beryllium-7, a very conservative estimate was used: 9.7E-05 appm, based on conditions of 324 ◦C in the hot leg, 300 ◦C in the cold leg, and a 2 % flow rate (reference case U06HM3T4F1). This con­ centration was assumed to be uniform throughout the lithium volume in all system segments. While the actual beryllium concentration in lithium depends on the trapping efficiency, this analysis assumes that all deposited Be-7 is captured and remains localized in the cold trap tank. In reality, much lower concentrations of dissolved beryllium-7 are likely if the flow rate is slower [6]

As for activated corrosion products, T. D´ezsi and A. Zs´akai [7] mass estimates were used for the exact system configuration (hot leg 324 ◦C, cold leg 300 ◦C, cold trap 190 ◦C). these estimates are based on mass transfer simulation of soluble radionuclides inside the primary lithium loop circuit. Two models were used to assess the corrosion: basic and reduced. The basic model assumes equal corrosion rates in all system components equal to 2 µm/year. The reduced corrosion model assumes different corrosion rates for specific components of the system: for target assembly 2 µm/year, for cold leg, hot leg, heat exchanger, and duct 0.4 µm/year and quench tank 0.1333 µm/year.

Fig. 1. Lithium loop cell inside IFMIF-DONES and lithium primary loop model (HX top left, CT bottom middle).

<!-- image -->

Aggregate radionuclide concentrations were assigned to the model segments representing gamma sources. FISPACT inventory code [8] was used to obtain the decay gamma spectra for relevant segments.

Fig. 2. Gamma spectra for Heat Exchanger.

<!-- image -->

(Figs. 2-4). Spectra were obtained for different decay times: 0 s, 1 hour, 1 day and 1 week. Fig. 3 shows the spectral difference between the two corrosion models, while Fig. 4 shows the spectral difference between the heat exchanger and cold leg segments. Gamma spectra is made by 18 groups where each group represents the photons with energies falling into defined interval (starting with 0.00- 0.01 MeV and ending with 4-5 MeV). In case of cold trap, its activity is mostly propagated by Be-7 and is by around 3 orders of magnitudes higher than the one present in HX and CL. Be-7 is characterized by a single energy peak at 477.6 keV.

Additionally, radionuclides were investigated in terms of gamma emissivity. This was done to better understand the specific radionuclide contribution and to normalize the source for the calculation. Activity gamma emissivity adjustment was performed with the data from IAEA nuclear data services [9]. Aggregate emissivity-adjusted activities are presented in Tables 1-2 for beryllium and ACPs.

## 2.3. Equivalent dose rate calculations

This section used the MCNP 6 [10] particle transport code to obtain equivalent dose maps inside the lithium loop and cold trap cells. Pre­ viously obtained radionuclide data were used to describe the source term. Each source volume was assigned a characteristic spectrum and spectral normalization parameters. Each source volume was also assigned a normalization coefficient corresponding to its total gamma emissivity-adjusted activity.

Eight cases were analyzed in total, corresponding to two corrosion models with four decay intervals. Biological dose equivalent rates were obtained using ANSI/ANS 6.1.1-1977 [11] conversion factors.

MCNP calculations were performed using FMESH photon tallies. Nine tally planes, representing the center of the lithium loop cell and the closest walls, were used for the calculations. Each calculation was per­ formed with 2 × 10 9 particle histories.

## 3. Results

It is evident from the maps (Figs. 5-7) that dose rates in the LLC

Fig. 3. Gamma spectra comparison for two corrosion models (Heat Exchanger).

<!-- image -->

Fig. 4. Gamma spectra comparison for Heat exchanger for Cold leg components.

<!-- image -->

Table 1 Gamma emissivity adjusted activities for beryllium in Bq/total mass.

| Beryllium 7  HX  CL  CT  0 s  2.18E+11  2.73E+10  2.13E+14  1 h  2.18E+11  2.73E+10  2.13E+14  1 day  2.15E+11  2.70E+10  2.10E+14  1 week  1.99E+11  2.50E+10  1.95E+14   |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

Table 2 Gamma emissivity adjusted activities for ACP Bq/total mass.

| Basic Corrosion Model  Reduced Corrosion Model  HX  CL  HX  CL  0 s  7.36E+11  1.61E+11  2.65E+11  5.91E+10  1 h  6.97E+11  1.52E+11  2.53E+11  5.65E+10  1 day  6.40E+11  1.40E+11  2.29E+11  5.15E+10  1 week  5.78E+11  1.28E+11  2.04E+11  4.64E+10   |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

Fig. 5. Equivalent dose rate in Sv/h distribution (central place parallel to the floor).

<!-- image -->

generally vary between 1-100 mSv/h with even higher doses near the radiation sources (up to 10 Sv/h). The highest dose rates are in the cold trap cell. Cold leg segment appears to have a higher influence on the doses, even causing noticeable particle streaming through the ceiling of LLC. This might be due to lesser shielding and dilution in volume compared to HX. The reduced corrosion model has some effect on the dose rates, but overall, it does not significantly reduce hazards in LLC. 1

Fig. 6. Equivalent dose rate in Sv/h distribution (central plane parallel to wall and perpendicular to heat exchanger length).

<!-- image -->

<!-- image -->

Fig. 7. Equivalent dose rate in Sv/h distribution (central plane parallel to wall and parallel to heat exchanger length).

<!-- image -->

week of decay also isn't a significant ionizing radiation mitigation factor in investigated scenarios (broadly range within 10 % in areas covered). However, due to the inverse square law, the differences are much more noticeable at the peak dose rates near the radiation sources. For the reduced corrosion model difference can be up to few percent, while one week of cooling can result up to 20 % reduction in dose rate.

As is seen in previously presented Fig. 2 and Tables 1-2, one week does not introduce the drastic changes in the activities of radionuclides and following gamma emission. Beryllium loses less than ~10 % of activity while activated corrosion products ~20 % in a week. So, it can be concluded that the ACP effect on the system in basic and reduced corrosion models diminishes with cooling. It is also important to note that during cooling (according to FISPACT-II calculations), no new important radionuclides were introduced, and total inventory decreased from 19 radionuclides (0 s, 1 hour) to 16 (1 day) and to 14 (1 week). Differences in basic and reduced corrosion models mainly manifest in the 1-2 MeV range. This is expected because the reduced corrosion model considers ~5 times less cobalt isotope presence in lithium. The highest energies in spectra reach up to 5 MeV but decay to an insignif­ icant level within a week. The high-energy gammas are propagated mainly by Mn 52 m.

Some additional calculations were performed with FISPACT code to assess the radionuclide decay evolution for 10 years (Figs. 8-9). While there are some minor differences due to different concentrations the general trends for heat exchanger and cold leg are similar. Be-7 is the most significant contributor in total activity in the heat exchanger.

Fig. 8. Radionuclide evolution in time for the Heat exchanger (basic corro­ sion model).

<!-- image -->

Fig. 9. Radionuclide evolution in time for the Cold Leg (basic corrosion model).

Cobalt and manganese isotopes play crucial roles, with Co-58, Co-56, and Mn-54 maintaining high activity for extended periods. Short-lived radionuclides decay quickly, whereas Fe-55, Co-60, and Cr-51 persist longer. Fig. 10 presents a comparison between two corrosion models in terms of radionuclide composition to the respective activities. Since the main difference between two models are the different corrosion rates for specific segments of the lithium loop system (depends on mass flow and temperature) there are two main factors that decide the different outcome in terms of radionuclide inventory: material composition and solubility. Lower corrosion rates in the reduced model primarily affect the SS316L structures, which have higher weight fractions of cobalt and chromium compared to EUROFER. Cobalt in comparison to other examined metals has a moderate solubility in lithium, while the solu­ bility of chromium is low [12,13]. As a result, cobalt has a more sig­ nificant presence in the basic model compared to the reduced one, whereas the difference in chromium is marginal. Iron is also moderately soluble in lithium; however, due to its abundance in EUROFER, the impact of its activation products is less pronounced between two models.

Fig. 10. Radionuclide contribution comparison between basic and reduced corrosion models in terms of activities.

<!-- image -->

## 4. Summary

The lithium loop cell (LLC) with a lithium cooling system consisting of a heat exchanger, cold leg, and cold trap was analyzed. The source term was described in accordance with the beryllium trapping para­ metric study (reference case U06HM3T4F1). A conservative amount of beryllium dissolved in lithium, at 9.70E-05 appm, was also considered. The activated corrosion product inventory was obtained from a mass transfer study.

The dose maps indicate that dose rates in the LLC generally range between 1 and 100 mSv/h, with even higher doses near the radiation sources, reaching up to 10 Sv/h. The highest dose rates are observed in the cold trap cell. The cold leg segment appears to have a relatively greater influence on the dose distribution, even causing noticeable particle streaming through the ceiling of the LLC (ceiling plane). This effect may be due to reduced shielding and lower dilution in volume compared to the heat exchanger.

The reduced corrosion model has some impact on the dose rates; however, it does not significantly reduce radiation hazards within the LLC. While differences should be more noticeable at peak dose locations near the radiation sources, the overall reduction remains limited.

Fig. 6

## CRediT authorship contribution statement

Andrius Tidikas: Writing - original draft, Methodology, Investiga­ tion, Conceptualization. Gediminas Stank¯unas: Writing - review &amp; editing, Supervision, Methodology. Benjaminas Togobickij: Software, Methodology.

## Declaration of competing interest

The authors declare the following financial interests/personal re­ lationships which may be considered as potential competing interests Andrius Tidikas reports financial support was provided by European Union. If there are other authors, they declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper. This work has been carried out within the framework of the EUROfusion Consortium, funded by the European Union via the Euratom Research and Training Programme (Grant Agreement No 101,052,200 - EUROfusion). Views and opinions expressed are, however, those of the author(s) only and do not necessarily reflect those of the European Union or the European Commission. Neither the European Union nor the European Commission can be held responsible for them.

## Acknowledgments

This work has been carried out within the framework of the EURO­ fusion Consortium, funded by the European Union via the Euratom Research and Training Programme (Grant Agreement No 101052200 - EUROfusion). Views and opinions expressed are, however, those of the author(s) only and do not necessarily reflect those of the European Union or the European Commission. Neither the European Union nor the European Commission can be held responsible for them.

## Data availability

Data will be made available on request.

## References

- [1] A. Ibarra, et al., The IFMIF-DONES project: preliminary engineering design, Nucl. Fusion 58 (2018).
- [2] [A. Ibarra, et al., The European approach to the fusion-like neutron source: the IFMIF-DONES project, Nucl. Fusion 59 (2019).](http://refhub.elsevier.com/S0920-3796%2825%2900554-X/sbref0002)
- [3] [Y. Qiu, et al., Overview of recent advancements in IFMIF-DONES neutronics activities, Fusion Eng. Des. 201 (2024).](http://refhub.elsevier.com/S0920-3796%2825%2900554-X/sbref0003)
- [4] [F. Martín-Fuertes, M.E. García, P. Fern´andez, ´A. Cort´es, G. D'Ovidio, E. Fern´andez, T. Pinna, M.T. Porfiri, U. Fischer, F. Ogando, et al., Integration of safety in IFMIFDONES design, Safety 5 (2019) 74.](http://refhub.elsevier.com/S0920-3796%2825%2900554-X/sbref0004)
- [5] Qiu Y., Parametric study of Be-7 dose in the lithium loop cell and lithium trap cell under different operation condition of the lithium loop, EFDA\_D\_2NKFVS (http s://idm.euro-fusion.org/default.aspx?uid=2NKFVS).
- [6] [M. Ida, et al., Estimation and control of beryllium-7 behavior in liquid lithium loop of IFMIF, Fusion Eng. Des. 82 (2007).](http://refhub.elsevier.com/S0920-3796%2825%2900554-X/sbref0006)
- [7] D´ezsi T.; Zs´akai A. Update of the modelling of the impurities distribution in lithium loop, EFDA\_D\_2NSUM6 (https://idm.euro-fusion.org/default.aspx?uid=2NSUM6).
- [8] Sublet, J.-C.; Eastwood, J.W.; Morgan, J.G. The FISPACT-II User Manual; Technol. Rep. CCFE Abingdon U. K.
- [9] [https://www-nds.iaea.org/relnsd/vcharthtml/VChartHTML.html.](https://www-nds.iaea.org/relnsd/vcharthtml/VChartHTML.html)
- [10] [C.J. Werner, J.S. Bull, C.J. Solomon, F.B. Brown, G.W. McKinney, M.E. Rising, D. A. Dixon, R.L. Martz, H.G. Hughes, L.J. Cox, et al., MCNP6.2 Release Notes; LA-UR18-20808, Los Alamos National Laboratory (LANL): Los Alamos, NM, USA, 2018.](http://refhub.elsevier.com/S0920-3796%2825%2900554-X/sbref0010)
- [11] American Nuclear Society; La Grange Park, Il (USA); Ansi/Ans-6.1.1-1977.
- [12] [H.U. Borgstedt, C. Guminski, Metals in Liquid Alkali Metals, Part II: Co to Bi, 64, Oxford University Press, United Kingdom, 1996.](http://refhub.elsevier.com/S0920-3796%2825%2900554-X/sbref0012)
- [13] [H.U. Borgstedt, C. Guminski, Metals in Liquid Alkali Metals, Part I: Be to Os, 63, Oxford University Press, United Kingdom, 1996.](http://refhub.elsevier.com/S0920-3796%2825%2900554-X/sbref0013)