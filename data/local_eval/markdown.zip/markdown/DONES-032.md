## RESOLUTION STUDIES OF INORGANIC SCINTILLATION SCREENS FOR HIGH ENERGY AND HIGH BRILLIANCE ELECTRON BEAMS

G. Kube, C. Behrens, DESY, Hamburg, Germany

W. Lauth, Institut f¨ur Kernphysik, Mainz, Germany

and holes, (2) thermalization, i.e. the formation of electronhole (e-h) pairs with an energy approximately equal to the band gap, (3) energy transfer to the luminescent centers, and (4) radiative relaxation of the excited centers. In the following it is assumed that the first stage in this sequence dominantes the resolution contribution because it is not localized at a certain point in the crystal lattice.

High-energy electrons and positrons lose energy in matter by ionization and bremsstrahlung, so in a thick absorber an electromagnetic shower is formed with a transverse shower dimension characterized by the Moli`ere radius RM. In a thin scintillator used for profile diagnostics with typical thickness of about 0.5 mm the situation is slightly different: while bremsstrahlung dominates the particle energy loss, the energy deposition causing the e-h formation is mainly due to ionization.

To find a measure similar to RM for the transverse extension of the e-h formation region, the ionization process is considered as an interaction of the particle electromagnetic field with the crystal lattice. This field can be described as expanding transversely as the particle velocity approaches the phase velocity of light in the medium, i.e. the energy loss grows with increasing beam energy. In a medium of finite density the dielectric properties modify the electromagnetic field, by this limiting its expansion [6]. In a classical picture the onset of the so called Fermi-plateau is described as a cancellation of the incoming particle field by the induced polarization field of the electrons in the medium, thus giving a measure for the transverse extension of the e-h formation region. According to Ref. [7] the particle field extension has a limiting value of Rδ = c/ω(1-ε)-1/2 ≈ c/ωp using the simplified model of a free-electron gas with ωp the plasma frequency. Therefore to have a good spatial resolution for beam diagnostics with ultra relativistic particles the scintillator material should have a small extension radius Rδ resp. a large plasma frequency ωp.

The light propagation influences additionally the resolution, even in an ideal case. Scintillation light produced inside the crystal has to reach the detector to contribute to the measurement, i.e. the light has to cross the boundary between scintillator and vacuum. Inorganic scintillators have a rather large index of refraction, so total reflection at the boundary may spoil the resolution. Furthermore the contribution of total reflection depends on the orientation between scintillator surface, beam axis, and detector axis, i.e. the resolution is orientation dependant which has to be taken into account.

Fig. 1 summarizes material properties in view of profile

06 Beam Instrumentation and Feedback

## Abstract

Luminescent screens are widely used for particle beam diagnostics, especially in transverse profile measurements at hadron machines and low energy electron machines where the intensity of optical transition radiation (OTR) is rather low. The experience frommodern linac-based light sources shows that OTR diagnostics might fail even for high energy electron beams because of coherence effects in the OTR emission process. An alternative method to avoid this problem is to use luminescent screens, especially inorganic scintillators. However, there is little information about scintillator properties for applications with high energy electrons. Therefore a test experiment has been performed to study the spatial resolution. The results of this experiment are presented and discussed in view of scintillator material properties and observation geometry.

## INTRODUCTION

Due to coherent effects in the emission of optical transition radiation (OTR) [1] which may compromise the use of OTR monitors as reliable diagnostics, alternative schemes like the use of luminescent screens are under consideration. In this context inorganic scintillators are of interest which are already widely used for calorimetry in highenergy physics and as X- and γ-ray converters in modern medical imaging devices. Their advantage is good radiation resistance, high stopping power for high light yield, and short decay times of the excited atomic levels. While the use of luminescent screens at hadron machines is widespread, there is little information about the use of scintillators for high energy electron beam diagnostics [2, 3, 4]. To discuss scintillator properties in view of transverse beam profile resolution, the following section summarizes some preliminary considerations about possible resolution influencing effects. Afterwards the results of a test experiment are presented which has been performed at the 855 MeV beam of the Mainz Microtron MAMI (University of Mainz, Germany).

## SCINTILLATOR RESOLUTION

Scintillation is based on the presence of luminescent centers in the crystal lattice. For better insight in profile resolution influencing effects, the process of light generation is shortly reviewed in the following. According to Ref. [5], the sequence of processes leading to scintillation in a medium consists of 4 phases: (1) energy conversion, i.e. initial energy release with the formation of "hot" electrons resolution for common inorganic scintillators. For a good spatial resolution the scintillator should have small Rδ and n values.

Figure 1: Extension radius Rδ and refractive index n (at peak wavelength) for common inorganic scintillators.

<!-- image -->

## EXPERIMENTAL SETUP

To study the achievable resolution a test experiment has been performed at the 855 MeV electron beam of the Mainz Microtron MAMI (University of Mainz, Germany). A target holder with 8 screens and a wire scanner (W, thickness 10 μm) was mounted onto a goniometric stage in the test vacuum chamber of the X1 collaboration. The screens were irradiated with a cw electron beam with current between 10 pA and 50 nA. The resulting beam profiles were observed with a standard CCD camera (Basler A311f) collecting the light emitted in backward direction and mounted at an angle of 22.5◦ with respect to the beam axis. The resolution of the optical system was measured to be about 10 μm.

Table 1: Screen materials and their thicknesses.

| material  thickness / mm  YAG:Ce (Y3Al5O12:Ce)  1; 0.2; powder  LYSO:Ce (Lu2-xYxSiO5:Ce)  0.8; 0.5  BGO (Bi4Ge3O12)  0.5  PWO (PbWO4)  0.3  Al2O3  0.5   |
|----------------------------------------------------------------------------------------------------------------------------------------------------------|

Tab.1 summarizes the screen materials investigated together with their thicknesses. YAG scintillators are often used as screen monitors for electron beam diagnostics. They have a small n but a large Rδ. The YAG powder has a thickness of a few μm and was evaporated onto an Allayer. LYSO which is similar to LSO is of interest because it is a material with small Rδ and n. The addition of certain amounts of Y change the crystal properties only slightly but helps to control the crystal growth and phase stability [8]. BGO and PWO were chosen because of their high density and small extension radius. To test an inorganic scintillator with a different crystal structure the Al2O3 ceramic was selected.

## DATA TAKING AND ANALYSIS

Two series of measurements with different beam foci and varying beam currents were performed, the first with a micro focused beam (σx = 23 μm, σz = 27 μm as measured with the wire scanner) and the second with an unfocused beam spot (σx = 330 μm, σz = 160 μm). In these measurements the scintillator surfaces were oriented perpendicular to the beam axis. For each scintillator 5 images were taken with and one without beam. The background image was subtracted from the corresponding mean signal image to determine the background corrected profile. The resulting images were fitted in a pre-defined range with a normal distribution.

Figure 2: Left: Background corrected micro focus beam image at 46 pA beam current for the 0.5 mm thick LYSO scintillator. Right: normalized projected beam profiles and the fit with a normal distribution.

<!-- image -->

Fig.2 shows the result for the 0.5 mm thick LYSO scintillator. The spot size is slightly larger than that measured with the wire scanner. Furthermore the beam profile exhibits a tail in the horizontal direction which could be seen in all measurements except for the thin YAG powder, and which is more pronounced for larger material thicknesses such as the 1 mm thick YAG crystal. This asymmetry is a result of the observation geometry, i.e. the angle of 22.5 ◦ between scintillator surface normal and optical axis in the horizontal plane as described later in simulations.

While the measurement with the Al2O3 scintillator showed a distinct beam spot, the resulting profile did not represent the beam at all. Due to the non-applicability to detect micro focused beam spots with this ceramic, these measurements are not covered in the following.

Fig. 3 summarizes the beam sizes measured with the micro focused beam spot as function of the beam current. To be independent on the observation geometry, only the results for the vertical beam size are included. As can be seen all beam sizes measured with the scintillators are larger than those measured with the wire scanner. They show no dependence on the beam current, except for a slight increase for the PWO scintillator.

A comparison of the measured sizes indicate that LYSO seems to be best suited for beam profile diagnostics. While the measured beam sizes from the BGO scintillator are slightly larger, it is interesting to note that those from the YAG scintillators are significantly larger, even taking into account that the thicknesses of some of the YAG screens are smaller than of the other screens.

Figure 3: Vertical profiles as function of the beam current. The wire scanner measurement was performed only at a beam current of 31 nA.

<!-- image -->

For the unfocused beam spot the measured beam profiles are slightly larger than that from the wire scanner measurement, but again the thick YAG screen showed a much larger beam size.

In a further measurement the influence on the observation geometry was investigated. The orientation between electron beam axis, crystal surface, and optical axis pointing towards the CCD could be varied by rotating the screen holder around the vertical axis. For the micro focused beam and 3.8 nA current, beam profiles measured with the BGO scintillator were studied as function of the screen rotation angle, thus changing the condition for internal total reflection in the crystal. Fig. 4 summarizes the results of this investigation. As can be seen the measured horizontal beam size exhibits a clear minimum while the vertical one remains constant. It is interesting to note that this minimum appears for the orientation when the scintillator surface is tilted away from the CCD surface, see inset of Fig. 4.

To verify this behavior a simulation was performed with the optical ray-tracing program ZEMAX c© [9]. The light source was assumed to be a line source located inside the BGO crystal. For each rotation angle, in total 10 8 rays at the BGO peak emission wavelength of 480 nm were traced from inside the scintillator to the CCD detector to determine the 2-dimensional point spread function (PSF). The resulting PSF was convoluted with the 2-dim. beam profile as measured with the wire scanners, and the beam sizes were calculated from the horizontal resp. vertical projections of the resulting distribution. Fig. 4 shows the simulation results together with the measurements. The general behavior of the beam sizes as function of the rotation angle is well described. The simulated beam sizes are in general smaller than the measured ones which might be caused by the simplified assumption of a line source (i.e. not taking into account the transverse extension of the e-h formation region) and the reduction of the BGO emission spectrum to the peak emission wavelength.

Assuming the influence of the observation geometry is properly described, the task can be reversed to determine the intrinsic scintillator resolution. Subtracting quadratically the optical system resolution from the measured beam sizes in Fig. 4 and comparing these sizes with the results of the simulation one finds a difference of 5-6 μm in both planes. This difference is assumed to be the intrinsic resolution of BGO scintillators for beam profile measurements.

Figure 4: Measured beam sizes as function of the crystal rotation angle together with the results from a ray-tracing simulation taking into account the internal total reflection. The inlet in the right picture indicates the sign convention for the rotation angle.

<!-- image -->

## CONCLUSION

A test experiment has been performed to study different scintillator materials in view of high resolution profile monitoring for high energy and high brilliance electron beams. An attempt was made to describe resolution influencing effects via the transverse extension of the e-h formation region and the index of refraction. Based on these assumptions it was verified that LYSO is a suitable scintillator material for profile diagnostics. Furthermore the influence of the observation geometry on the achievable resolution was investigated, and it could be verified that the general behavior can be explained by the effect of total reflection inside the scintillator crystal.

## REFERENCES

- [1] H. Loos et al., Proc. FEL'08, Gyeongju, Korea, August 2008, THBAU01, p.485 (2008).
- [2] W.S Graves, E.D. Johnson, P.G. O'Shea, Proc. PAC'97, Vancouver, Canada, May 1997, p.1993 (1997).
- [3] A. Murokh et al., Proc. PAC'01, Chicago, Illinois, June 2001, p.1333 (2001).
- [4] A.H. Lumpkin et al., Proc. FEL'09, Liverpool, UK, August 2009, TUPC46, p.348 (2009).
- [5] P. Lecoq et al., Inorganic Scintillators for Detector Systems, (Springer Verlag, Berlin-Heidelberg, 2006).
- [6] E. Fermi, Phys. Rev. 57 (1940) 485.
- [7] W.W.M Allison, J.H. Cobb, Ann Rev. Nucl. Part. Sci. 30 (1980) 253.
- [8] A.G. Petrosyan et al., Opt. Mat. 24 (2003) 259.
- [9] http://www.zemax.com