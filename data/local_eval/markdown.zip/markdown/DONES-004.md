<!-- image -->

WPENS-CPR(17) 17317

S. Gordeev et al.

## CFD Analyses of the Quench Tank Configuration for IFMIF-DONES Liquid-Lithium Target System

Preprint of Paper to be submitted for publication in Proceeding of 13th International Symposium on Fusion Nuclear Technology (ISFNT)

<!-- image -->

This work has been carried out within the framework of the EUROfusion Consortium and has received funding from the Euratom research and training programme 2014-2018 under grant agreement No 633053. The views and opinions expressed herein do not necessarily reflect those of the European Commission.

This document is intended for publication in the open literature. It is made available on the clear understanding that it may not be further circulated and extracts or references may not be published prior to publication of the original when applicable, or without the consent of the Publications Officer, EUROfusion Programme Management Unit, Culham Science Centre, Abingdon, Oxon, OX14 3DB, UK or e-mail Publications.Officer@euro-fusion.org

Enquiries about Copyright and reproduction should be addressed to the Publications Officer, EUROfusion Programme Management Unit, Culham Science Centre, Abingdon, Oxon, OX14 3DB, UK or e-mail Publications.Officer@euro-fusion.org

The contents of this preprint and all other EUROfusion Preprints, Reports and Conference Papers are available to view online free at http://www.euro-fusionscipub.org. This site has full search facilities and e-mail alert options. In the JET specific papers the diagrams contained within the PDFs on this site are hyperlinked

## Analyses of the Quench Tank Configuration for IFMIF-DONES Liquid-Lithium Target System.

Sergej Gordeev a , Frederik Arbeiter a , Francesco Saverio Nitti b , Florian Schwab a

a Institute for Neutron Physics and Reactor Technology, Germany b ENEA Brasimone, Camugnano, BO, Italy

In the IFMIF-DONES (International Fusion Materials Irradiation Facility - DEMO-Oriented Neutron Source) neutron source a single accelerator line delivers 125mA of deuterons at 40MeV to a flowing liquid lithium target with a free (vacuum) surface exposed to the deuteron beam. Neutrons with fusion-relevant spectrum are generated and used for material samples irradiation. The Quench Tank (QT) system has the function to deliver the opensurface high-speed (15 m/s) lithium-flow emerging from the target assembly to the lithium piping system under proper conditions. Several detailed studies on specific QT design features have been performed. The following design aspects have been analysed:

- Influence of the shape and orientation of the QT on the flow behaviour;
- Influence of internal devices in the QT on the control and enhancement of the mixing of the jet within the stagnant lithium;
- Transient mixing of lithium with temperature step-change due to beam on/off events;
- Structure analysis of the QT.

As result the optimized design of the QT with enhanced flow conditions is proposed.

Keywords: IFMIF-DONES, liquid lithium, quench tank.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## 1. Introduction

In the IFMIF-DONES (International Fusion Materials Irradiation Facility - DEMOOriented Neutron Source) [1] neutron source a single accelerator line delivers 125mA of deuterons at 40MeV to a flowing liquid lithium target with a free (vacuum) surface exposed to the deuteron beam. Neutrons with fusion-relevant spectrum are generated and used for material samples irradiation. The Quench Tank System has the main function to deliver the open-surface highspeed Lithium-flow emerging from the target assembly to the lithium system piping system under proper conditions. Due to its large size and peculiar interface properties, its positioning and configuration in the IFMIF-DONES plant has a strong effect on the building design as well as on safety, maintenance and remote handling aspects. ^

Fig. 1 CAD model of QT

<!-- image -->

Figure 1 shows the CAD model of the QT System used as reference design for this work. The aim of this work is optimization of the QT configuration by means of analytical and numerical analyses of hydraulic and thermalstructural conditions in the QT.

## 2. Assessment of the decrease velocity for the free planar jet

The velocity field of a free submerged jet shows two regions: potential core zone and developed zone. In the potential core zone, the centreline velocity remains nearly constant and equal to the exit velocity U0 of the jet. The length of potential core extends between 3dj and 6dj (dj=25 mm is the lithium jet thickness) depending on the initial conditions. The majority of the equations suggested were obtained empirically. In case of the free planar jet, the expression for the evolution of the centreline velocity:

<!-- image -->

(1)

is suggested as particularly suitable. The values of constants C2 and C3 differ notably between different studies. The value of C2 varies between 1.9 and 3, and C3 between -8 and 10 [2]. The diagram in fig. 2 shows the estimated evaluation of the free jet for target outlet flow conditions with U0=15 m/ s For the evolution of the developed zone the minimum and maximum value of the coefficient C2 have been applied. The value of the coefficient C3 was adapted for the smooth

connection between the potential core zone and developed region. Both curves limit the evolution of the centreline velocity field. The dashed line shows the expected distance from the jet exit to the wall of the QT. According to this diagram the jet centreline velocity in the impinging zone can vary between 5 and 8 m/s. That means that the jet kinetic energy will not be completely dissipated by the depth of the QT and the highspeed flow will generate swirling and splashing of lithium free-surface.

Fig.2 Centreline velocity decrease for the free planar jet.

<!-- image -->

## 3. CFD analysis of QT reference design.

## 3.1 Computational domain and boundary conditions

Computational domain of the QT system (see fig. 3) consists of the QT vessel, TA outlet channel and lithiumoutlet pipe. One half of the QT system with symmetrical conditions was modelled. Because of different flow conditions in the nearwall regions the turbulence was modelled by k-e realizable turbulence model with Two-Layer(TL)/High- ReynoldsNumber(HR)approach applied to the viscous sublayer. This model allows the automatic switch of TL/HR treatment depending on the y+ value near the wall. The free-surface flow was modelled by means of Volume of Fluid(VOF) method. The grid density was varied from 2 up to 15 Mio. cells.

Fig. 3 CFD Model of QT reference design.

<!-- image -->

## 3.2 Simulation results

Simulation results presented in fig. 4 clarify the main design issues have to be solved: splashing and sloshing of lithium in the QT, inhomogeneous mixing of lithium and nonuniform outflow. Sloshing of lithium and flow separation in the outlet pipe can induce velocity and pressure fluctuations in the lithium-pipe system.

Fig. 4 Simulated instantaneous free surface (VOF=0.5) and stream lines.

<!-- image -->

<!-- image -->

In order to avoid the direct jet flow in the outlet pipe two displacements of the QT in the beam (X) direction X=100 mm and X=200 mm (main CS, see fig.3) have been analysed. Simulation results have shown that the change of QT-displacement is not effective for the enhancement of flow conditions in the QT. The small volume of the QT and the wall confinement of the free jet cause the unstable behaviour of lithium flow in the QT. The volume of the QT cannot be increased because of the narrow spatial conditions in the TC. The steady behaviour of lithium can be achieved by means of flow conditioners installed in the QT and by modification of the QT shape.

## 3.3 Impact of QT-shape and flow conditioners on the flow stability.

Two QT design optimization options have been analysed. Option 1 is the reference a)

<!-- image -->

b)

Fig. 5 Simulated free surface and stream lines results for two QT design options: a) option 1 - reference geometry with conditioning screens, b) option 2 - the flat shape of the QT.

Simulation results show that the mixing quality of both QT designs is nearly the same (see fig.6a). The lithium temperatures at the outlet develop quite synchronously with the mean lithium temperature in the QT and achieve the steady state temperature

geometry extended by conditioning screens, for the option 2 the flat shape of the QT is proposed. Figure 5a,b presents flow simulation results. The cylindrical wall of the QT significantly affects the flow stability in the impingement region. The applying of the conditioning screen between the jet outlet and impinging wall reduces the impinging energy by scattering of the jet. A more effective slowdown of the flow is achieved in the "flat wall" QT design. The jet impacts the flat wall synchronously with the total cross section. The tangent alignment of the jet and conditioning grid near the outlet provide the homogeneous outflow conditions.

## 3.4 Thermal-hydraulic analysis of the mixing quality

The mixing quality of both QT design options have been tested by transient thermalhydraulic simulations for the case of sudden switch-on of the D+ beam. The initial temperature of lithium in the QT at the start of simulations is 250°C and the lithium inlet temperature is set to 285°C.

of 285°C in 60 s. In contrast to the stable increasing of the temperature in the "flat walls" design, the flow instabilities in the "cylindrical" QT induce the small-amplitude fluctuations of the lithium temperature. It becomes noticeable by comparison of temperature increasing rates in the pipe structure near the QT outlet (fig. 6b). While the maximal value for the "flat walls" design is of 2.5 K/s for the reference design this value achieves 6 K/s. It will increase the thermal loads during sudden beam-on/beam-off situations.

b) Fig. 6. Evolution of lithium (a) and inner wall temperatures (b) at the QT outlet.

<!-- image -->

## 3.5 Structure analysis

The structure analysis of

both of QT design options was performed for the beam-on operation conditions. The initial temperature of the QT structure is set to 350°C. The outer walls of the QT have adiabatic boundary conditions. The mounting plates of supporting legs contacting with the TC liner have the constant temperature of 10°C. For supporting legs the ambient temperature of 50°C with heat transfer coefficient of 10 WK/m2 is assumed. Vacuum conditions have been simulated by pressure load of 0.1 MPa was applied on the outer surface of the QT. In order to reduce bending of supporting legs caused by thermal expansion of the QT a free radial sliding of QT supports is allowed. In case of design option 2 the flat walls are strained by loads induced by vacuum. In order to avoid a high stresses the walls are stabilised by outer stiffening ribs. In figure 7 the overall primary and secondary stresses for both of designs are compared. The minimal allowable stress in the QT structure can be roughly determined in accordance to the rules for elastic analysis of RCC-MRx

2012 [3].

<!-- image -->

Fig. 7. Overall stress distribution calculated for different QT geometries

<!-- image -->

For the case with significant primary stresses can be used the criteria RB 3251.112 for type P damages (RB 3121), level A.

<!-- formula-not-decoded -->

<!-- formula-not-decoded -->

<!-- formula-not-decoded -->

<!-- formula-not-decoded -->

(Pm) and (PL) represent the general primary respectively local primary membrane stress intensity. (Pb) describes the primary bending stress intensity (RB 3224.5). Sm-the allowable stress as a function of temperature is a material property and is derived from yield strength R (p0.2 (min)).

For case where the stresses are mainly caused by the thermal expansion can be used rules RB 3261.1118 for preventing of type S damages, Level A criteria (alternative rule):

<!-- formula-not-decoded -->

For the QT design option 1 the primary stresses induced by gravity and vacuum conditions are negligible so the criterion (4) can be used. The maximal stress is less than the maximal allowable stress value 3 Sm=300 MPa. In case of the option 2 the maximal stress value of does not exceed 1.5Sm=162.6 MPa. Thereby the criterion (3) is fulfilled. In according to criteria (1)-(4) both designs are suitable for the DONES operation conditions. However for the QT design option 1 the structure is less loaded. While it has only local areas with stress values between 60 and 20 MPa in case with "flat walls" the stresses of the same level are distributed over the whole structure.

## Conclusions

Analytical and numerical studies of the lithium flow behaviour in the QT show that the lithium depth in the QT is not large enough to reduce the jet inlet velocity. The wall confinement of the free jet induces very unstable behaviour of lithium in the QT. Simulations show that the QT-displacement relative to the inlet channel is not effective for the enhancement of flow conditions. Because of the narrow spatial conditions in the TC the steady lithium behaviour can be achieved by means of flow conditioners installed in the QT or modification of the QT shape. Comparison of two QT design options: reference design with conditioning screens and QT with a flat shape shows that both of variants have their pros and cons:

- Both of variants have a good mixing quality;
- The" flat wall" design ensures more smooth and stable lithium-jet inflow;
- The maximal stresses in the structures of both variants do not exceed the required limits;
- The structure of the QT option 2 is more mechanically loaded by vacuum conditions. This disadvantage can be compensated by stiffening ribs on the outer surface of the QT;
- The deceleration of the highspeed jet by grids, plates etc. will be combined with forming of recirculation and separation zones in the liquid. Thereby the probability of the cavitation and erosion risk in the QT design

option 1 is higher. Apart from the increased weight due to stiffening ribs, the QT design option 2 with flat walls shows more advantages in the providing of proper conditions for the lithium pipe system

## Acknowledgments

This work has been carried out within the framework of the EUROfusion Consortium and has received funding from the Euratom research and training programme 2014-2018 under grant agreement No 633053. The views and opinions expressed herein do not necessarily reflect those of the European Commission.

## References

[1] A. Ibarra, et al., A Stepped Approach from IFMIF/EVEDA Toward IFMIF, Fusion Science and Technology 66(1), August 2014. [2] S. Maurel, C. Solliec, A turbulent plane jet impinging nearby and far from a flat plate, Experiments and Fluids 31, 687-696, 2001. [3] RCC-MRx 2012 Edition with 1st ADDENDUM - DECEMBER 2013: Design and Construction Rules for Mechanical Components of Nuclear Installations, 2013.