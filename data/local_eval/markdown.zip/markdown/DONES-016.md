<!-- image -->

WPENS-CPR(17) 17684

F. Arbeiter et al.

## Material irradiation capabilities of IFMIF-DONES

Preprint of Paper to be submitted for publication in Proceeding of 18th International Conference on Fusion Reactor Materials (ICFRM-18)

<!-- image -->

This work has been carried out within the framework of the EUROfusion Consortium and has received funding from the Euratom research and training programme 2014-2018 under grant agreement No 633053. The views and opinions expressed herein do not necessarily reflect those of the European Commission.

This document is intended for publication in the open literature. It is made available on the clear understanding that it may not be further circulated and extracts or references may not be published prior to publication of the original when applicable, or without the consent of the Publications Officer, EUROfusion Programme Management Unit, Culham Science Centre, Abingdon, Oxon, OX14 3DB, UK or e-mail Publications.Officer@euro-fusion.org

Enquiries about Copyright and reproduction should be addressed to the Publications Officer, EUROfusion Programme Management Unit, Culham Science Centre, Abingdon, Oxon, OX14 3DB, UK or e-mail Publications.Officer@euro-fusion.org

The contents of this preprint and all other EUROfusion Preprints, Reports and Conference Papers are available to view online free at http://www.euro-fusionscipub.org. This site has full search facilities and e-mail alert options. In the JET specific papers the diagrams contained within the PDFs on this site are hyperlinked

## Material irradiation capabilities of IFMIF-DONES

Frederik Arbeiter 1* , Eberhard Diegele 2 , Ulrich Fischer 1 , Angela Garcia 3 , Angel Ibarra 3 , Joaquin Molla 3 , Fernando Mota 3 , Anton Möslang 1 , Yuefeng Qiu 1 , Marta Serrano 3 , Florian Schwab 1

1 Karlsruhe Institute of Technology (KIT), 76131 Karlsruhe, Germany 2 EUROfusion PMU, 85748 Garching, Germany 3 Laboratorio Nacional de Fusion, CIEMAT, 28040, Madrid, Spain

## 1 Introduction, objectives of IFMIF-DONES

IFMIF-DONES [1] (International Fusion Materials Irradiation Facility - DEMO-oriented Neutron Source) is currently being developed in the frame of the EUROfusion Early Neutron Source work package (WPENS), based on the results achieved in the ongoing IFMIF/EVEDA (Engineering Validation and Engineering Design Activities) project by Japan and Europe in the frame of the Braoder Approach (BA) agreement. The top level requirements of IFMIF-DONES define as the mission of the facility: (i) Generation of materials irradiation test data for design, licensing, construction and safe operation of the fusion demonstration power reactor (DEMO), with its main characteristics as defined in the 2012 EU Roadmap under simulated fusion environment relevant to anticipated needs in radiation resistance for the structural materials in early DEMO, and (ii) generation of data base for benchmarking of radiation responses of materials hand in hand with computational material science. IFMIF-DONES is therefore planned with only one 125 mA 40 MeV deuteron accelerator line (resulting in a neutron flux of 50% compared to IFMIF), and is reduced in technological complexity (only one irradiation experiment) to assure an early enough availability for DEMO design.

The limited product of "irradiation volume × neutron fluence" on one hand and the large potential test matrix (defined by number of material grades, test types, irradiation- and test temperature levels and damage dose levels) on the other hand, require a careful selection of test conditions, as collaborative effort of the communities of DEMO designers, fusion materials science and the irradiation facility designers. This paper presents the capabilities of the facility for the various irradiation tasks from the neutronic as well as from the engineering perspective.

## 2 Irradiation of RAFM steels for the blanket

The irradiation of reduced activation ferritic martensitic (RAFM) steels (typically 8 - 10 % Cr and 1 - 2 % W) for application as structural material of the blanket is regarded as priority irradiation task for IFMIF-DONES. The irradiation of according specimens is planned to be performed in the so called High Flux Test Module (HFTM) directly behind the neutron source. The design principle of the HFTM developed during IFMIF/EVEDA is described in [2]. It is now being adapted to the situation in IFMIF-DONES. The lower nuclear heating and the fact that

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

*Author's e-mail: frederik.arbeiter@kit.edu

no further test modules will be installed (in standard situation) behind the HFTM allowed to increase the size of the irradiation capsules and the total depth of the module: In total 8 columns × 4 rows of irradiation slots are offered, of which the central 4 × 3 achieve high quality irradiations, while the other positions primarily serve as neutron reflectors (to smoothen gradients) and instrumentation carriers, but can also be used for lower dose rate irradiations. In the central 4  3 slots, individually temperature controlled irradiation capsules are placed, into which packets of small specimen test technique (SSTT) specimens are placed. Each capsule offers a cuboid volume 81.2 mm  40.2 mm x 16.5 mm (54 cm³) for specimens. The specimen types and their arrangement can be selected according to user demand. Types and sizes of the specimens proposed by Möslang et al. [3] are shown in Table 1. (For the default loading pattern, about 0.36 cm³ (indicative value) are occupied per specimen; each capsule is then filled with about 150 specimens). A HFTM irradiation capsules provides quasi-isothermal irradiation conditions (+/- 3 % of the Kelvin temperature, good temporal stability) for its specimen payload. The irradiation temperature for each capsule can be selected between 250 and 550 °C. In the central regions with considerable volumetric heating, the specimens are embedded in liquid sodium to homogenize the temperature field. In less heated regions, thermal conduction between the specimens can be achieved by metal filler pieces.

The nuclear responses in the specimen set are described in detail in [4]. The neutron flux density incident to the HFTM is 5 × 10 14 n/cm 2 /s. The capsule-averaged structural damage rate reaches 15.4 dpa/fpy for a capsule in the beam center in the first row, and 5.6 dpa/fpy for a capsule on the beam edge in the third row. 12 - 25 dpa/fpy (the region with accelerated testing vs. DEMO) are reached in 306 cm³ of usable specimen volume. The helium production rate is about 13 appm He / dpa and the hydrogen production rate about 53 appm H / dpa . These ratios are quite homogenous throughout the beam footprint area, and match very well the values experienced in the DEMO first wall.

Gradients in the damage production rate in the specimens are inherent for irradiations with a single-sided neutron source. As guiding number for usable testing, 10% allowable difference of damage dose over the specimen's gage volume is assumed. The allowable absolute gradient of damage per length unit thus depends on the specific specimen's gage volume sizes (0.76 - 9 mm with the presented specimen set) and its orientation in the radiation field. In the default arrangement of specimens, it has been taken care to align the long axes of the gage volumes as well as possible to the neutron flux iso surfaces. As guiding number, about 20-25% dpa difference per cm can lead to acceptable conditions. Such conditions are met in 78% of the volume within the beam footprint. In the central part, the gradients are about 10% per cm.

The total lifetime of the HFTM (and thus the achievable doses in the specimens) is limited (a) by the allowed structural damage of the HFTM pressure bearing outer wall, (b) by creep damage of the high temperature hermetically sealed capsules, and (c) lifetime of electical heaters and instrumentation. The damage limit for the applied X2 CrNiMo 17-12-2 (N) steel is specified by the RCC-MRx code to 53 dpa. It may be possible to extend this limit based on return of experience from the operation of the IFMIF-DONES facility. The creep damage can be circumvented by using non-pressurized capsules (i.e., which don't contain Sodium). The lifetime of electrical heaters is the most difficult to assess, due to the lack of operational data. Tests of the heaters are prepared in the MARIA reactor. A lifetime of 1-2 years is the target for the HFTM.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

*Author's e-mail: frederik.arbeiter@kit.edu

Table 1: Specimen types, bounding box measures and geometry

<!-- image -->

## 3 Irradiation of W and Cu alloys

Tungsten alloys are foreseen as armor materials for the divertor target plates and also for the first wall, copper alloys are considered as heat sink of the divertor. The service temperature range of tungsten in those applications spans from about the upper usage temperatures of the heat

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

*Author's e-mail: frederik.arbeiter@kit.edu

sink materials (550 °C for Eurofer and about 350 °C for copper) to nearly the melting temperature of tungsten during short time transients. For temperatures up to 550 °C, the irradiation of both materials can be performed in the standard HFTM capsules. This technology is limited by the upper use temperature of about 600 °C of the mineral insulated heaters of the capsules. Higher temperatures can be achieved by using the volumetric heating (up to 16.76 W/cm³ in W) of the specimens. In this case, cylindrical capsules with an additional insulation gap between the specimens and the heater can be used to create a temperature increase of over 200 °C between the heaters and the specimen, so that an irradiation at about 800 °C will be possible. Such a capsule type was already developed for the Tritium Release Test Module in the IFMIF/EVEDA phase. The structural material of the specimen bin must then be a high temperature alloy.

Nuclear responses have been investigated for several loading patterns of materials in the HFTM 1 and are described in detail in [5]. For an irradiation scenario dedicated to tungsten, a structural damage rate of 1-3 dpa/fpy (capsule average) can be achieved in 8 cylindrical high temperature capsule each with 20 cm³ of specimen volume. This allows accelerated testing vs. the application in the DEMO divertor. The helium production rate is 9-10 appm He / dpa, which is about double of the value in DEMO. The hydrogen production rate is 20 - 29 appm H / fpy, about factor 3 to of what is expected in the DEMO divertor. Other transmutation effects (like Osmium and Rhenium) where not yet investigated.

Copper alloys could be irradiated in standard (cuboid) capsules of the HFTM. The compatibility with Sodium as embedding heat transfer medium has not yet been studied, but due to the high thermal conductivity of copper, thermal gradients will be less an issue than for steels.

According to [5], structural damage rates of 5-30 dpa/fpy can be reached in the HFTM for CuCrZr samples, allowing accelerated testing. The helium production rate of 6-8 appm He is comparable with the DEMO case, and the hydrogen production rate with 48-50 appm(H)/dpa about 36% higher.

## 4 In situ testing of creep fatigue and tritium release

In-situ testing experiments are not foreseen for the first phase of operation of IFMIF-DONES, and are currently not actively being developed. It is anticipated however, that the need of such tests may come into focus of research needs during the IFMIF-DONES operation time. During the IFMIF/EVEDA phase, the following irradiation modules were developed to an intermediate engineering design:

-  A Tritium Release Test Module [6], which enables the irradiation of Beryllium and Lithium-ceramics (20 cm³ per capsule) at temperatures up to 900 °C. The time dependent tritium release to a purge gas stream can be measured.
-  A Liquid Breeder Validation Module [7], which enables the irradiation of liquid PbLi and measurement of tritium release.

1 For that study, two HFTM with the thickness of 56 mm each were stacked together in the neutron field, while the up-to-date thickness of the HFTM container is 102.2 mm.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

*Author's e-mail: frederik.arbeiter@kit.edu

-  A Creep Fatigue Test Module [8], which enables the in-situ cyclic loading with load and strain measurements of three individually controlled creep fatigue specimens.

Those modules and the IFMIF-DONES facility are in principle compatible (concerning for example coolant supply and nuclear heating intensity). The operation of the tritium producing experiments may however necessitate the upgrade of a tritium measurement and removal station, for which the space is reserved.

## Conclusions

IFMIF-DONES is designed to offer an early available neutron irradiation facility in accordance with the european DEMO schedule and requirements. The focus is on irradiation of structural steels.

For steels, the irradiation conditions of IFMIF-DONES achieve accelerated testing in a significant specimen volume. Per campaign over 1 fpy, approximately 800 specimens can be irradiated to 12 - 25 dpa. The gas production rates match closely those of the DEMO blanket. Thermal and nuclear responses gradients are limited to the stated requirements.

The irradiation conditions of copper and tungsten alloys have been explored. In both cases, accelerated testing can be achieved. For tungsten, significantly too high gas production rates are predicted. For CuCrZr, the gas production rates may be found acceptable.

The development of in-situ irradiation experiments (like creep fatigue testing or tritium release) is considered as a future option for the IFMIF-DONES facility.

## Acknowledgements

This work has been carried out within the framework of the EUROfusion Consortium and has received funding from the Euratom research and training programme 2014-2018 under grant agreement No. 633053. The views and opinions expressed herein do not necessarily reflect those of the European Commission.

## References

[1] A. Ibarra et al., A stepped approach IFMIF/EVEDA towards IFMIF, Fusion Science and Technology, 66 (2014) 252-259

[2] F. Arbeiter, A. Abou-Sena, J. Averhals, et al. Design description and validation results for the IFMIF High Flux Test Module as outcome of the EVEDA phase. Nuclear Materials and Energy, 9, 59-65, (2016).

[3] Anton Möslang, personal communication.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

*Author's e-mail: frederik.arbeiter@kit.edu

[4] Yuefeng Qiu, Frederik Arbeiter, Ulrich Fischer, Florian Schwab, IFMIF-DONES HFTM neutronics modelling and nuclear response analyses, submitted for publication in Nuclear Materials an Energy (proceedings of ICFRM-18)

[5] F. Mota et al., Potential irradiation of Cu alloys and tungsten samples in DONES, submitted for publication in Nuclear Fusion

[6] Ali Abou-Sena, Frederik Arbeiter, Development of the IFMIF Tritium Release Test Module in the EVEDA phase, In Fusion Engineering and Design, Volume 88, Issues 6-8, 2013, Pages 818-823

[7] Natalia Casal et al., Present status of the Liquid Breeder Validation Module for IFMIF, In Fusion Engineering and Design, Volume 88, Issues 6-8, 2013, Pages 863-867

[8] F. Arbeiter et al., The accomplishments of lithium target and test facility validation activities in the IFMIF/EVEDA phase, Nucl. Fusion 58 (2018) 015001 (6pp)

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

*Author's e-mail: frederik.arbeiter@kit.edu