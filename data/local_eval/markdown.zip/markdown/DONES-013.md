<!-- image -->

WPENS-CPR(18) 21056

D. Bernardi et al.

## Towards the EU fusion-oriented neutron source: the Preliminary Engineering Design of IFMIF-DONES

Preprint of Paper to be submitted for publication in Proceeding of 30th Symposium on Fusion Technology (SOFT)

<!-- image -->

This work has been carried out within the framework of the EUROfusion Consortium and has received funding from the Euratom research and training programme 2014-2018 under grant agreement No 633053. The views and opinions expressed herein do not necessarily reflect those of the European Commission.

This document is intended for publication in the open literature. It is made available on the clear understanding that it may not be further circulated and extracts or references may not be published prior to publication of the original when applicable, or without the consent of the Publications Officer, EUROfusion Programme Management Unit, Culham Science Centre, Abingdon, Oxon, OX14 3DB, UK or e-mail Publications.Officer@euro-fusion.org

Enquiries about Copyright and reproduction should be addressed to the Publications Officer, EUROfusion Programme Management Unit, Culham Science Centre, Abingdon, Oxon, OX14 3DB, UK or e-mail Publications.Officer@euro-fusion.org

The contents of this preprint and all other EUROfusion Preprints, Reports and Conference Papers are available to view online free at http://www.euro-fusionscipub.org. This site has full search facilities and e-mail alert options. In the JET specific papers the diagrams contained within the PDFs on this site are hyperlinked Fusion Engineering and Design xxx (xxxx) xxx-xxx

<!-- image -->

Contents lists available at ScienceDirect

## Fusion Engineering and Design

[journal homepage: www.elsevier.com/locate/fusengdes](https://www.elsevier.com/locate/fusengdes)

## Towards the EU fusion-oriented neutron source: The preliminary engineering design of IFMIF-DONES

D. Bernardi a,⁎ , F. Arbeiter b , M. Cappelli c , U. Fischer b , A. García d , R. Heidinger e , W. Krolas f , F. Martín-Fuertes d , G. Miccichè a , A. Muñoz g , F.S. Nitti a , M. Pérez d , T. Pinna c , K. Tian b , A. Ibarra d , the full IFMIF-DONES team

- a ENEA, Brasimone, Italy
- b KIT, Karlsruhe, Germany
- c ENEA, Frascati, Italy
- d CIEMAT, Madrid, Spain
- e F4E, Garching, Germany
- f IFJ PAN, Krakow, Poland
- g Empresarios Agrupados, Madrid, Spain

## A R T I C L E I N F O

Keywords: IFMIF-DONES Test cell Shielding Confinement Neutronics

Remote handling

## 1. Introduction

The availability of a fusion-relevant neutron source is felt since a long time by fusion community as a crucial pending step to qualify the materials that will be used in DEMO and future fusion power plants. Safe design, construction and licensing of a fusion facility by the corresponding Nuclear Regulatory Agency will demand the understanding of the materials degradation under the neutrons bombardment during the lifetime of the fusion reactor. The radiation-exposed components must withstand the severe operational conditions without significant impact on their dimensional stability and on their mechanical and physical properties, together with low presence of long-lived activation prone constituent isotopes and moderate decay heat [1]. In particular, DEMO in-vessel materials will be exposed to neutron fluxes in the order

⁎ Corresponding author. E-mail address: davide.bernardi@enea.it (D. Bernardi).

[https://doi.org/10.1016/j.fusengdes.2018.12.042](https://doi.org/10.1016/j.fusengdes.2018.12.042)

Received 8 October 2018; Received in revised form 14 December 2018; Accepted 14 December 2018 0920-3796/ © 2019 EUROfusion Consortium. Published by Elsevier B.V. All rights reserved.

## A B S T R A C T

The need of a high-intensity, 14MeV neutron source for the qualification of materials under fusion-relevant conditions has been recognized in the European fusion programme as an essential step towards the design and licensing of DEMO and future commercial fusion power plants. This need has pushed the EU to support the development of a Li(d,nx) neutron source called IFMIF-DONES (International Fusion Materials Irradiation Facility-DEMO Oriented NEutron Source) based on and taking advantage of the results obtained in the IFMIF/ EVEDA (IFMIF Engineering Validation and Engineering Design Activities) project conducted in the framework of the bilateral EU-Japan Broader Approach Agreement. The design activities and the supporting R&amp;D work of the IFMIF-DONES facility are presently being carried out in the framework of the Work Package Early Neutron Source (WPENS) of the EUROfusion Consortium in direct collaboration with F4E Agency, with the main goal of consolidating the underlying technology and developing a sound design basis in order to be ready for IFMIFDONES construction at the early beginning of the next decade.

In this paper, some important aspects of the IFMIF-DONES Preliminary Engineering Design concerning in particular the main design integration issues in the target area are presented and briefly discussed.

of ˜(1-5)×10 18 m -2 s -1 with a peak energy of 14.1MeV which will produce a displacement damage in excess of 10 dpa (as calculated by the NRT model [2]) per year of operation [3,4] with an He production rate of 10-13 appm/dpa.

The current European Fusion Roadmap [5] foresees an initial DEMO phase with a maximum dose around 20 dpa, for components integration testing, and a second phase with a maximum dose around 50 dpa [6]. In line with this approach, a specific activity was started in Europe in 2015, in the framework of the EUROfusion Consortium Workprogram, with the objective to develop the design of a DEMO-oriented irradiation facility able to irradiate materials samples up to the above mentioned levels of displacement damage [7]. The facility, named IFMIF-DONES (International Fusion Materials Irradiation Facility-DEMO Oriented Neutron Source) is currently being designed within the EUROfusion

<!-- image -->

## D. Bernardi et al.

Fusion Engineering and Design xxx (xxxx) xxx-xxx

Work Package Early Neutron Source (WPENS) in collaboration with F4E Agency, taking advantage and on the basis of the previous results achieved during the IFMIF/EVEDA (IFMIF Engineering Validation and Engineering Design Activities) project [8] conducted in the framework of the EU-Japan Broader Approach Agreement [9]. In 2017, an important milestone of WPENS consisting in the IFMIF-DONES Preliminary Engineering Design (PED) developed for a generic site has been achieved [10,11] as a first step required to move forward with the engineering design for a specific site and the subsequent construction activities planned to be started in the early 2020s.

In this paper, some important aspects of the IFMIF-DONES PED concerning in particular the main design integration issues in the target area are presented and briefly discussed.

## 2. Plant design description

## 2.1. Mission and top level requirements

The final goal of IFMIF-DONES design is to provide a neutron source producing high energy neutrons at sufficient intensity and irradiation volume to: 1) generate materials irradiation test data for the design, licensing, construction and safe operation of DEMO, with its main characteristics as defined by the EU Roadmap [5]. The IFMIF-DONES neutron source shall simulate fusion environment relevant to anticipated needs in radiation resistance for the structural materials in DEMO; 2) generate a data base for benchmarking of radiation responses of materials hand in hand with computational material science.

From this mission, a set of top level requirements [11] descends for the IFMIF-DONES Plant. Among them, the following specifications are given in particular for the high flux irradiation region:

Neutron spectrum shall simulate the first wall neutron spectrum of early DEMO as closely as possible so as to provide the same nuclear responses which affect the material behavior under irradiation in terms of primary knock-on atom spectrum (PKA), main transmutation reactions, and gas production (He, H).

Neutron fluences accumulated in the materials samples shall correspond to a damage level of 20-30 dpa (NRT) in&lt;2.5 years applicable to 0.3 l volume and to 50 dpa (NRT) in&lt;3 years applicable to 0.1 l volume.

Temperature range of the test modules shall be controlled and varied at least between 250 °C and 550 °C (based on the expected temperature design window for EUROFER steel, to be used as main structural material for DEMO design).

Displacement damage (dpa) and temperature gradients over a gauge volume corresponding to standardized miniaturized specimens shall be limited as follows: dpa gradient&lt;10%; temperature gradient within±3% with the long-time stability of the same order.

Although not assumed as a requirement, the possibility of a future upgrade of IFMIF-DONES to full IFMIF (2 x 125mA, 40MeV D+beams, 10MW) is considered in the design. A comparison of the main characteristics of DEMO, IFMIF (as conceived in IFMIF/EVEDA) and IFMIF-DONES is reported in Table 1.

Table 1

Comparison of DEMO (First Wall, FW), IFMIF and IFMIF-DONES main characteristics.

| DEMO  (on FW)  IFMIF  IFMIF-DONES  D+beam current [mA]  -  2×125 125  D+energy [MeV]  -  40  40  Neutron flux  [m -2 s -1 ]  (1-5)×10 18  ˜10 19  5 × 10 18  Damage rate (DR) [dpa/fpy]  &lt; 12  20  10  Irradiation volume related to DR [l]  -  0.5  0.3  He/dpa [appm/dpa]  &lt; 12  ˜13  ˜13   |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

## 2.2. Plant configuration

IFMIF-DONES Plant is conceived as an accelerator-based neutron source in which a high energy deuterons (D+) beam is focused on a fast flowing liquid lithium jet to produce neutrons via D-Li stripping reactions.

A sketch of the current IFMIF-DONES Plant configuration is shown in Fig. 1. Five major groups of systems can be identified, namely: Accelerator Systems; Lithium Systems; Test Systems; Plant Systems and Central Instrumentation and Control Systems.

The Accelerator Systems (AS) include all the systems aimed to generate, accelerate and shape the deuteron beam. The IFMIF-DONES accelerator is based on the same concept of the IFMIF one [8], whose prototype (LIPAc) is currently under advanced commissioning stage at Rokkasho site in Japan [12]. IFMIF-DONES accelerator consists in a sequence of acceleration and beam transport stages that will produce a 5MW deuteron beam (125mA, 40MeV) and shape it to have a rectangular cross section ranging from 100mm×50mm to 200mm× 50mm. The D+beam will impinge on the free surface liquid lithium target 25mm thick, 260mm wide cross-flowing at 15m/s in front of it. The large number of neutrons generated by the stripping reactions interact with the materials samples enclosed in the High Flux Test Module (HFTM) located directly behind the lithium target.

The Lithium Systems (LS) comprise several systems according to their functions. Among these, the Target System [13] has the function to accelerate and shape the lithium jet and to position it with respect to the beam and the HFTM. Its main component is the Target Assembly (TA) which includes the concave shaped open channel (backplate) where the lithium jet is exposed to the D+beam in a windowless vacuum chamber connected to the accelerator High Energy Beam Transport (HEBT) line through a Beam Duct. Downstream the TA, the Quench Tank (QT) collects and slows down the lithium exiting from the backplate. The Heat Removal System [14] comprises: the main Li loop recirculating the lithium between the TA and the primary heat exchanger; the secondary and tertiary oil loops transferring the heat deposited in the lithium jet by the D+beam to the Plant general cooling water system. The Impurity Control System [15] consists of a branch line, which extracts a fraction of the lithium from the main loop and reinjects it after purification and impurity analysis. The system is designed to condition the lithium after maintenance prior to start-up and to control and maintain a defined level of purity during operation. The purification branch contains the cold trap, to remove elements with temperature sensitive solubility in lithium (mainly C, O and metallic impurities mostly related to corrosion and activation products) and the hydrogen trap to remove hydrogen isotopes by chemical reaction with H-binding material (presently Yttrium). It is also planned to maintain N content at low enough concentration (in the range of 30 ppm) by installing a N-binding material (presently Ti) inside the Li loop Dump Tank to be used during the maintenance operations.

The Test Systems (TS) include all those systems devoted to enclose and position the test samples behind the lithium target and to control and keep the proper irradiation conditions inside them. The TS include in particular the HFTM, the Start-up Monitoring Module (STUMM) and the closed cavity or Test Cell (TC) housing the lithium target and the test modules. The HFTM is basically composed of capsules which hermetically enclose the material specimens stacks to be irradiated. The capsules are installed in so-called compartment slots. To achieve the temperature control of the specimen stack, each capsule is equipped with at least three heaters each monitored by two thermocouples located inside the capsule. In addition, each slot is surrounded by minicooling-channels for low pressure (3.5 bar at the inlet) He coolant flow. Furthermore, capsules are filled with Na in order to promote the heat transfer and each capsule is also surrounded by an insulation gap whose dimensions depend on the temperature of the corresponding compartment. To characterize the neutron/gamma flux and spectrum and to validate neutronic calculation models a dedicated Start-up Monitoring Fusion Engineering and Design xxx (xxxx) xxx-xxx Module is foreseen to be used during the commissioning phase in place of the HFTM.

Fig. 1. IFMIF-DONES Plant configuration.

<!-- image -->

The IFMIF-DONES Plant Systems include general services which support the function of the whole Plant. These services comprise: Heating, Ventilation and Air Conditioning System or HVAC (both industrial and nuclear); Heat Rejection System; Electrical Power System; Service Water and Service Gas System; Radioactive Waste Treatment System (including both solid and liquid waste) as well as Gas Radioactive Waste Treatment System; Fire Protection System.

complementary experiments [16] through a Collimated Neutron Beam Facility which takes advantage of the neutron flux available behind the HFTM.

Finally, the Instrumentation and Control Systems are designed with a hierarchical structure, starting from the top level, the Central Instrumentation and Control Systems (CICS), down to the Local Instrumentation and Control Systems (LICS) level. The CICS consist of three systems: Control Data Access and Communication (CODAC) System; Machine Protection System (MPS); and Safety Control System (SCS). Each system at the central level is in a continuous and bidirectional communication with the corresponding one at the local level by means of dedicated instrumentation and control networks and/or buses: CODAC Network, Interlock Bus Network, and Safety Network. At the local level, the Instrumentation and Control is mainly given by a local controller with a set of sensors and actuators.

## 2.3. Buildings and site layout

The systems pertaining to AS, LS and TS, together with their related ancillaries are arranged inside the Main Building (MB). This is a story building with footprint dimensions of around 160m×75m and including one additional basement level occupying only a reduced area of the total footprint. The basement and the floor above it, which houses the accelerator vault and the TC, are buried underground (at elevations EL.-18.000m and -9.000m, respectively) while the remaining suspended floors are placed at ground level and at elevation EL.+6.000m. One additional roof slab is placed at EL.+12.000m. A large room named Access Cell (AC) with dimensions of about 9m×60m is located immediately above the TC and allows the access to the TC components for their maintenance through the Remote Handling Equipment (RHE) installed in it (see Sect. 3.4). The AC is also provided with an extension covering and giving access from the top to the Target Interface room (TIR) and to the Radiation Isolation Room (RIR) housing the final section of the HEBT line. A dedicated experimental area has also been arranged behind the TC to perform The MB is erected at the centre of the site layout having a usable surface area of about 10 ha (Fig. 2) and it is directly connected with the adjacent Access Control Building. Different auxiliary buildings and areas are distributed all along the perimeter of the site and are connected to the MB through service galleries. These areas include in particular: the Main Electrical Building, the Transformers area, the Electrical Switchyard area, the Emergency Power Building, the Fire Water area, the Industrial Water area, the Warehouse, the Cooling Towers area, the Administration Building.

## 3. Design integration in the target area

## 3.1. Test cell and target system configuration

At the heart of the whole DONES Plant, the TC is an hermetically closed volume where the interaction between the D+beam and the Li jet takes place and the materials samples are irradiated by the resulting neutron flux. In the current design, the TC is conceived as a blind hot cell (Fig. 3) with an opening at the top, enclosed by biological concrete shielding with a stainless steel liner completely covering its internal surface.

The TC biological shielding includes the surrounding lateral shielding walls, the upper shielding plug (USP), the lower shielding plug (LSP), the piping and cabling plugs (PCPs), and the TC floor separating the TC and the LS room placed beneath. Below the TC floor, a TC-LS Interface Cell (TLIC) is arranged to accomplish safety functions

Fig. 2. Plant layout with Main Building and service areas (only some of them are indicated).

<!-- image -->

Fig. 3. IFMIF-DONES Test Cell with TA and HFTM inside (penetration in the TC wall of the Beam Duct not housing the beam is not shown).

<!-- image -->

(see Sect. 3.2) and to accommodate the sections of the Li pipes extending outside the TC and connecting to the Li loop. The TC physically houses the HFTM (or the STUMM during commissioning phase) and part of the Target System components including the backplate section and the TA support, the Beam Duct, and the inlet and outlet Li pipes.

During the irradiation experiments, the liquid lithium enters the TC through the inlet pipe, which penetrates the wall of the TLIC and the TC floor, flows through the TA to receive the deuteron beam and then is slowed down in the QT. Thereafter, the lithium flows through the outlet pipe, which penetrates as well the TC floor and the TLIC wall, and returns back to the lithium loop. Differently from the previous IFMIF design, the QT is now arranged inside the TC directly below the TA. This is a design choice mainly aimed at reducing flow instabilities in the outlet channel [17]. The deuteron Beam Duct from the accelerator also penetrates the wall between TIR and TC. The end section of the Beam Duct meets the TA inside the TC. It must be noted, however, that in order to allow the potential future upgrade to full IFMIF, two Beam Ducts are implemented in the design (as shown in all the figures herein included), although only one is actually used for the single D+beam of IFMIF-DONES. The Beam Duct not housing the beam is kept available for other purposes (e.g., diagnostics).

Periodic replacement of TA and HFTM is foreseen due to structural materials degradation caused by the exposure to the severe irradiation environment of the TC. To perform these operations, RH devices must be used as components become highly activated under neutron irradiation.

Taking into account all the above mentioned features, several integration aspects need to be addressed in the target area including TC penetrations design and confinement; radiation shielding and dose rates in the surrounding rooms; RH integrated system and related maintenance operations. All these aspects are briefly discussed in the following sections.

Fusion Engineering and Design xxx (xxxx) xxx-xxx

Fig. 4. TC vertical cut view showing the steel liner (in red) (For interpretation of the references to colour in this figure legend, the reader is referred to the web version of this article).

<!-- image -->

## 3.2. TC penetrations and confinement

As mentioned in Sect. 3.1, the internal surface of the TC walls are completely covered by a few mm thick stainless steel liner which extends also through the walls openings (see Fig. 4). This liner has the function to provide the leak tightness of the TC in order to maintain the proper working atmosphere (He at pressure below 10 kPa in operation; Ar at atmospheric pressure during maintenance) and to protect the concrete shielding wall from contact with lithium in case of lithium spill inside the TC, which can initiate violent chemical reactions.

Furthermore, following the IFMIF-DONES defense-in-depth principle [11] for application of different levels of safety, the liner is credited as one of the multiple safety containment barriers against release of radioactive materials.

As such, it must comply with nuclear safety rules which in particular do not allow the use of expansion bellows as part of the containment [18]. In addition, design of bellows in lithium penetration pipes in the TC floor is neither recommended in order to avoid degradation of their elastic elements from Li exposure. To cope with this issue, a solution was proposed within the IFMIF-DONES PED, which separates the two functions of thermal compensation and radioactive confinement. This is done by using integrated Interface Shielding Plugs (ISPs), which absorb the pipes thermal expansions, in conjunction with the TLIC sealed volume that creates the confinement. Besides thermal expansion compensation, the ISPs must provide several other functions such as sealing between TC and Lithium Loop Cell (LLC); shielding of the LLC from TC radiation and thermal insulation between lithium pipes and TC concrete floor.

To illustrate the abovementioned approach, a sketch of the design solution proposed for the Inlet ISP (IISP) is shown in Fig. 5. In this concept, the 6″ inlet pipe is surrounded by a shielding ring, a thermal insulation layer and electrical heaters (not shown in Fig. 5) to form the IISP assembly. An insulation thickness of 30-40 mm is enough to reduce

## D. Bernardi et al.

Fusion Engineering and Design xxx (xxxx) xxx-xxx

Fig. 5. Sketch of the Inlet Interface Shielding Plug (IISP).

<!-- image -->

the temperature of the IISP outer structure to the same level of the liner temperature (T˜50 °C). The IISP assembly is inserted into the floor opening and fixed to the liner on the TC side through a supporting flange. This flange is designed as a flexible element to allow the vertical expansion of the pipe in both directions.

A small gap (˜2.5mm) exists between the IISP outer surface and the liner to allow the relative axial movement of the pipe. The axial displacement of the pipe in downwards direction towards the LLC is estimated to be around 12 mm and thus a DN250 axial bellow (allowing a maximum expansion of 72mm) on the outer side of the TC wall is enough to compensate this expansion. The atmosphere of the TC is separated from that of the LLC by a sealed flange placed below the TC floor, which rigidly connects the lithium pipe to one end of bellow by means of a flange adaptor. The other end of the bellow is connected by another flange to the liner extending from the penetration hole. Since, according to the argument discussed above, this bellow cannot be credited as a containment barrier, a dedicated stainless steel enclosure (TLIC) welded to the extension of the TC liner is introduced below the TC floor to create a leak tight volume surrounding the bellow which actually extends the volume of the TC in the LLC. The TLIC also provides the anchor points for the lithium pipes in the LS area and creates the space to arrange the flexible portion of Li pipes aimed at absorbing the thermal deformations in the horizontal plane (see Fig. 4).

On one wall of the TLIC, an opening with a leak tight air lock hatch/ door is reserved for RH operations on the inner LS components. Together with the wall of the TLIC, the door is considered as part of the containment. Removable shielding blocks without active cooling are arranged surrounding/inside the TLIC to protect the LS area during beam-on operation.

The same design concept adopted for the IISP is proposed for the Outlet ISP (OISP). The optimization of the ISPs design has been supported by 3D thermal-hydraulic and structural analyses using commercial software codes [19].

## 3.3. Radiation maps and shielding approach

## 3.3.1. Radiation map in and around the TC

The TC volume contains the major source of radiation of the IFMIFDONES Plant with an estimated dose rate well above 100 mSv/h both in beam-on operation and beam-off maintenance mode. As such, this area is radiologically classified as "prohibited" and it must be shielded to reduce the dose rate (DR) level in the adjacent rooms to values compatible with their radiation classification [10] which includes "controlled area/frequent access" (3μSv/h &lt; DR &lt; 10 μSv/h, green zone) and "controlled area/limited permanence" areas (10μSv/h &lt; DR &lt; 1mSv/h, yellow zone).

Following the ALARA principle [11], an extensive neutronic analysis for prompt (beam-on) conditions has been carried out at plant level to estimate the optimal configuration of the TC biological shielding walls both in terms of materials (ordinary or heavy magnetite concrete with densities of 2300 kg m -3 and 3400 kg m -3 , respectively) and thicknesses [20].

The calculations have shown that the original set of shielding walls dimensions (4 m in beam downstream direction, 4 and 4.65 m at lateral side and 3.5 m in beam upstream direction) with heavy concrete is able to fulfill the radiological requirements in the adjacent rooms with quite a large margin. This has suggested a possible reduction of the walls thickness in particular at the lateral sides and in the TC/TIR (beam upstream) wall. Updated calculations have thus been performed using reduced shielding walls (4m downstream, 3/3.65m laterally and 3m upstream) [21]. The results of this analysis has confirmed the effectiveness of such shielding configuration (Fig. 6) which has been therefore assumed as the new reference [22].

The surrounding shielding walls as well as the liner of the TC are actively cooled by water to remove the nuclear heating generated by neutrons and gammas during beam-on operation. Neutronics calculations estimate a peak value of volumetric nuclear heating of about 83mW/cm 3 in the concrete in beam downstream direction. Within the IFMIF-DONES PED, the principal technical specifications of the TC water cooling system have been identified, topology of piping has been defined and thermal-hydraulic simulations have been started showing that, for a reference temperature of 30 °C of the cooling water flowing at a velocity of 2m/s, the peak temperature in the wall (84 °C) is below the maximal allowable value of heavy concrete (90 °C) [22].

## 3.3.2. Radiation in the TIR

In all the investigated cases with different shielding walls dimensions, the prompt dose rate in the upstream zone of the TC is very high (well above the 100 mSv/h limit in the TIR) because of the effect of

Fig. 6. Prompt neutron+gamma dose rate map [μSv/h] around the TC with reduced shielding walls dimensions.

<!-- image -->

## D. Bernardi et al.

Fusion Engineering and Design xxx (xxxx) xxx-xxx

radiation streaming through the beam ducts. Thus, increasing the thickness of the wall between TC and TIR has no effect on reducing the dose rate in the TIR. Accordingly, the reduced thickness of 3m (see Sect. 3.3.1) has been confirmed for this wall. In addition, local shielding of the beam duct crossing TIR is being explored.

## 3.3.3. Radiation in the AC

The AC is classified as "limited permanence" area (10 μSv/ h &lt; DR &lt; 1mSv/h, yellow zone) during beam on and "forbidden area" (DR &gt; 100 mSv/h, red zone) during maintenance. Recent neutronic estimations [23], however, show dose rates levels less than ˜10 μSv/h, low enough to allow man access during operation. This is due to the design of the Pipe and Cabling Plug (PCP) with dog-leg type steps reducing the radiation streaming through the pipes in a very efficient way.

During maintenance, the main radiation source in the AC comes from the highly irradiated components extracted from the TC (namely, TA and HFTM) whose specific activity after one irradiation cycle is of the order of 10 14 Bq/kg [24,25]. Analyses are ongoing to estimate the biological dose rate map generated in the AC by this source and to assess the suitability of the current AC walls thickness to fulfill the dose requirements in the adjacent rooms.

## 3.3.4. Radiation in the LLC

The thickness of the TC floor is designed with 2 m of heavy concrete to shield the LLC below it. The penetrations for the Li pipes passing through the TLIC are nevertheless to be considered (see Fig. 4). A detailed neutronics analysis of the TC and surrounding areas including also the LLC has been recently performed using an integrated model which takes into account the new dimensions of the TC shielding walls (see Sect. 3.3.1), the current position of the QT inside the TC and the updated building layout [26]. Conservative assumptions with no shielding blocks in the TLIC have been adopted.

The results show that the neutron flux inside the LLC remains in the range of 10 2 -10 4 cm -2 s -1 corresponding to a neutron dose rate of 10-5000 μSv/h. Moreover, the foreseen walls thickness of 1m of ordinary concrete for the LLC is enough to allow the neutron dose rate outside the walls to not exceed 0.5 μSv/h. Neutronic calculations also show that the gamma dose rate is ˜10% of neutron dose rate inside the LLC concrete walls although the gamma streaming through the Li outlet pipe is quite strong due to the weak shielding effect of lithium for gammas. However, the effect of gamma streaming does not influence the above conclusions on LLC walls thickness.

The total (neutron+gamma) prompt dose rate map is shown in Fig. 7 which makes evident that the radiation level does not allow any human presence in the LLC during operation. However, the access to LLC is in any case forbidden as Ar atmosphere is foreseen in this room during beam-on period to avoid risk of Li fire.

The shutdown dose rate in LLC due to components activation induced after one irradiation campaign (corresponding to 345 days of full power operation) and one day cooling has also been assessed (Fig. 8) to estimate the accessibility in this area during maintenance when polyethylene shielding is installed in the TLIC and with the additional hypotheses of Li not drained and TA and HFTM still in position in the TC.

Fig. 7. Prompt neutron+gamma dose rate map [μSv/h] in the LLC below the TC.

<!-- image -->

Fig. 8. Shutdown gamma dose rate map [μSv/h] in the LLC below the TC.

<!-- image -->

Results clearly show that the radiation level is low enough to permit free access in the Li area. Nevertheless, it must be noted that the main radioactive source in the LLC is originated by lithium activation products (mainly 7 Be) and activated corrosion products (ACPs) which can deposit and remain stuck on the inner surface of LS components after Li draining. An expected contribution to the contact dose rate of ˜3 Sv/h from 7 Be and ˜3mSv/h from ACPs was evaluated under very conservative assumptions [27] on the basis of previous IFMIF works [28], thus showing the need of local shielding installations. More accurate evaluations on this topic for IFMIF-DONES conditions are still underway.

## 3.4. RH system and maintenance operations in the TC

IFMIF-DONES requires the use of advanced RH technologies to prevent human exposure to the high radiological activated environment and to accomplish the stringent requirement set for the global Plant availability. To this regard, one of the most challenging aspects of IFMIF-DONES design integration is the development of the RH Systems (RHS) used to perform maintenance activities on the LS and TS components inside the TC [29]. Most of these activities are performed in the AC which is sized to accommodate all the RH Equipment (RHE) and tools used to execute the required maintenance tasks as well as to temporary store the removable TC components such as the TCCP, the USP and the LSP when the TC is open.

In the framework of IFMIF-DONES PED, a strong effort has been made to achieve a high degree of integration of the RH devices and procedures so as to use as much as possible the same tools to perform different operations in the TC area with minimum intervention times. The main operations to be accomplished in the TC during yearly scheduled maintenance period are:

- Opening and closing of the TC
- Plugging/unplugging of electrical and cooling pipes connections
- Exchange of HFTM and TA and their transportation, through dedicated hatch on the AC floor, to the Irradiated Waste Treatment Cell (IWTS) for dismantling and waste conditioning.

To perform these operations, a number of common RH devices is foreseen in the AC (see Fig. 9) including:

- Two Heavy Rope Overhead Cranes (HROCs) covering the TC area

## D. Bernardi et al.

Fusion Engineering and Design xxx (xxxx) xxx-xxx

Fig. 9. RH equipment in the AC.

<!-- image -->

(HROC\_1) and the TIR and RIR area (HROC\_2). Both of them are nuclear grade multi-ropes double beam overhead travelling cranes dedicated to perform transfer operations of components with weights up to 140 tons for HROC\_1 and 100 tons for HROC\_2. The HROC\_1 is designed to lift and transfer large and heavy components of the TC such as TCCP, USP and LSP requiring moderate positioning accuracy. This crane has six degrees of freedom including rotation around the vertical axis and small transverse translations.

- The Access Cell Mast Crane (ACMC) which is a nuclear grade double beam overhead crane with a telescopic mast equipped with a Change Gripping System (CGS) to allow connection with various devices and end-effectors including: a Parallel Kinematic Manipulator (PKM, see Fig. 10, left side) to manage the transportation and positioning of the TA through dedicated TA Lift Frame (Fig. 11); a Robotic Arm (RA, see Fig. 10, right side) to manage the various RH tools for different operations inside the TC like connection, disconnection, inspections and cleaning; and the multipurpose interface module for transportation and installation of the HFTM in the TC (Fig. 12).

## 4. Conclusions

The successful accomplishment of the IFMIF-DONES Preliminary Engineering Design for a generic site has been recently achieved within the EUROfusion WPENS workpackage as a first step to move towards the completion of the design of a European DEMO-oriented neutron source whose construction is planned to be started in early 2020s. Some important integration aspects have been described in this paper concerning safety, neutronics and RH issues in the target area of the facility. The design solutions proposed in the framework of the IFMIFDONES Preliminary Engineering Design activities in order to tackle the above issues have been illustrated and briefly discussed, showing the progresses achieved so far in the design integration of the Plant.

Fig. 10. PKM (left) and RA (right) to be attached to ACMC.

<!-- image -->

Fig. 11. TA positioning in the TC.

<!-- image -->

Fig. 12. Multipurpose module for HFTM transportation and installation in the TC.

<!-- image -->

## Acknowledgments

This work has been carried out within the framework of the EUROfusion Consortium and has received funding from the Euratom research and training programme 2014-2018 under grant agreement No 633053. The views and opinions expressed herein do not necessarily reflect those of the European Commission, Fusion for Energy, or of the authors' home institutions or research funders.

## D. Bernardi et al.

Fusion Engineering and Design xxx (xxxx) xxx-xxx

## References

- [1] D. Stork, et al., Towards a programme of testing and qualification for structural and plasma-facing materials in fusion neutron environments, Nucl. Fusion 57 (2017) 092013, , https://doi.org/10.1088/1741-4326/aa60af.
- [2] M.J. Norgett, M.T. Robinson, I.M. Torrens, A proposed method of calculating displacement dose rates, Nucl. Eng. Des. 33 (1975) 50-54, https://doi.org/10.1016/ 0029-5493(75)90035-7.
- [3] U. Fischer, et al., Neutronic performance issues of the breeding blanket options for the European DEMO fusion power plant, Fusion Eng. Des. 109-111 (2016) 1458-1463, https://doi.org/10.1016/j.fusengdes.2015.11.051.
- [4] D. Stork, et al., Materials R&amp;D for a timely DEMO: key findings and recommendations of the EU roadmap materials assessment group, Fusion Eng. Des. 89 (2014) 1586-1594, https://doi.org/10.1016/j.fusengdes.2013.11.007.
- [5] T. Donné, et al., European Research Roadmap to the Realisation of Fusion Energy, ISBN 978-3-00-061152-0 EUROfusion Consortium, 2018, http://www.euro-fusion. org/eurofusion/roadmap.
- [6] G. Federici, et al., European DEMO design strategy and consequences for materials, Nucl. Fusion 57 (2017) 092002, , https://doi.org/10.1088/1741-4326/57/9/ 092002.
- [7] A. Ibarra, et al., A stepped approach from IFMIF/EVEDA toward IFMIF, Fusion Sci. Technol. 66 (2014) 252-259, https://doi.org/10.13182/FST13-778.
- [8] The IFMIF/EVEDA Integrated Project Team, IFMIF Intermediate Engineering Design Report, Available on request at (2013) ifmif@ifmif.org.
- [9] J. Knaster, et al., Overview of the IFMIF/EVEDA project, Nucl. Fusion 57 (2017) 102016, , https://doi.org/10.1088/1741-4326/aa6a6a.
- [10] [A. Ibarra, et al., DONES Plant Description Document, Included in IFMIF-DONES Preliminary Engineering Design Documentation, (2017) Available on request to corresponding author.](http://refhub.elsevier.com/S0920-3796%2818%2930807-X/sbref0050)
- [11] A. Ibarra, et al., The IFMIF-DONES project: preliminary engineering design, Nucl. Fusion 58 (2018) 105002, , https://doi.org/10.1088/1741-4326/aad91f.
- [12] K. Kondo, et al., Linear IFMIF prototype accelerator (LIPAc): installation activities for Phase-B beam commissioning in Rokkasho, Nucl. Mat. Energy 15 (2018) 195-202, https://doi.org/10.1016/j.nme.2018.04.011.
- [13] [D. Bernardi, et al., IFMIF-DONES Target System Design Description Document (2017), Included in IFMIF-DONES Preliminary Engineering Design Documentation, (2017) Available on request to corresponding author.](http://refhub.elsevier.com/S0920-3796%2818%2930807-X/sbref0065)
- [14] [F.S. Nitti, et al., IFMIF-DONES Design Description Document (DDD) of Heat Removal Systems (2017), Included in IFMIF-DONES Preliminary Engineering Design Documentation, (2017) Available on request to corresponding author.](http://refhub.elsevier.com/S0920-3796%2818%2930807-X/sbref0070)
- [15] [F.S. Nitti, A. Aiello, T. Dezsi, P. Favuzza, N. Holstein, IFMIF-DONES Design Description Document (DDD) of Impurity Control Systems, Included in IFMIFDONES Preliminary Engineering Design Documentation, (2017) Available on request to corresponding author.](http://refhub.elsevier.com/S0920-3796%2818%2930807-X/sbref0075)
- [16] A. Maj, M.N. Harakeh, M. Lewitowicz, A. Ibarra, W. Królas, White Book on the Complementary Scientific Programme at IFMIF-DONES, IFJ PAN Report No. 2094/ PL. https://www.ifj.edu.pl/badania/publikacje/raporty/2016/2094.pdf.
- [17] K. Tian, F. Arbeiter, S. Gordeev, F. Groeschel, Y. Qiu, The test cell configuration under IFMIF-DONES condition, Fusion Eng. Des. 124 (2017) 1112-1117, https:// doi.org/10.1016/j.fusengdes.2017.03.003.
- [18] [RCC-MRx Design and Construction Rules for Mechanical Components of Nuclear Installations, edition, AFCEN organization (France), 2012 (RB 3711).](http://refhub.elsevier.com/S0920-3796%2818%2930807-X/sbref0090)
- [19] [S. Gordeev, W. Hering, Preliminary Design of Shielding Plugs for Inlet and Outlet Li Pipes, (2017) Available on request to corresponding author.](http://refhub.elsevier.com/S0920-3796%2818%2930807-X/sbref0095)
- [20] [G. Tracz, B. Bieńkowska, K. Drozdowicz, Report on the Updating of Dose Map Results in/around the Target/Test Cell Facility, (2017) Available on request to corresponding author.](http://refhub.elsevier.com/S0920-3796%2818%2930807-X/sbref0100)
- [21] [G. Tracz, K. Drozdowicz, Updated Radiation Dose Maps in/around the Target/Test Cell Facility during DONES Full Power Operation, (2018) Available on request to corresponding author.](http://refhub.elsevier.com/S0920-3796%2818%2930807-X/sbref0105)
- [22] K. Tian, et al., Overview of the current status of IFMIF-DONES test cell biological shielding design, Fusion Eng. Des. 136 (2018) 628-632, https://doi.org/10.1016/j. fusengdes.2018.03.043.
- [23] [F. Mota, G. Barrera, M.B. Ahedo, J. Molla, Update of Available Dose Map Results in/ around the Pipes &amp; Cable Plugs Region, (2018) Available on request to corresponding author.](http://refhub.elsevier.com/S0920-3796%2818%2930807-X/sbref0115)
- [24] [M. Frisoni, Neutronics Analysis of Target Assembly, (2016) Available on request to corresponding author.](http://refhub.elsevier.com/S0920-3796%2818%2930807-X/sbref0120)
- [25] K. Kondo, et al., Shutdown dose calculation for the IFMIF test facility and the high flux test module, Prog. Nucl. Sci. Technol. 4 (2014) 233-237, https://doi.org/10. 15669/pnst.4.233.
- [26] [Y. Qiu, et al., Report on the Nuclear Analyses Requested for Systems Design Updates and Specific Evaluations, (2018) Available on request to corresponding author.](http://refhub.elsevier.com/S0920-3796%2818%2930807-X/sbref0130)
- [27] [M. Frisoni, ENEA Contribution to Radiation Shielding Studies, (2016) Available on](http://refhub.elsevier.com/S0920-3796%2818%2930807-X/sbref0135)
28. [request to corresponding author.](http://refhub.elsevier.com/S0920-3796%2818%2930807-X/sbref0135)
- [28] M. Ida, H. Nakamura, M. Sugimoto, Analytical estimation of accessibility to the activated lithium loop in IFMIF, Journal Nucl. Mat. 367-370 (2007) 1557-1561, https://doi.org/10.1016/j.jnucmat.2007.04.022.
- [29] [G. Miccichè, et al., IFMIF-DONES Design Description Document (DDD) of Remote Handling System, (2017) Available on request to corresponding author.](http://refhub.elsevier.com/S0920-3796%2818%2930807-X/sbref0145)