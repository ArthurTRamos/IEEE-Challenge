## ACTIVATION OF HIGH FLUX TEST MODULE SAMPLE HOLDER AFTER IFMIF-DONES OPERATION

## S. Breidokaitė, G. Stankūnas, and A. Tidikas

Laboratory of Nuclear Installation Safety, Lithuanian Energy Institute, Breslaujos 3, 44403 Kaunas, Lithuania Email: simona.breidokaite@lei.lt

Received 14 October 2019; revised 25 October 2019; accepted 31 October 2019

Nuclear safety assessment in nuclear fusion devices relies on the Monte Carlo method based neutron transport calculations. This paper presents information about the calculation results of the activities and dose rates caused by neuron irradiation for the structural materials of the high flux test module sample holder of IFMIF-DONES. The neutron induced activities and dose rates at shutdown were calculated by means of the FISPACT-2010 code with data from the EAF-2010 nuclear data library. Neutron fluxes and spectra were obtained with MCNP neutron transport calculations. The activities and dose rates were calculated at the end of irradiation of the assumed device operation scenario for cooling times of 0 s - 1000 year. In addition, radionuclides with contribution of at least 0.5% to the total value of activation characteristics at the previously mentioned cooling times were identified. After the operation, the most active radionuclide is 55 Fe, with an activity share ranging from 30% (M200) to 63% (M8), and at the end of the prediction it accounts for 86% of the total activity. The highest dose rates at the end of irradiation are attributed to 56 Mn radionuclide. 54 Mn and 60 Co are the most dominant radionuclides during intermediate and long cool-down periods.

Keywords: IFMIF-DONES, fusion, neutron irradiation, MCNP, FISPACT

## 1. Introduction

Nuclear energy is a relatively clean energy source in terms of carbon footprint in comparison to widely used fossil fuels. There are two main nuclear processes that can result in net energy gain: fusion and fission. Although nuclear fission based technologies currently play an important role in the energy market, they have issues with radiation protection, nuclear waste storage and limited fuel resources. Nuclear fusion offers the alternative that mitigates the formerly mentioned issues to more manageable levels [1]. On the other hand, nuclear fusion technologies face their own challenges, for example: fusion devices are very complicated and achieving sustainable fusion on earth is not an easy task [2]. In order to ensure safety of fusion devices, most times Monte Carlo method based neutron transport calculations are performed. THe Monte Carlo method is based on simulation of individual particle histories in complex environment. Particle histories follow the established laws of physics; however, the outcome is decided by random events that are described by probability distributions [3].

There are many possible fusion reactions that result in energy release. At the moment, the most promising and feasible for the controlled thermonuclear process are reactions between hydrogen isotopes (deuterium and tritium) and helium [4]. Most of the energy released during D-T fusion reactions is carried by neutrons. Self-sustaining nuclear fusion can only be achieved if certain particle densities, temperatures and confinement times are present. The cross-section of the D-T reaction is the highest at the selected plasma temperature (around 100 million degrees) [5].

Based on the preliminary engineering project of IFMIF (International Fusion Materials Irradiation Facility), the European Union has proposed a plan for the development of the DONES (DEMO-Oriented Neutron Source) nuclear fusion facility [6]. IFMIF-DONES neutrons will be generated during the Li (d, xn) reaction by liquid lithium target bombardment with deuterium ions (up to 40 MeV). The device will be capable to produce energetic neutrons and will employ acceleration current (125 mA) in order to procure high neutron flux [&gt;10 18 m -2 s -1 ] in order to achieve exposure conditions relevant to nuclear fusion for material testing and qualification. Neutron exposure in material samples will result in structural damage and activation. Activation will not be limited to samples as a large part of the facility will be exposed to neutron irradiation as well. The highest neutron intensity will be at the Test Cell (TC) (Fig. 1) [7] and its High Flux Test Module (HFTM) [8] where material samples are held (for more details see Figs. 2, 3) [9]. Estimation of activation in TC and HFTM is critical for the operation and maintenance of the device as it could lead to radiological hazards for staff and sensitive electronics.

## 2. Computational methods

The MCNP (Monte Carlo n-particle) particle transfer code was developed by the Los Alamos National Laboratory in the United States. It was programmatically written using the FORTRAN and C programming languages.

For neutron spectrum calculations the neutron transport equation must be solved:

Fig. 1. Model of the Test Cell including the High Flux Test Module [7].

<!-- image -->

Fig. 2. IFMIF-DONES High Flux Test Module. From left to right: a downstream view, an upstream view, a downstream view but cut in the middle of the container with the global coordinate system of IFMIF-DONES [8].

<!-- image -->

Fig. 3. MCNP model of the IFMIF-DONES HFTM sample holder.

<!-- image -->

<!-- formula-not-decoded -->

( , , , ). S r E t + Ω

The MCNP uses three processes to solve neutron transport equations:

- (1) using the probability distribution determines the source parameters;
- (2) neutron location, energy and direction tracking;
- (3) data recording and analysis of results [10].

The FISPACT-2010 is describing the amounts of various nuclides in materials after given irradiation steps. It can be achieved by solving the Bateman differential equations

<!-- formula-not-decoded -->

<!-- formula-not-decoded -->

<!-- formula-not-decoded -->

where N i is the amount of nuclide i at time t, λ i is the decay constant of nuclide i, λ ij is the decay constant of nuclide j producing i, σ i is the total cross section for reaction i, σ ij is the reaction cross-section for reaction j producing on i, σ k f is the fission crosssection for reactions on actinide k, ϕ is the neutron flux, S i is the source of nuclide i from fission, and Y ik is the yield of nuclide i from the fission of nuclide k. The set of the previously mentioned differential equations is solved using the Sidell method. Due to the dependence on the duration of irradiation and cooling sequences only nuclides with sufficiently long half-lives are calculated by this method, and nuclides with shorter half-lives are considered to be in equilibrium [11].

## 3. Calculation results

Neutron spectra (Fig. 4) were determined by using the IFMIF-DONES neutron source and geometry model. Neutron fluxes and energy distribution were obtained for the structure of the HFTM sample holder. All neutron transport calculations were done by using MCNP5 with the JEFF-3.1.2 [12] nuclear library.

Activation analysis and radionuclide identification were performed with the FISPACT-2010 code with the EAF-2010 nuclear data library [13].

JEFF-3.1.2 is the general purpose fusion and fission nuclear data library, while EAF-2010 is the nuclear data library optimized for fusion applications. A concise structure of EAF-2010 enables a shorter computation duration.

For activation calculations the IFMIF-DONES irradiation scenario was employed that assumes facility operation for 10 years. Each year consists of 345 days of continuous irradiation and 20 days of downtime representing the maintenance work. Specific activities and dose rates were obtained and dominant radionuclides were identified for HFTM. Only radionuclides contributing more than 0.5% to the total value after any of the considered time interval are presented.

Activities and dose rates were calculated for the HFTM sample holder structure, which consists of 14 materials used for structural integrity and thermal insulation: SS316L (N), EUROFER 97 and several compounds such as M40 (EUROFER 97 | AISI 321 | MgO | NiCr 80/20 | INNOBRAZE ML 442), M200 (Silica Aerogel, Si (OCH 3 ) 4 ) and M8 (Fe, Cr, W, Mn, and some other elements). 11 of the investigated materials were iron based (see Table 1).

The specific activity dependence on time is shown in Fig. 5. At the end of irradiation, 55 Fe is the most active radionuclide and represents 30%

Fig. 4. Neutron spectrum.

<!-- image -->

Table 1. Chemical composition of the investigated materials.

| M1 % M2 % M3 % M5 % M8 % M30 %  Fe 62.974 Fe  65.4  Fe  47.442  Fe  61.645 Fe  87.974 Fe 84.777  Cr  18 Cr 16.998 O 33.035 Cr  18.5 Cr  9.5  Cr  9.155  Ni  12.5 Ni  11.998 Ca  7.103 O  13 W 1.199 Na  3.634  Mo 2.699 Mo 2.499 Ti  5.434 Mn 2.499 Mn  0.6 W 1.155  Mn  2 Mn  2  Si  2.575 Mn  2  V 0.25 Mn 0.578  Cu  1  Si  0.75 Al  2.348 Cu  1  Ta  0.15 V 0.241  Si  0.5 Nb  0.1 Mg  0.934  Si  1  C  0.12  Ta  0.144  Other 0.322 Other 0.255 Other 1.129 Other 0.357 Other 0.19 Other 0.295  M31 % M32 % M33 % M40 % M200 %  Fe 84.857 Fe  84.94  Fe  85.02  Fe  74.9  Fe 26.6663  Cr 9.163 Cr  9.172 Cr  9.181 Cr  10.65 O 24.1705  Na 3.544 Na  3.449 Na  3.358 Ni  7.723 C 17.2439  W 1.156 W 1.158 W 1.159 Mg  2.298  Si  10.2879  Mn 0.579 Mn 0.579 Mn  0.58 O 1.52 Cr  7.4234  V 0.241 V 0.241 V 0.242 W 0.916 Ni  5.9955  Ta 0.145 Ta  0.145 Ta  0.145 Mn 0.686 H 4.3041  Other 0.295 Other 0.296 Other 0.296 Other 1.283 Other 3.8842   |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

Fig. 5. Specific activity at HFTM for M40.

<!-- image -->

(M200) to 63% (M8) of the total activity. In addition to this, the contribution of 54 Mn and 56 Mn is 7% (M200) to 13% (M8) of total activities. Although the half-life of the 55 Fe iron isotope is relatively long (half-life is 2.734 yr), it remains the most relevant isotope for almost all prediction time period. A more detailed analysis of the obtained results shows that 55 Fe is produced from the 54 Fe neutron capture reaction with gamma radiation as a by-product. The neutron capture reaction is responsible for 56 Mn production from 55 Mn.

The main radionuclides that are gamma radiation sources are presented in Fig. 6. As we can see, the largest contribution to the equivalent dose rate is provided by 56 Mn, but due to its short half-life (2.64 h), 58 Co (half-life is 70.86 d.) and 54 Mn (halflife is 312.2 d.) are relevant for longer times. From 10 to 100 years due to the long half-life (5.273 m), 60 Co emits almost 100% of the total dose.

Fig. 6. Dose rate at HFTM for M40.

<!-- image -->

Fig. 7. Specific dose rate at HFTM for EUROFER 97.

<!-- image -->

In Fig. 7, we can see that the main dominant radionuclides are the same as in the material in Fig. 6; however, in Fig. 7 there are some differences in radionuclides responsible for the total dose rate. The main contributors are 56 Mn and 54 Mn, while 60 Co is insignificant and amounts to less than 0.5% of the total dose rate.

As seen in Fig. 8, in the first second after the end of irradiation, the increase in the iron content increases the activity of the 55 Fe isotope fraction in the material. The highest activity (272.8 TBq/kg) is reached in the AISI SS316L material with 65% iron content. 51 Cr has the greatest influence on SS316L. For the activity of M40 (concentration of Fe in material is ~75%), in addition to 51 Cr, 56 Mn and 54 Mn are also significant sources.

Figure 9 depicts the iron percentage and related specific activity values present for 181 days of the observation time. During this time period, the influence of iron activation products (mainly 55 Fe) increases with regard to the total specific activities. It should also be noted that the activity of iron isotopes ( 55 Fe and 53 Fe) ranges from 65% (M200) to 86% (M8). The most active substance is M8, containing 87.97% of iron, and has a total activity of 159.1 TBq/kg after 181 d.

Fig. 8. Specific activity dependence on the iron content in the material (1 second of cooling).

<!-- image -->

Fig. 9. Specific activity dependence on the iron content in the material (181 days of cooling).

<!-- image -->

## 4. Summary

The objective of this study was to calculate the activities and dose rates in the HFTM sample holder structure at the IFMIF-DONES induced by neutron irradiation. Subsequent activities and dose rates at shutdown were calculated by means of the FISPACT-2010 code using the irradiation scenario specified for the IFMIF-DONES. After the end of irradiation, the activities and dose rates were calculated at the cooling time of 0 and 1 s, 5 and 30 min, 1, 3, 5 and 10 h, 1 and 3 days, 2, 4 and 8 weeks, 181 days, 1, 10, 100, 300 and 1000 years.

The investigation of the iron based materials shows that the total dose rate values range from 2.5 ∙ 10 4 to 4 ∙ 10 4 Sv/h within the first second after the end of irradiation and drops to 1.05 · 10 -3 - 5.92 · 10 -2 Sv/h, respectively, after 1000 years of cooling.

The specific activity of 55 Fe in the metal samples ranges from 4.92 · 10 13 to 1.57 · 10 14 Bq/kg at the first second of the cooling time and from 1.54 · 10 8 to 4.95 · 10 8 Bq/kg after 50 years of the cooling time. The highest activity value belongs to M8. After 50 years, no activity of 55 Fe was observed.

The total specific activity in the metal samples ranges from 1.63 · 10 14 to 2.74 · 10 14 Bq/kg at the first second of the cooling time and from 1.72 · 10 8 to 5.21 · 10 10 Bq/kg after 50 years of the cooling time. The highest activity values belong to M8.

At 0 second of the cooling time, the most active radionuclide is 55 Fe: its activity ranges from 30% (M200) and 63% (M8) of the total activity up to 86% at the end of the observation. 56 Mn is the radionuclide emitting the highest doses, but it decays fast and due to the longer half-life the dominant nuclides at the end of the cooling time are 54 Mn and 60 Co.

## Acknowledgements

This work has been carried out within the framework of the EUROfusion Consortium and has received funding from the Euratom Research and Training Programme 2014-2018 and 2019-2020 under Grant Agreement No. 633053. The views and opinions expressed herein do not necessarily reflect those of the European Commission.

## References

- [1] K. Tokimatsu, H. Hondo, Y. Ogawa, K. Okano, K. Yamaji, and M. Katsurai, Energy analysis and carbon dioxide emission of Tokamak fusion power reactors, Fusion Eng. Des. 48(3-4), 483-498 (2000), https://doi.org/10.1016/S09203796(00)00157-5
- [2] L.J. Qiu, Fusion Energy and Its Application (Science Press, Beijing, 2008).
- [3] L.W. Dunn and J.K. Shultis, Exploring Monte Carlo Methods (Elsevier Science, 2011).
- [4] W. Yican, Fusion Neutronics (Springer Singapore, 2017).
- [5] Y.C. Wu, E. Stevens, K. Kim, D. Maisonnier, A. Ka­lash­nikov, K. Tobita, D. Jackson, C. Ale­ jald­re, D. Perrault, D. Panayotov, et al., Sum­ mary of the 1st International Workshop on Environmental, Safety and Economic Aspects of Fusion Power, Nucl. Fusion 56(12), 127001 (2016).
- [6] Overview of IFMIF-DONES and Testing of Materials for DEMO (2016), https://elamatscience.ifj.edu.pl/slides/Ibarra\_slides.pdf
- [7] K. Tian, B. Ahedo, F. Arbeiter, G. Barrera, Ł. Ciu­ piński, T. Dézsi, J. Horne, D. Kovács, J. Molla, F. Mota, et al., Overview of the current status of IFMIF-DONES test cell biological shielding design, Fusion Eng. Des. 136(A), 628-632 (2018).
- [8] Q. Yuefeng, F. Arbeiter, U. Fischer, and F. Schwab, IFMIF-DONES HFTM neutronics modeling and nuclear response analyses, Nucl. Mater. Energy 15, 185-189 (2018).
- [9] A. Ibarra, F. Arbeiter, D. Bernardi, M. Ca­pel­li, A. Gar­cia, R. Heidinger, W. Krolas, U. Fis­cher, F. Martin-Fuertes, G. Micciché, et al., THe IFMIFDONES project: preliminary engineering design, Nucl. Fusion 58(10), 105002 (2018).
- [10] X-5 Monte Carlo Team, MCNP - A General Monte Carlo N-particle Transport Code, Version 5 (2003).
- [11] R.A. Forrrest, THe FISPACT-2007 User Manual (Culham Science Centre, 2007).
- [12] The JEFF-3.1 Nuclear Data Library, eds. A. Koning, R. Forrest, M. Kellett, R. Mills, H. Henriksson, and Y. Rugam, JEFF Report 21 (OECD/NEA, Paris, 2006).

[13] L.W. Packer and J.-Ch. Sublet, The European Activation File: EAF-2010 decay data library (Culham Science Centre, Oxfordshire, 2010).

## DIDELIO NEUTRONŲ SRAUTO TESTAVIMO MODULIO BANDINIŲ LAIKIKLIO AKTYVUMAS PO IFMIF-DONES EKSPLOATACIJOS

S. Breidokaitė, G. Stankūnas, A. Tidikas

Lietuvos energetikos institutas, Kaunas, Lietuva

## Santrauka

Vertinant branduolių sintezės prietaisų saugumą yra atliekami neutronų pernašos lygties skaičiavimai. Dalis jų pagrįsti Monte Karlo metodu. Straipsnyje pateikiami aktyvumų ir dozės galių skaičiavimų rezultatai, kuriuos lemia neutronų apšvita IFMIF-DONES didelio neutronų srauto testavimo modulio bandinių laikiklio struktūrinėse medžiagose. Bandinių laikiklį sudaro 14 medžiagų (11-oje iš jų pagrindinis elementas yra geležis): SS316L (N), EUROFER 97, M40 (EUROFER 97 | AISI 321 | MgO | NiCr 80/20 | INNOBRAZE ML 442), M200 (Silica Aerogel, Si (OCH3)4), M8 (Fe, Cr, W, Mn ir kiti elementai). Neutronų sukelti aktyvumai ir dozės galios įrenginio eksploatavimo metu buvo apskaičiuoti pritaikius FISPACT-2010 kodą su EAF-2010 branduolinių duomenų biblioteka. Neutronų spektras buvo gautas naudojant MCNP kodą neutronų pernašos lygties skaičiavimams. Aktyvumai ir dozės galios buvo apskaičiuotos aušimo laikams nuo 0 s iki 1000 metų. Taip pat buvo nustatyti radionuklidai, turintys mažiausia 0,5 % bendro aktyvumo vertės anksčiau minėtais aušimo laikais. Stebėjimo pradžioje geležies tipo medžiagose aktyviausias radionuklidas buvo 55 Fe, kurio aktyvumo dalis medžiagose svyruoja nuo 30 % (M200) iki 63 % (M8), o stebėjimo pabaigoje sudaro 86 % bendro aktyvumo. Didžiausia dozės galia pasižymi radionuklidas 56 Mn, o ilgesniais aušimo laiko periodais - 54 Mn ir 60 Co.