## EUROFUSION WPENS-CPR(20) 25571

D Sanchez-Herranz et al.

## Design of the HEBT components inside TIR room of the IFMIF-DONES facility

Preprint of Paper to be submitted for publication in Special Issue of 31st Symposium on Fusion Technology (SOFT2020)

<!-- image -->

This work has been carried out within the framework of the EUROfusion Consortium and has received funding from the Euratom research and training programme 2014-2018 and 2019-2020 under grant agreement No 633053. The views and opinions expressed herein do not necessarily reflect those of the European Commission.

This document is intended for publication in the open literature. It is made available on the clear understanding that it may not be further circulated and extracts or references may not be published prior to publication of the original when applicable, or without the consent of the Publications Officer, EUROfusion Programme Management Unit, Culham Science Centre, Abingdon, Oxon, OX14 3DB, UK or e-mail Publications.Officer@euro-fusion.org

Enquiries about Copyright and reproduction should be addressed to the Publications Officer, EUROfusion Programme Management Unit, Culham Science Centre, Abingdon, Oxon, OX14 3DB, UK or e-mail Publications.Officer@euro-fusion.org

The contents of this preprint and all other EUROfusion Preprints, Reports and Conference Papers are available to view online free at http://www.euro-fusionscipub.org. This site has full search facilities and e-mail alert options. In the JET specific papers the diagrams contained within the PDFs on this site are hyperlinked

## Design of the HEBT components inside TIR room of the IFMIF DONES facility

Daniel Sánchez-Herranz a* , Oriol Nomen a , Fernando Arranz b , Sofía Coloma c , Ivan Podadera b , Rodrigo Varela b

a IREC, Jardins de les Dones de Negre, 1, 2ª, 08930, Sant Adrià de Besòs, Barcelona, Catalonia, Spain

b CIEMAT, Avenida Complutense, 40, 28040, Madrid, Spain

c Centre for Automation and Robotics UPM-CSIC, Madrid, Spain

*Corresponding author: dsanchez@irec.cat

Maintenance of the High Energy Beam Transport (HEBT) line components are foreseen to be made during the two scheduled periods per year established for IFMIF-DONES facility, considering that the main one (annual preventive maintenance) will have a duration of 20 working days. Due to the radiation doses calculated and its subsequent radiation zone classification, technically challenging maintenance activities will need to be performed in the Accelerator Systems (AS) and particularly in the HEBT section located inside Target Interface Room (TIR). Thus, all HEBT components inside TIR must be designed to be maintained and replaced by Remote Handling (RH). In order to fulfil the RH requirements, a modularity approach intends to divide HEBT line section into independent large replacement units (LRUs), with localized interfaces. Splitting this section in three modules allows, first, the identification of faulty components more easily and secondly, reduces time needed for their replacement. In addition, the design of these modules has been performed to comply with beam dynamics, vacuum, building, RAMI and positioning requirements established for this section of the HEBT. As a result of the work done, the conclusions concerning the whole design process are summarized at the end of the paper.

Keywords: IFMIF, DONES, remote handling, modular design

## 1. Introduction

IFMIF-DONES (International Fusion Materials Irradiation Facility - DEMO Oriented Neutron Source) is currently being developed in the frame of the EUROfusion Early Neutron Source work package (WPENS). It will be an installation for fusion material testing that will generate a neutron flux with a broad energy distribution covering the typical neutron spectrum of a (D-T) fusion reactor. This is achieved by utilizing Li (d,xn) nuclear reactions taking place in a liquid Li target when bombarded by a deuteron beam with rectangular footprint. The energy of the deuterons (40 MeV) and the current of the accelerator (125 mA) have been set in order to maximize the neutron flux (up to ~5 × 10 18 m -2 s -1 ) to obtain irradiation conditions similar to those in the first wall of a fusion power reactor [1].

The DONES Facility is broken-down in five major areas, see Fig. 1. The systems devoted to produce and transport the high power beam are grouped under the Accelerator Systems (AS); the systems related to the Lithium Target management constitute the Lithium Systems (LS); the systems in charge of the irradiation test modules, Test Cell and their support systems make up the Test Systems (TS); the systems responsible of performing the global control of the plant are gathered under the Central Instrumentation and Control Systems (CI&amp;CS) and lastly the Site, Building and Plant Systems (PS) include the buildings and the systems supplying electrical power, cooling, ventilation, remote handling of components and services to the rest of the systems. [2].

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Fig. 1. - IFMIF-DONES facility main systems schematic [2]

<!-- image -->

The IFMIF-DONES High Energy Beam Transport Line and Beam Dump System (HEBT) is in charge of guiding the deuteron beam from the exit of the Superconducting Radio Frequency Linac towards the Lithium Target, modelling it by the use of magnetic elements to the reference shape of the beam footprint at the Lithium Target. The HEBT System will include a secondary line with a dedicated Beam Dump, analogous to the one designed for LIPAc (Linear IFMIF Prototype Accelerator), to be used during the commissioning of the IFMIF-DONES facility. Once the integrated commissioning will be completed, the aim of the Beam Dump will be to stop the pulsed beam at low duty cycle during start-up, checkout and tuning phases after a shutdown. [3].

The last part of the High Energy Beam Transport (HEBT) line section and thus of the Accelerator Systems is located inside the Target Interface Room (TIR), the closest room to the Test Cell where the Target System is hosted. Considering this characteristic as the final stage of the accelerator, requirements such as beam dynamics, safety or alignment are of great importance, and must be satisfied. In addition, due to its proximity to where nuclear reactions between deuteron beam and lithium curtain occur, high levels of radiation have been yielded in the nuclear analysis performed showing that hands-on maintenance activities will be basically non-existent which implies demanding Remote Handling requirements.

The objective of the work performed and explained in this article is to design the Target Interface Room (TIR) modules in compliance, not only with RH requirements but also with requirements imposed by beam dynamics, safety, vacuum, building, positioning, interfaces and RAMI.

Description for each of the requirements set by the different areas stated above is given in Section 2. Next section provides an explanation of the layout and integration approach followed in order to integrate all the required components and devices needed inside TIR. Section 4 is devoted to give a detailed explanation of the components and design approaches used to comply with the requirements. Finally, conclusions reached and future work foreseen to be done is described.

## 2. TIR Design Requirements

## 2.1 Beam dynamics requirements

The beam impinging the Li flow shall have an energy of 40 MeV, a CW current of 125 mA, a transverse position in the range of +/-5 mm and a special rectangular profile. The beam nominal footprint has 20 cm in the horizontal axis, and 5 cm in the vertical one. In addition, to the nominal size, it will be possible to obtain a range of beam sizes over the target by reducing the horizontal dimension up to 10 cm, keeping the vertical size fixed. The maximum beam extension containing the complete particle distribution shall be 25 and 10 cm respectively.

In order to control the beam dynamics parameters abovementioned, it is required to include the following diagnostics devices [4]:

Three Beam Position Monitors (BPM): Their function is to monitor and provide information about the position of the beam that will be used for the feedback of the steering magnets of the preceding sections of the system. In the last section of the HEBT, at least three beam position monitors should be located to steer the beam towards the target. In addition, due to the great beampipe diameter throughout this final section of 250 mm and the high de-bunching effect in this area, the measurement of the position will be quite challenging.

Two Current Transformers (CT): One for DC average current measurement and a second one for AC pulsed beam measurements. They will provide information about the beam intensity in order to monitor the beam transmission along the TIR.

Two Beam Profile Chambers (BPC): These are diagnostics vacuum chambers which combine noninterceptive and interceptive techniques to monitor the transverse beam profile. They will be equipped with two FPMs (Fluorescence Profile Monitors), a type of transverse profile monitor, non-interceptive device that detects the light produced by the passage of the beam and the subsequent fluorescence, and one SEM Grid (Secondary Emission Monitor), an interceptive instrument that measures current flowing back onto the wires when secondary electrons are ejected due to the beam energy loss when passing through the wire-grid.

All these diagnostics devices must be mechanically integrated in HEBT line section at TIR with independent alignment features added to their supports in order to ensure accurate beam positioning and characterization.

## 2.2 Safety requirements

Nuclear analysis for the Accelerator Systems (AS) of DONES have been performed, during operation (beamon) and also maintenance (beam-off) periods, with a view to study and propose a radiological design that comply with the dose rate limits established for the facility [5]. Residual radiation fields computed, following previous experience with LIPAc, with cooling times of one day and one week after beam-off, lead to classify TIR room as a specially regulated controlled area, meaning total dose rates will be &lt; 100 mSv/h. Furthermore, the contamination classification of TIR has been defined under the project criteria as limited permanence controlled area, with values of &lt; 40 (β,γ), &lt; 4 (α) for surface contamination.

From the point of view of radioprotection and with the aim of minimizing the impact of the radiation in the surrounding areas of TIR, it is necessary the inclusion of a lead shutter. It should be included as near as possible to the penetration leading to the Test Cell. Its main function is to limit gamma doses incoming from the TA area when the beam is off.

Regarding also safety, but in this case related to the safe operation of the accelerator, there is the necessity of a Fast Isolation Valve (FIV) integration as a measure of risk mitigation for a Reference Accident Scenario (RAS) identified in the facility, consisting on the potential cooling water ingress inside the beamline, in case of a leakage. [6]

## 2.3 Remote Handling requirements

Requirements regarding RH are the main parameter to take into consideration for the mechanical design and integration of the components within TIR. The methodology to define and apply these RH requirements is an iterative process to follow until reaching successful results [7]. In addition, remote handling design guidelines has been set for DONES project [8] and must be also followed. Some general requirements were established at the early-stage of the project, such as the need of designing HEBT components inside TIR to be remotely maintained, or that RH maintenance activities will be performed through the Remote Handling Equipment (RHE) installed in the Access Cell (AC) located on the floor above [9]. However, as the DONES facility design progress, more specific Remote Handling requirements emerged.

Although, in Table 1 below some of them are listed, a complete and more detailed description of these specifications is incorporated in reference [10], an article also presented to this symposium.

Table 1. - Summary of specific RH requirements for HEBT components at TIR [10]

| RH requirements for HEBT section design inside TIR room  Modularity  HEBT components located inside  TIR shall be grouped in modules  Accessibility  Modules inside TIR room shall  have enough accessibility to be  completely reachable  Simplicity  number of components and  complexity of systems in a RH  maintained shall be reduced as  much as possible.  Standardisation  Components shall be standardized,  avoiding custom, one-time and  seldom-used elements and  processes  High Reliability  Mechanical design shall prove a  high reliability level by extended  use in industry or RAMI analysis.  Decontamination Features shall be added to avoid  potential contamination.  Radiation  resistance  Components shall be designed  taken into account radiation  hardness of the material they are  made of.  Labelling  RH components shall be labelled  to avoid mismatching.  Viewing  accessibility  Modules design shall enable a  correct and clear view for the  RHE   |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

## 2.4 Vacuum requirements

An important requirement to fulfill for the correct operation of Lithium Systems, and more specifically Target System, is to maintain target vacuum conditions by means of vacuum pumps installed in the HEBT last section inside TIR room. Apart from the vacuum pumps required, a sectioning valve shall be integrated to isolate the HEBT line upstream areas during shut down of the facility.

## 2.5 Positioning requirements

With the purpose of placing the elements by RH inside TIR and progressively reduce the number of degrees of freedom available to ensure that the mating process is carried out in a controlled manner, features shall be added to guide and place them correctly.

Apart from the general positioning features expressed before, it is also required to integrate individual alignment mechanisms to allow misalignment correction of each component. The most restrictive devices foreseen are the beam diagnostics instruments that must be positioned accurately for their proper operation, as previously stated in section 2.1.

## 2.6 Building requirements

All the necessary components and devices established for the correct operation of the accelerator by the different systems and functional aspects stated in the preceding sections, shall be installed inside TIR room. Fig. 2 depicts architectural drawings of the Target Interface Room and neighboring areas.

Fig. 2 - Target Interface Room (TIR) area drawings, side-view (top) / top-view (bottom)

<!-- image -->

Consequently, its dimensions limit the number and type of design for the modular approach expected. In particular, the most restrictive dimension is the available length from east to west of the room, where not only devices are going to be integrated, but also bellows and Remote Disconnection Systems (RDS) shall be added.

Height of the room being 5500 mm from floor to upper hatch must be kept in mind, as well as the center of the complete beam line set at 1500 mm. These two dimensions impact on the design of the supports and the maximum height of the components.

## 2.7 Interfaces requirements

On the TIR left-hand side, the connection with the collimator embedded inside the RIR/TIR wall imposes a requirement of available space for the inclusion of a Remote Disconnection System. Additionally, in case of collimator failure, it has to be disassembled through the TIR which imposes some limitations to take into account.

On the east side, the Though Wall Beam Duct (TWBD), also requires the possibility of replacement through the TIR in case of failure [8]. The TWBD is welded to the shielding plug, therefore the design shall account for the possibility of a welding orbital machine in that area in case the TWBD should be replaced. As in the case of the left interface with collimator, bellows should be included for the allowance of some misalignment between components plus the possibility of length reduction for hoisting.

## 2.8 RAMI requirements

DONES facility is expected to be operable 24/7 with a target availability of at least 70% during the whole operational time foreseen of 20 years. This means that the plant is expected to be available for irradiation 255.5 days each year. Such average operational availability requirement, combined with the foreseen scheduled annual maintenance scheme (20+3 days), implies an inherent availability requirement of 87% for the complete Accelerator Systems (AS). In order to reach the AS availability value mentioned before, the HEBT system will need to obtain higher values for its total availability.

## 3. Devices Mechanical Integration

The distribution and integration of the components to comply with all the requirements leads to a modular design approach based on Large Replaceable Units (LRUs). Modularity in essence, intends to separate into independent modules with localised interfaces. By dividing a section into different modules generally allows diagnosing faults more easily and consequently a great reduction in maintenance time and cost.

HEBT line section inside TIR has been divided into three LRUs [8] shown in figure 3, which could be moved individually outside of the TIR room to perform maintenance or replacement as a whole or just specific component. "Hot spares", ready-to-use modules will be stored outside TIR, available to be transported, installed and commissioned in a short period of time, minimizing the MTTR.

Fig. 3. - Modular design HEBT components inside TIR

<!-- image -->

Components integrating each module have been chosen carefully trying to keep a good balance between DONES facility correct operation and remote handling design guidelines set in the project.

Next sections intend to explain how the TIR modules design has been carried out trying to comply with requirements imposed. A more detailed picture showing all three modules with the component distribution can be found on next page in Fig. 4.

## 4. Requirements Compliance

## 4.1 Beam diagnostics instrumentation

Most of the beam diagnostics devices to monitor the beam properties at the Target will be located inside TIR room, just upstream of the Test Cell, since the target will not be directly accessible by the Remote Handling Equipment and given the large radiation doses expected. The following monitors and their distribution have been considered at the TIR, following the requirements set by Beam Dynamics and Diagnostics groups.

In module I, two BPMs have been implemented, one at the entrance and the second one at the exit allowing better measurement of the evolution of the beam position along the length of the beamline. The two current transformers required are also added to module I to provide a beam current measurement as close to the target as possible, avoiding at the same time damaging them due to the radiation coming out of the Target System. Finally, a BPC composed of two FPMs and one SEM Grid is integrated in this first module with the aim to monitor and check that the desired beam profile has been properly obtained and correct it if necessary.

For module III, only one BPC and one BPM have been incorporated due to the lack of space, as in the case of module I. These last two instruments will supply the ultimate beam position and profile before the beam enters into the Test Cell and reaches the Lithium target.

## 4.2 Safety features

Module III includes a lead shutter that is installed inside of a vacuum chamber. On top of the vacuum chamber a pneumatic cylinder will operate for lifting or lowering the in-vacuum lead plug. This shutter has been placed as close as possible to the right-hand penetration of the room because of the Target System proximity and the Lithium loop hosted inside which produces high neutron backscattering fluxes inducing high levels of activation on upstream areas.

Furthermore, one of the most important components safety-wise is added to Module III (near the penetration leading to the Test Cell), the Fast Isolation Valve (FIV). This rapid response valve located very close to the TWBD will isolate the Target System (TS) and hence the lithium target in the event of water or air ingress inside the beam transport line is detected, for instance, a leakage in cooled components such as scraper, preventing the exothermic reaction between water and lithium. [11].

Fig. 4. Modular design and device integration inside Target Interface Room (TIR).

<!-- image -->

## 4.3 Modularity, Mechanical Integration and RH design

With the purpose of easing the RH replacement operations and satisfying some RH requirements in the mechanical design, such as simplicity and standardization, three alternative solutions for gripping and lifting the entire modules though their top are proposed and are currently being assessed. The most suitable option will be adopted as the standard solution for all the accelerator components requiring RH on the facility.

Module I with multiple diagnostics integrated on it has a total weight of 968 kg. In this first module a novel Remote Handling solution has been implemented. It is a Modular Quick-Change System whose commercial name is VERO-S, composed of two main elements, the clamping modules and clamping pins. The clamping procedure is carried out by an integrated spring package.

The lightest among all three modules is Module II weighting approximately 550 kg. In this case, a classical Remote Handling gripping solution is proposed. A square-shaped structure on top of the module is provided with four boreholes on each corner in order to insert twistlocks.

Last module III, is the heaviest with a weight of 1625 kg, mainly due to the inclusion of the lead shutter on it, however, the payload of 3 Tons for the Access Cell Mast Crane (ACMC) is not exceeded. A third alternative to grip, hoist and replace modules inside TIR is the Gripper Change System (GCS). It is similar to the Modular Quick-Change System (VERO-S) proposed in module I

with some features added. This robotic system has two different plates, the Tool Plate provided with an anodized aluminium body and three hardened stainlesssteel bearing races, installed in the module, and Master Plate which compromises three locking mechanisms. Tapered pins located on the Master plate mates with holes in the Tool plate to ensure repeatable alignment during the coupling process. Proximity sensors are designed into the body of the Master plate to verify locked/unlocked positions.

## 4.4 Valves and pumps installation

Module II is devoted to vacuum components, it includes two cryopumps, that will work alternatively, allowing the conditioning of one pump while the other keeps the nominal vacuum value in the beamline and Lithium system. These cryopumps are connected to a cross-chamber through gate valves, so they can be sealed and isolated, when not working or during regeneration cycles. This transversal placement of the pumps has been chosen to avoid their contamination by evaporation products coming from the Lithium target.

At the entrance of Module II, a third gate valve has been integrated for vacuum sectorization, thus, isolation of the upstream HEBT line and hence the Accelerator Systems (AS) from the Lithium Target during shut down is achieved.

## 4.5 Positioning capabilities

To position the modules as a whole item inside TIR by Remote Handling operations, three V-shaped seats has been added to them. To ease and aid the guiding operations, guiding pockets have been added, during the lifting/lowering movement with RH equipment, the modules have to move in a vertical trajectory while the guiding pockets are engaged with the vertical guiding bars that will be installed on the support, only when these two features are disengaged, the module is freed for horizontal movements [12][13]. Fig. 5 shows the features installed in module III as example:

Fig. 5 - TIR Modules guide &amp; positioning features

<!-- image -->

Even though, individual alignment mechanisms are currently under-development, a conceptual first design has been integrated on each component. Every specific support will be equipped with block-and-bolt systems with various fine pitch bolts to position the devices over the horizontal plane correctly. To manipulate the height of the device, a preliminary assembly composed of a threaded bar, concave/convex washers and nuts is included, which will be adapted later on to the RHE capabilities defined.

## 4.6 Space limitations

For any TIR module replacement it is necessary to disconnect/connect it first from the line. To be able to disengage the modules by means of Remote Handling, two RDS have been developed and are under-study. Both alternatives are based on the same principle, compression and extension of a welded bellow. The difference between them is the type of mechanism used, mechanical or pneumatical. As in the case of the hoisting alternatives, multiple concepts are proposed and being assessed, the best option found will be set as standard for all RH maintained components.

The mechanical approach shown on the left-hand side in figure 6 uses a rack-pinion mechanism adapted to RHE. By rotating the cone-head vertical shaft attached to the pinion, the rack scrolls horizontally backward and forward depending on the turning direction, guiding bars have been included to keep the tube as aligned as possible during engage and disengage operations [14]. The second proposal, seen on the right part of the figure works by shrinking and elongating the bellow using pneumatic actuation. Two double acting linear actuators are integrated on both sides of the assembly. Over the top and vertically located there will be two RH pneumatic plugs connected to two manifolds which shall distribute evenly to the actuators the air in order to move both stems at the same pace. Guiding bars are also integrated for this second conceptual design.

Both mechanisms explained above have been designed to be connected and disconnected to/from a fixed clamp component, whose working principle is based on the RDS for the beam dump implemented in LIPAc [15]. This mechanical element will consist of two remote handling articulated collars, each of them actuated independently. These double articulated collars are a multi-segmented chain with each segment including a V-shaped clamping element. The chains are tightened or loosen around the flanges using two conehead threaded rods.

Fig. 6 - TIR Modules connection/disconnection Remote Disconnection Systems

<!-- image -->

The total length of the modules, taking into account that the RDS mechanisms added on each side are 1684 mm for module I, 1038 mm in module II and 1818 mm for module III. Design of the modules including their remote handled disconnections systems on both sides and RH actuated collars in-between them lead to a total distance of 4875 mm, which fits into the available length established. Module III is the highest with 1810 mm given the minimum height constraint set by the lead shutter actuator included.

## 4.7 Lateral interfaces

The potential need of the collimator replacement, in case of failure, through the TIR has been taken into account in the design. By putting module I and II aside, and removing the RH articulated collar located between them, the extraction of the collimator will be allowed since its total length is 2900 mm.

Similar but more complex situation occurs with the TWBD at the opposite side of the TIR room. Taking into consideration that its length is 3732 mm, it will be necessary the displacement of modules I, II and III, in addition of the two RDS to properly slide the TWBD out of the wall between TIR and Test Cell (TC) where is embedded and replace it.

## 4.8 System availability

Towards increasing the availability of the HEBT and thus of the AS and DONES plant, the design of the TIR modules has been carried out using as much as possible technologies and solutions that have been already tested and qualified in similar facilities, for instance, LIPAc. All the components have been designed having in mind a quick maintenance and/or replacement time. The modular design followed inside TIR based on LRUs allows to reduce the downtime and therefore increase availability by having a hot spare of each complete module prepared and ready-to-use for installation and commissioning.

## 5. Conclusions

The modular design proposed for the HEBT beamline section inside TIR room complies with the requirements imposed from different systems in the IFMIF-DONES project, the most important characteristics of the designed components are summarized below:

- Integration of all the necessary diagnostics devices for beam characterization which allow an adequate monitoring of the beam dynamics requirements established and therefore the safe operation in the facility.
- Safety features that limit high neutron backscattering fluxes, incoming from TC inducing great levels of activation by means of the lead shutter. Also, the Fast Isolation Valve integrated will prevent water ingress in the Target and the reaction with the Lithium curtain.
- RH compatible design with features that allow fast replacement of modules and optimization of the facility downtime for maintenance operations.
- Vacuum pumps have been implemented in order to sustain the vacuum pressure level within specifications.
- Individual alignment supports are included to properly position each of the components in their nominal position.
- The dimensions of the room and the need to include disconnection systems have been taken into account.

## 6. Future work

There are areas of the design that will be detailed and improved in the future. For beam dynamics aspects, the implementation of a beam halo monitor would be quite beneficial helping to minimize small losses and providing valuable information about beam halo formation.

Concerning the alignment of the components, a further level of detail must be achieved in the design and implementation of individual alignment supports, in order to adapt their manipulation to the RH equipment available. Also, and with the aim to position and align the different modules within TIR by Remote Handling operations, a levelling and adjustable mechanical support tables are being developed.

There is the need of integrating RH adapted connections in the modules, as close as possible to the components, for power cables, pneumatic hoses, signal wires, vacuum roughing/evacuation piping and any other external connection needed for the devices control and operation. RH features must be included in the articulated collars proposed to be removed by RHE.

## Acknowledgments

This work has been carried out within the framework of the EUROfusion Consortium and has received funding from the Euratom research and training programme 2014-2018 and 2019-2020 under grant agreement No 633053. The views and opinions expressed herein do not necessarily reflect those of the European Commission.

Work performed also supported by FusionCAT project, within the framework of the ERDF Operational Programme for Catalonia 2014-2020, with the support of the Catalan Government.

## References

- [1] A. Ibarra et al., The IFMIF-DONES project: preliminary engineering design, Nuclear Fusion 58 (10) (2018). https://doi.org/10.1088/1741-4326/aad91f
- [2] A. Ibarra, et al., The European approach to the fusionlike neutron source: the IFMIF-DONES project, Nucl. Fus. 59 (6) (2019). https://doi.org/10.1088/1741-4326/ab0d57
- [3] O. Nomen, D. Sanchez-Herranz, C. Oliver, I. Podadera, R. Varela, F. Ogando, F. Arranz, S. Coloma, R. Heidinger and H. Dzitko. Preliminary design of the HEBT of IFMIF DONES. Fus. Eng. and Design, 153, 111515. 2020. https://doi.org/10.1016/j.fusengdes.2020.111515
- [4] I. Podadera, A. Ibarra, D. Jiménez-Rey, J. Mollá, C. Oliver, R. Varela, V. Villamayor, O. Nomen, D. SánchezHerranz. "Beam Diagnostics for the Multi-MW High Energy Beam Transport Line of DONES", in Proc, IBIC19, Malmö, Sweden, Sep. 2019, pp. 200-204. https://doi.org/10.18429/JACoW-IBIC2019-MOPP042
- [5] Radiation maps in and around accelerator systems. EFDA\_D\_2NFZ7J (2020)
- [6] Martín-Fuertes, F.; García, M.E.; Fernández, P.; Cortés, Á.; D'Ovidio, G.; Fernández, E.; Pinna, T.; Porfiri, M.T.; Fischer, U.; Ogando, F.; Mota, F.; Qiu, Y.; Helminen, A.; Potempski, S.; Gallego, E.; Ibarra, Á. Integration of Safety in IFMIF-DONES Design. Safety 2019, 5, 74.
- [7] Coloma, S., Ferre, M., Cogollor, J. M., &amp; Miccichè, G. "Methodology for Remote Handling Operations in IFMIF-DONES". Fusion Engineering and Design 146 (2019), 1334-1337.

https://doi.org/10.1016/j.fusengdes.2019.02.070

- [8] Basic guidelines for the design of remotely maintained components in DONES. EFDA\_D\_ 2NG7SN (2018)
- [9] G. Miccichè, M. Ascott, A. Bakic, D. Bernardi, J. Breñosa, S. Coloma, O. Crofts, G. Di Gironimo, M. Ferre, G. Fischer, A. Ibarra, A. Karap, I. G. Kiss, C. Kunert, L. Lorenzelli, G. Mitchell, M. Mittwollen, P. Pagani, S. Papa, G. Porempovics, T. Tadic, T. Matyas. "The remote handling system of IFMIF-DONES". Fusion Engineering and Design 146 (2019) 2786-2790. https://doi.org/10.1016/j.fusengdes.2019.01.112
- [10] Fernando Arranz, Oriol Nomen, Daniel Sánchez-Herranz, Sofía Coloma, Francisco Martín-Fuertes, Gioacchino Micciché, Angel Ibarra. "Remote Handling operations for Target Isolation Room modules of DONES". Presented in SOFT 2020.
- [11] G. D'Ovidio, F. Martín-Fuertes. "Accident analysis with MELCOR-fusion code for DONES lithium loop and accelerator", Fusion Engineering and Design 146 (2019) 473-477. https://doi.org/10.1016/j.fusengdes.2018.12.093
- [12] S. Rajendran and J. Palmer, "ITER remote handling code of practice," ITER\_D\_ 2E7BC5, 2009
- [13] R. Vanhoutte, S. Evrard, E. Harrouch, M. Lazzaroni, M. Lino Diogo dos Santos, D.E. Nogtikov, J. Renedo Anglada, D. Brethoux, A. Ebn Rahmoun, F.J. Harden, R. Lopez. "Design &amp; optimization of the alignment supports for the new laminated magnets for the CERN East Area consolidation project", in Proc, IPAC19, Melbourne, Australia, May. 2019, pp. 4020-4022. https://doi.org/10.18429/JACoW-IPAC2019-THPRB086
- [14] F. Sanchez Galan, S. Evrard, M. Lazzaroni, J. Perez Espinos, M. Raymond, A. Gaddi, C. Adorisio, H. Vincke, I. Bergstrom, L. Krzempek, D. Brethoux. "Optimising Machine-Experiment Interventions in HL-LHC", in Proc, IPAC17, Copenhagen, Denmark, Jun. 2017, pp. 35403543.

https://doi.org/10.18429/JACoW-IPAC2017-WEPVA114

- [15] F. Arranz, O. Nomen, B. Brañas, J. Castellanos, J. Molla, D. Gutierrez. "Remote disconnection system for the beam dump of the LIPAc accelerator", Fusion Engineering and Design 125 (2017), 123-126. https://doi.org/10.1016/j.fusengdes.2017.10.010