ISBN: 978-3-95450-209-7

## PRELIMINARY ENGINEERING DESIGN OF THE CENTRAL INSTRUMENTATION AND CONTROL SYSTEMS FOR THE IFMIF-DONES PLANT

M. Cappelli † , ENEA, Frascati Research Center, Rome, Italy

A. Bagnasco, Ansaldo Nucleare, Genova, Italy A. Ibarra, CIEMAT, Madrid, Spain

conditions of fusion reactors. In particular, since 1994 EU and Japan joined their effort in the so-called IFMIFEVEDA (IFMIF-Engineering Validation and Engineering Design Activities) project, conducted in the framework of the bilateral EU-Japan Broader Approach Agreement [3, 4]. Recently, the EU supported the development of a Li(d,nx) neutron source called IFMIF-DONES (International Fusion Materials Irradiation Facility-DEMO Oriented NEutron Source) through the EUROfusion Work Package Early Neutron Source (WPENS) in collaboration with F4E Agency.

The objective of the IFMIF-DONES design [5] is to provide a high-energy neutron source with sufficient intensity and irradiation volume to generate material irradiation test data for the design, licensing, construction and safe operation of DEMO as defined in the EU Roadmap [6, 7, 8].

The general scheme of the current IFMIF-DONES Plant configuration is shown in Fig. 1, where five major groups of systems can be identified: Accelerator Systems; Lithium Systems; Test Systems; Plant Systems, and Central Instrumentation and Control Systems.

Figure 1: IFMIF-DONES Plant general scheme [9, 10].

<!-- image -->

The Accelerator Systems (AS) comprise all systems and components for the generation, acceleration and shape of the deuteron (D+) beam. Similarly to the IFMIF accelerator, the DONES accelerator consists of a sequence of acceleration and beam transport stages producing a 5 MW deuteron beam (125 mA, 40 MeV) with a rectangular cross section of [100, 200] mm × 50 mm, which impinges on the free surface liquid lithium target (25 mm thick, 260 mm wide), cross-flowing at 15 m/s on the opposite side. The stripping reactions generate neutrons that interact with the materials samples enclosed in

## Abstract

IFMIF-DONES is the International Fusion Materials Irradiation Facility-DEMO Oriented NEutron Source, an accelerator-based neutron source where a high-energy deuterons beam is focused on a fast flowing liquid lithium jet to produce high-energy neutrons via stripping reactions with intensity and irradiation volume sufficient to generate material irradiation test data for design, licensing, construction and safe operation of the DEMO fusion reactor. This work presents the design of Central Instrumentation and Control Systems for the IFMIF-DONES plant and describes its most recent development. After a general overview of the current status of the design, the differences with respect to the corresponding system developed during the previous phases of the project will be highlighted. The paper describes the overall architecture (in terms of definitions, functions and requirements) and provides details about the identification of subsystems and equipment. A particular attention will be given to the I&amp;C Networks connecting infrastructures.

## INTRODUCTION

The irradiation environment in the future Fusion Power Plants is characterized by the presence of 14 MeV fusion neutrons in the first-wall region [1]. Understanding the degradation properties of materials and components throughout the operating life of the reactor is a main problem in allowing the design and plant licensing by the safety authorities. Presently available n sources are not adequate to reproduce fusion-like environment.

The availability of a fusion-relevant neutron source is therefore of the utmost importance for understanding the degradation of the fusion material under neutron bombardment during the life of the fusion reactor. In particular, this is a necessary requirement to a safe design for the DEMOnstration Fusion Reactor (DEMO), whose invessel materials will be exposed to neutron fluxes up to 5 × 10 18 m -2 s-1 with a peak energy of 14.1 MeV. This could produce a displacement damage in excess of 10 dpa per year of operation with an He production rate of 10 -13 appm/dpa [2].

Since more than 40 years, an international consensus has been reached on the development of an acceleratorbased neutron sources exploiting D-Li stripping reactions (Li(d,nx)) as the optimal choice to provide the appropriate neutron flux and spectrum for reproducing the irradiation

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

† mauro.cappelli@enea.it

ISBN: 978-3-95450-209-7

the High Flux Test Module (HFTM) located directly behind the lithium target.

The Test Systems (TS) undertake the role of enclosing and positioning the test samples behind the lithium target, and the requirements for regulating the irradiation circumstances are met. The TS include, in particular, the HFTM, the Start-up Monitoring Module (STUMM) and the closed cavity or Test Cell (TC) housing the lithium target and test modules.

The Lithium Systems (LS) comprise three main systems: the Target System, which has the role of accelerating, shaping and positioning the lithium jet; the Heat Removal System, which has the objective of removing the heat generated by means of separate heat exchangers; the Impurity Control System, consisting of a branch line that extracts a fraction of the lithium from the main loop and re-injects it after purification and impurity analysis.

The plant operation is supported by general services called Plant Systems: Heating, Ventilation and Air Conditioning System (HVAC); Heat Rejection System; Electrical Power System; Service Water and Service Gas System; Radioactive Waste Treatment System and Gas Radioactive Waste Treatment System; Fire Protection System.

The entire plant operations are regulated by the Instrumentation and Control (I&amp;C) System, whose preliminary design is the object of this paper.

A detail description of the IFMIF-DONES design is included in [5, 6, 9], while the general architecture of the Instrumentation and Control (I&amp;C) System is widely described in [10, 11, 12]. In this paper, a particular attention will be given to the current design of the central Control, Data Access and Communication System and the related Local Instrumentation and Control Subsystems, and to the I&amp;C Networks connecting infrastructure.

## THE CENTRAL INSTRUMENTATION AND CONTROL SYSTEMS (CICS): GENERAL ARCHITECTURE

Following a current trend in similar plants (see for example the ITER case, as in [12, 13], or other modern tokamak designs [14, 15, 16]), the DONES I&amp;C System is designed with a hierarchical structure, starting from the top level, the Central Instrumentation and Control Systems (CICS), down to the Local Instrumentation and Control Subsystems (LICS) level [10, 11, 12]. The DONES I&amp;C System consists of entirely distinct systems with autonomous complex tasks and adopts a distributed control strategy that guarantees independence to each of the devices to handle the single control loops introduced at the LICS stage. At the same time, the CICS guarantee a central supervision and control for the entire local I&amp;C subsystems. As a system, it is responsible for managing, monitoring and controlling all plant parameters and variables, and for storing and visualizing data, at a global level. It is mainly based on a set of supervisory buildings that guarantee continuous, bi-directional communication with LICS and, at the same time, real-time (networking) interaction with other (sub)systems.

On the other hand, the LICS are in charge of the control of every subsystem and component in order to guarantee that all process variables are maintained inside the required range at a local level. The raw signal data acquired by the LICS are processed and converted into process variables compatible with the selected framework and then made available through the whole plant. Typically, the I&amp;C Systems include at each hierarchical level an HMI and operational monitoring functions (if required).

Control systems at separate hierarchical levels are interfaced with Ethernet Local Area Networks (LANs) that communicate through common control software in order to allow communication between distinct hardware platforms. Local control systems could use a particular network or fieldbus depending on specific commercially available controllers. However, these local systems with non-standard communication protocols should have an interface system to allow communications between different control systems.

The control architecture is implemented as a real-time distributed control system based on open source software tools, libraries and applications. Robust control hardware is used: programmable logic controllers (PLC), programmable automation controllers (PAC), and industrial PCs (IPC) high performances devices, e.g. Field Programmable Gate Arrays (FPGA). The communication is based on multi-control/supervisory networks (Ethernet and fibre optic 10 Gigabit Ethernet) for controlling and monitoring the full plant operation and status.

The CICS consists of three systems: COntrol Data Access and Communication (CODAC) System; Machine Protection System (MPS); Safety Control System (SCS). Each system at the central level is in a continuous, bidirectional communication with the corresponding system at the local level by means of dedicated instrumentation and control networks and/or buses: CODAC Network, Interlock Bus Network, and Safety Network (Fig. 2).

The Local CODAC Controllers (LCC) are connected to the field sensors and actuators in order to acquire data and perform local control logics. Local Controllers work in normal operation, including the execution of non-safety interlocks. Each Local Controller is in charge of executing operations only on a single, well-defined LICS subsystem. The Local Interlock Controllers (LIC) are connected to dedicated field sensors and actuators in order to acquire data and perform local safety-related interlock logics. Each LIC is in charge of protecting only a single, well-defined LICS sub-system. The Local Safety Controllers (LSC) are related to the following specific tasks: plant safety, occupational safety, personal access safety, radiation monitoring. This class can include a heterogeneous set of devices: controllers, hardwired units, smart sensors, etc. All local components are housed in local I&amp;C cubicles. Each local I&amp;C cubicle embed all I&amp;C components (fast and slow controllers, switches, signal I/O interfaces).

Figure 2: DONES I&amp;C Systems: General First Level Architecture [10]

<!-- image -->

## COntrol, Data Access and Communication (CODAC) System

The COntrol, Data Access and Communication System (CODAC) coordinates the DONES systems, organizes their operation and collects and archives information produced by the DONES plant. CODAC is in charge of managing (supervision and control) the normal operation of the Systems and must prevent the activation of the Machine Protection System. CODAC System is designed as a two-level architecture: the Central CODAC System that coordinates control and monitoring across the LICS; the Local CODAC System, which is a component of each local system providing control during ordinary operation. The CODAC System must ensure the coordination of all the physical systems, their configuration, synchronisation and data retrieving. The LICS are responsible for interpreting the high-level command and converting it into multiple unit commands, controlling its execution, and returning the execution status to the CICS. The overall time sequence of operation is centrally controlled by the timing signal from the Timing Subsystem (TS). The TS sends master clock signal to the TS gateway of each System to synchronize all the clocks of the Plant. The Data Management (DM) Subsystem is responsible of archiving process information and system information. The Operator User Interface is based on the Human-Machine Interface (HMI) Subsystem, implemented in the operator console in order to permit the user to monitor, supervise and control all relevant processes. The Alarms and Warnings (AW) Subsystem provides information to the operators through a CODAC system service for fault diagnosis and correction. Alarms alert the operator in the event of deviations or anomalies from normal operating conditions.

## Machine Protection Subsystem (MPS)

The Machine Protection System (MPS) is in charge of implementing all the investment protection strategies at the different plant levels, ensuring plant protection against failures of systems or components, failures of the central and/or local control systems, incorrect operation by

means of dedicated sensors, controllers and actuators. The MPS is designed according to the IEC-61508 reference standard. The MPS has an interface to the CICS for coordination and data handling and is designed as a two level architecture: the Central Machine Protection System (CMPS), for plant-wide protection actions, and the Local Machine Protection System (LMPS), for local protection events. CMPS and LMPS communicate through dedicated networks. The main system functionalities of the CMPS are: receive the interlock events from local LMPS; coordinate and transmit the interlock actions to local LMPS; provide warning threshold information; inform the operator about the status of all the LMPS; enable operator actions (e.g. permits, resets and overrides); log all the data related to the interlock function being performed; interface the CICS for monitoring purposes and to archive data. The LMPS main system functions are: detect the interlock events; execute interlock actions, either standalone or commanded by CMPS; inform the CMPS on the occurrence of the local events/actions. From a general perspective, the interlock actions can be divided in two classes as a function of the response time: fast interlocks (from 300 ms to less than 30 µs) and slow interlocks (above 300 ms). The MPS will rely on a set of critical monitors to trigger the interlock events. The most relevant for DONES are: Beam Loss Monitors (BLoMs), Level gauges, Li leak and pressure sensors, Pressure sensors, Strain gauge/thermocouples, Fission chambers in the Test, Radiation monitors.

## Safety Control System (SCS)

The Safety Control System (SCS) is a dedicated nuclear class safety system dedicated to the execution of all the protection tasks specified for people or the environment. The SCS coordinates the individual protections provided by the Safety Procedures, enables manual control by the operator and displays data required for the operator supervision and control. It is implemented in an independent and dedicated architecture, minimizing the interactions with the conventional systems. The SCS is mainly composed by four subsystems. The Plant Safety Subsystem (PSS) is based on a hierarchical architecture, which implements local functions and central functions, according to the general I&amp;C architecture. In a local safety function the safety feedback loop (i.e. sensor detection of an event and subsequent safety action by the actuator) is performed within a single LICS. The function is executed locally and autonomously inside the local safety system and monitoring data are sent to the correspondent safety HMI in dedicated control-room consoles. In a central safety function the safety feedback loop is performed by different LICS. The Occupational Safety Subsystem (OSS) provides I&amp;C Safety functions for the protection of people against all conventional hazards (toxicological, physical, electrical, cryogenic or other), generated inside the plant in normal and abnormal circumstances. The safety functions can be implemented either locally or centrally by means of different protection systems (local passive systems, local hardwired systems, local programmable systems, central

ISBN: 978-3-95450-209-7

programmable systems). The system is based on the personnel and zone classification with respect to the level of hazard. Exposure to ionizing radiation imposes that this subsystem will be in tight connection with the Personal Access Safety Subsystem (PASS) and the Radiation Monitoring System for the Environment and Safety (RAMSES). The PASS has the objective of implementing all the actions ensuring the safety of the people in specific areas generating safety risks. Access safety functions are for example stopping hazardous equipment or devices in case of intrusion, or banning access on detection of a risk. Typical access statuses will be defined for the access to the main experimental room (e.g. free, controlled, warning, pre-pulse, pulse-on). The RAMSES objective is to keep the radiation doses of workers as low as practically possible, not exceeding the dose limits set. As a consequence it contributes to the protection of the personnel in radiation-controlled areas by permanently dose rates monitoring and comparison with alarm levels. In case of excessive dose levels, RAMSES is responsible of the activation of evacuation alarms and interlocks.

## THE CENTRAL INSTRUMENTATION AND CONTROL SYSTEMS (CICS): PRELIMINARY DESIGN

## The CODAC Architecture

The architecture of the CODAC section of the DONES control system is presented in Fig. 3. It is based on two layers: the higher is the CICS level, which is related to the central control and to the control room. The lower layer is the section related to the plant sub-systems.

The CODAC Network-Plant section connects the following components:

- CODAC servers: high performance industrial grade servers with redundant storage capabilities and redundant power supplies, running either CODAC run-time applications or CODAC services. The servers are connected both to the control room and the plant level networks;
- Time Servers: reference time generators, providing time synchronization to all of the system components;
- Gateways (for both MPS and SCS systems): provider of data translation and separation of the connecting networks/systems;
- Local Controllers: conventional control systems dedicated to the low level control of a given LICS, i.e. the Local Controller acquires raw signals, after processing and conversion, makes them available to the CODAC System. The Local Controller is also in charge of executing the local control loop according to the parameters given by the CODAC System.

Figure 3: The CODAC architecture.

<!-- image -->

The two-layers approach allows obtaining a logical and physical segregation between domains having different performance and security requirements. The Operator Stations do not need to access directly to the data provided by the Local Controllers and the communication is always mediated by the server. Malicious or erroneous operation performed on the Operators Station cannot impact directly on the Local Controller, and thus to the process. Different security policies can be applied to the Server and Operators Stations with the aim of restricting the level of access to sensitive information, hosts and services while ensuring an organisation can continue to operate effectively with different requirements. It is also possible the addition of new, task-specific Operator Station without impacting on the plant performance.

From the functional point of view, the Control Room section is dedicated to the exchange of data related to the HMI only, while the Plant section has to deal with a set of different services: operation control, data transfer and time synchronization. These transport services have to be exploited by a single infrastructure, thus is necessary to adopt a virtualization strategy to optimize performances.

## The MPS Architecture

Figure 4 shows the architecture of the MPS section of the DONES control system, divided into two levels: the CICS higher level is related to the centralized actions and to the control room, while the LICS lower level is related to the local interlock operations.

Figure 4: The MPS architecture.

<!-- image -->

The Interlock Network-Control Room connects the following elements:

- MPS central controllers, both fast and slow;
- MPS servers;
- MPS Operator Station, both main and backup;
- Gateways, for the exchange of data with the CODAC system.

The Interlock Networks-Plant (IN-P) level connects the CMPS controllers to the LMPS. From the architectural point of view, no distinctions are made on the basis of the LPMS characteristics. According to the complexity of the protected system, the LMPS could be a programmable device (i.e. a fast or slow controller), or hardwired logic. In the latter case, the necessary signals are exchanged by means of fast or slow Remote I/O devices. In any case, field data are exchanged through the IN-P network. The architecture also considers the possibility of having direct hardwired links between different actors:

- LMPS and central fast controllers: this link is for specific signals, both inputs and outputs, that need to be managed directly by the central fast controllers;
- SCS and central fast controllers: this link is for control output coming from the SCS;
- Central slow controller and central fast controller: this link is for hardwired signals to be exchanged between fast and slow controllers.

According to the specific requirements, it is possible to identify three categories of IN-P: (i) Interlock Network - Plant - Fast; (ii) Interlock Network - Plant - Slow; (iii) Interlock Network - Plant - Hardwired. The possibility of sharing the same physical infrastructure between Fast and Slow section should be considered for cost and space optimization. Since the MPS has to deal with safety issues, the central controllers are redundant and specific synchronization links have to be designed to connect the main controller to the corresponding backup one. These links are not considered as part of the Interlock Networks.

## The SCS Architecture

According to its functional description, the Safety Control System (SCS) is composed by a set of 4 I&amp;C systems.

Each of them is related to a different type of hazards to be detected and mitigated:

- The Plant Safety System (PSS) is related to the protection of the environment and people against radiological hazards;
- The Occupational Safety System (OSS) is in charge of the protection of the environment and people against non-radiological hazards;
- The Personnel Access Safety System (PASS) have to deal with the management of the people's access to the different parts of the plant;
- The Radiation Monitoring Subsystem for the Environment and Safety (RAMSES) is charge of the radiological monitoring of the entire plant.

In this preliminary phase of the design, it was assumed that the safety level (SIC, Safety Importance Class) assigned to the PSS requires the following features:

- Double redundant trains for signal acquisition, elaboration and generation, based on safe controllers or logic solvers;
- Double redundant communication channels;
- Duplicated sensors;
- 1oo2 (1 out of 2) actuation logics;
- Hardwired connections between central system and field.

For what concerns the OSS, it was assumed the adoption of the following solutions:

- Safe controller with hot stand-by backup;
- Double redundant communication channels;
- Single sensors;
- Single actuation logics;
- Bus-based connections.

Finally, regarding the PASS and the RAMSES subsystems, it was assumed the adoption of COTS platforms having proven installation history in plant with similar characteristics.

Figure 5: The SCS architecture.

<!-- image -->

Each SCS sub-system is thus characterized by a different architecture and relies on a specific network to connect the distributed parts between them. Figure 5 presents the preliminary design of this architecture.

The Safety Network architecture is composed by two main layers. At the upper layer there is the Safety Network - Control Room (SN-CR), while at the lower layer

there are four different networks, corresponding to the four sub-systems composing the SCS:

- Safety Network - PSS section (SN-PSS);
- Safety Network - OSS section (SN-OSS);
- Safety network - PASS section (SN-PASS);
- Safety Network - RAMSES section (SN-RAMSES).

Each safety sub-system has a different SIC classification, but all the sub-system have to be accessed as a whole from the operators. For these reasons, the lower part of the architecture consists in four separate "legs", that are different for performance, configuration and physical means. On the contrary the upper part of the architecture is in charge of the seamless integration of the safety data to be accessed by the operator and by the CODAC gateway. The separation between the different levels of the networks has to be always mediated by the servers, to guarantee a separation layer between the operators and the safety controllers. An additional degree of separation is created toward the interfacing CODAC system, that is not safety-classified, by means of the CODAC gateway.

The SN-CR connects all the data servers related to each part of the SCS to each specialized Operator Terminal, and to the CODAC Gateway.

The PSS implements the safety functions. It is composed by two identical trains collecting the necessary inputs from the plant sensors, that are installed different part of the plants. Input data also include signal coming from the other SCS sub-systems, that is the OSS, the PASS and the RAMSES, as well as the signals generated from the operator hardwired HMI. Each controller performs the safety logics in independent way, while a double voting mechanism checks the elaboration results for discrepancies.

The Occupational Safety System is based on a redundant safety PLC configuration. Each redundant CPU contains the same occupational safety logics and the redundancy is for availability purposes. In the case of failure of one of the redundant PLCs, the other one continues to assure safety with the same safety level. In this case, the network consists of two redundant fieldbus connections. Each channel connects the redundant PLC to the RIO stations using a daisy chain approach.

The SN-PASS connects the access controller with the peripheral devices. The peripheral devices consist of: door lockers, card readers, and door position sensors. The simplest means of communication for this kind of systems is the serial connection based on RS-485 standard in daisychain configuration. This type of connection is widely used by different vendors of Personnel Access Systems, is reliable and cost-effective. If required by the design, the RS-485 can be replaced by Ethernet connection. In this case the SN-PASS network can be available to support the communication of additional services, such as: voice communication, video surveillance.

The SN-RAMSES connects the RAMSES server with the radiation monitoring devices that are deployed in the different areas of the plant. It consists of a serial connection based on RS-485 standard in daisy-chain configura-

tion. This type of connection is generally supported by COTS Radiation Monitoring System.

## CONCLUSION

In the framework of the EUROfusion Work Package ENS, the preliminary design of the DONES CICS was presented here. This step is a fundamental achievement towards the completion of the design of a European DEMO-oriented neutron source whose construction is planned for the early 2020s.

A detailed definition has been given in terms of philosophy, strategy and functionality of the CICS. The different role of CICS and LICS has been also underlined. Main features of the CICS CODAC System have been presented, which can be considered as a consolidated basis for the development of more detailed design. A specific study will be dedicated to the MPS and SCS, due to the need of a homogenization with the safety requirements of the final implementation. Details on the time system and the control system framework will be given in a separate work. For the completion of the design, an improvement will also arrive over the next years including the lessons learned during the system commissioning in similar I&amp;C projects (in particular, from the IFMIF LIPAc facility).

## ACKNOWLEDGMENT

This work has been carried out within the framework of the EUROfusion Consortium and has received funding from the European Union's Horizon 2020 research and innovation programme under grant agreement number 633053. The views and opinions expressed herein do not necessarily reflect those of the European Commission.

## REFERENCES

- [1] D. Stork et al., "Towards a programme of testing and qualification for structural and plasma-facing materials in fusion neutron environments", Nucl. Fusion, vol. 57, 2017.
- [2] G. Federici et al., "DEMO design activity in Europe: Progress and updates", Fus. Eng. Design, vol. 136, pp. 729741, 2018
- [3] The IFMIF/EVEDA Integrated Project Team, "IFMIF Intermediate Engineering Design Report", 2013, available on request at ifmif@ifmif.org.
- [4] A. Ibarra et al., "A stepped approach from IFMIF/EVEDA toward IFMIF", Fusion Sci. Technol., vol. 66, pp. 252259, 2014.
- [5] A. Ibarra et al., "DONES Conceptual Design Report", 2018, available on request to the corresponding author.
- [6] F. Romanelli et al., "Fusion Electricity, A roadmap to the realization of fusion energy", EFDA, 2012,
- [7] T. Donné et al., "European Research Roadmap to the Realisation of Fusion Energy", EUROfusion Consortium, 2018. ISBN 978-3-00-061152-0
- [8] A. Ibarra et al., "The IFMIF-DONES project: preliminary engineering design", Nucl. Fusion, vol. 58, p. 105002, 2018.

- [9] D. Bernardi et al., "Towards the EU fusion-oriented neutron source: The preliminary engineering design of IFMIFDONES", Fus. Eng. Design, vol. 146, Part A, pp. 261-268, 2019.
- [10] M. Cappelli et al., "IFMIF-DONES Central instrumentation and control systems: General overview", Fus. Eng. Design, vol. 146, Part B, pp. 2682-2686, 2019.
- [11] M. Cappelli et al., ENS-3.6.1.1-T13-N1, 2017, available on request to the corresponding author.
- [12] M. Cappelli, ENS-3.6.1.1-T15-11-N1, 2017, available on request to the corresponding author.
- [13] ITER Instrumentation and Control System - PRIMER (ITER\_ID: 32J454 v1.1), 2010.
- [14] W. Davis et al., "Current status of ITER I&amp;C system as integration begins", Fus. Eng. Design, vol. 112, pp. 788795, 2016.
- [15] M. Park et al., "Overview Of KSTAR Integrated Control System", Nucl. Eng. Tech., vol. 40, no. 6, 2008.
- [16] J.G. Krom, "The evolution of control and data acquisition at JET", Fusion Engin. Design, vol. 43, pp. 265-273, 1999.