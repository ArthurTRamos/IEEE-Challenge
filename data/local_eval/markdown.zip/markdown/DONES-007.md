<!-- image -->

WPENS-CPR(18) 21023

Y. Qiu et al.

## Neutronics Analyses of the IFMIF-DONES Test Cell

Preprint of Paper to be submitted for publication in Proceeding of 30th Symposium on Fusion Technology (SOFT)

<!-- image -->

This work has been carried out within the framework of the EUROfusion Consortium and has received funding from the Euratom research and training programme 2014-2018 under grant agreement No 633053. The views and opinions expressed herein do not necessarily reflect those of the European Commission.

This document is intended for publication in the open literature. It is made available on the clear understanding that it may not be further circulated and extracts or references may not be published prior to publication of the original when applicable, or without the consent of the Publications Officer, EUROfusion Programme Management Unit, Culham Science Centre, Abingdon, Oxon, OX14 3DB, UK or e-mail Publications.Officer@euro-fusion.org

Enquiries about Copyright and reproduction should be addressed to the Publications Officer, EUROfusion Programme Management Unit, Culham Science Centre, Abingdon, Oxon, OX14 3DB, UK or e-mail Publications.Officer@euro-fusion.org

The contents of this preprint and all other EUROfusion Preprints, Reports and Conference Papers are available to view online free at http://www.euro-fusionscipub.org. This site has full search facilities and e-mail alert options. In the JET specific papers the diagrams contained within the PDFs on this site are hyperlinked

## Neutronics Analyses of the IFMIF-DONES Test Cell

Yuefeng Qiu a , Frederik Arbeiter a , Ulrich Fischer a , Kuo Tian a

a Karlsruhe Institute of Technology (KIT), Hermann-von-Helmholtz-Platz 1, 76344 Eggenstein-Leopoldshafen, Germany

IFMIF-DONES (International Fusion Material Irradiation Facility- DEMO Oriented NEutron Source) is an accelerator based irradiation facility providing the irradiation data for the needs of the DEMO construction. The Test Cell (TC) is the central room of IFMIF-DONES enclosing the target and the test module. A neutronics analysis on nuclear responses, e.g. heating, radiation damage (displacement per atom, DPA) and helium production, has been performed for the TC. The results on the TC steel liner covering the inner TC surface have been obtained with an unstructured mesh based interpolation approach. The results show that the softening of the neutron spectrum at the thin layer of inner wall increases the nuclear heating as well as the SS316L helium production. The helium production is a major concern when considering the maintenance of the liner. The impact of using different beam footprint size on the TC radiation distribution is small, thus the results calculated using normal footprint of 20 × 5 cm 2 is representative for IFMIF-DONES operating with reduced footprint of 10 × 5 cm 2 .

Keywords: IFMIF-DONES, Test Cell, Neutronics, heating, DPA, helium

## 1. Introduction

IFMIF-DONES (International Fusion Material Irradiation Facility- DEMO Oriented NEutron Source) is an accelerator based irradiation facility developed within the Early Neutron Source project of EUROfusion [1] providing the needs of irradiation data on the structure materials for the DEMO construction. It is a deuteriumlithium neutron source facility, which produces neutron by a 125 mA beam of 40 MeV deuterons striking a liquid Li target, and providing irradiation conditions comparable to those in the first wall of a fusion reactor. The Test Cell (TC, shown in Fig. 1) is the central confinement to envelop the end section of the deuteron accelerator, the target, the test module and the other lithium system components.

The design of the IFMIF-DONES is based on IFMIF/EVEDA (IFMIF Engineering Validation and Engineering Design Activities) with changes of the key parameters and design. Two deuteron accelerators have been reduced to one accelerator, and only the High Flux Test Module (HFTM) has been kept instead of having three (High/Medium/Low flux) test modules. Besides, IFMIF-DONES TC design has been continuously changed since the project started. The HFTM design has been upgraded to enhance the material irradiation capability [1]. In addition, the quench tank has been moved from the below to the inside of the TC by enlarging TC in the vertical direction. These impact strongly on the nuclear distribution inside the TC, thus scaling of the IFMIF/EVEDA results by a factor of 0.5 (half beam power) would not be applicable. Therefore, it is necessary to renew the TC neutronics analysis and provide data for the needs of the TC engineering design.

In this paper provides comprehensive neutron analysis of IFMIF-DONES TC during operation. It is emphasized on the TC concrete wall and steel liner, which provide biological shielding and safety confinement. The nuclear responses, e.g. nuclear heating, radiation damage

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

(quantified in terms of Displacements Per Atom, DPA or dpa), and helium production have been calculated. Also, the impact of the beam footprint size on the TC has been also studied.

Fig. 1 Exploded view of IFMIF-DONES TC reference design

<!-- image -->

## 2. Model and methodology

The TC neutronics model has been continuous updated to follow up the TC design. The model "mdl8.2.0" presented in [2] have been was used for this calculation. The McDeLicious code [3] has been employed for the neutron/photon generation and transport calculation. It is an extension to the LANL Monte Carlo code MCNP [4,5] with the capability to simulate the generation of D-Li source neutrons and photons based on evaluated d + 6,7 Li cross-sections. The neutron transport cross-sections in the Fusion Evaluated Nuclear Data Library (FENDL, version 3.1b)[6] have been used, which is the reference data library for IFMIF-DONES project.

The nuclear responses have been calculated on mesh tally with resolutions of 5 × 5 × 5 cm 3 covering the center region and 1 m-thick of concrete wall. Calculations have been done using the super computer MARCONI hosted at CINECA in Italy. Results are processed using the McMeshTran code [7], and visualized by ParaView overlay with the CAD geometry.

## 3. Results and analyses

Nuclear responses calculated with 10 10 particle histories are shown in Fig. 2, including the nuclear heating, the DPA and the helium production. Two nuclear heating results are presented using different calculation methods. The first result is from a mix-material tally with the materials in one mesh cell being homogenized. The second result is from superimposed heating mesh tally of stainless steel 316L (SS316L) calculated by neutron/photon flux multiply with the heating crosssection. Both heating results are the total heating of neutron and photon. The NRT displacement model was applied to calculate the DPA, and Fe-equivalent value is given. For discussions, the direction is named as follow: (beam) downstream: -X; (beam) upstream: +X, left: -Y, right: +Y, top: +Z, and bottom: -Z.

## 3.1 Nuclear responses for the TC concrete wall

Fig. 2-a shows the nuclear heating distribution. The distribution is asymmetric due to the beam incident angle of 9 ° . The peak heating value of 0.02-0.03 W/cm 3 at the

Horiziotal cut

Vertical cut downstream is not located at the TC inner surface, but ~ 5-10 cm inside the concrete wall. It is noted that, as the neutron flux decrease due to the shielding, the neutron spectrum is also soften. Because iron is the main composition of the heavy concrete (~50 wt%), the softening of spectrum increase the neutron capture reactions, and produces more gamma photon at the thin layer of concrete near the inner surface. Since gamma photon contributes 80-90% of the total nuclear heating, the location of the peak heating value can be therefore explained.

The relative statistical errors of the heating results are &lt;15% for the region with heating &gt; 10 -5 W/cm 3 . An empirical limit [8] is that the concrete region with heating &gt; 10 -5 W/cm 3 muss be actively cooled. On this basis, about 1 m layer of the concrete wall has to be actively cooled, except the downstream wall which requires for more than 1 m. Recent analysis on the TC cooling[9] shows that, the cooling design for the inner 1 m-thick of downstream wall can provide sufficient cooling. The results of Fig. 2-a on the liner is not useful, since the heating produced in the stainless steel liner (8mm in thickness) is homogenized with the void inside a mesh cell of 5 x 5 x 5 cm 3 . The results of the liner are calculated in a different method and will be presented in Section 3.2. The total heating for the HFTM and target assembly (TA) are 16.9 W and 17.3 W, with about 60%- 70% contribution from the gamma photons.

Fig. 2. Nuclear responses calculated for inner TC covering 1 m of concrete wall. The horizontal cut-view is made at the beam level, and the vertical cut-view is made cross the target center.

<!-- image -->

Fig. 2-b presents the nuclear heating only for SS316L used for the quench tank, the lithium pipe, the liner and the support structure of the TA and the HFTM. Nuclear heating is a key source term for the thermal analysis of these inner TC components. Whether they should be actively cooled depends on their structure and cooling conditions. A rough calculation of a 1 cm-thick steel slab inside the TC atmosphere shows that, the nuclear heating should less than 0.15 W/cm 3 in order to keep the temperature lower than 200 ° C. The 0.1 W/cm 3 contour

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

line in Fig. 2-b encloses only the HFTM and the TA where is already actively cooled. Other inner TC steel components receive nuclear heating in the range of 0.010.1 W/cm 3 . The convective and radiation heat transfer also need to be taken into account for the thermal analysis of inner TC components. In Fig. 2-b, a similar plume is observed at the beam downstream, which is also attributed to the softening of neutron spectrum.

The DPA distribution is shown in Fig. 2-c given the value for a full-power-year (fpy, 365 days). Since the DPA is mainly contributed by the high energy neutrons, its value decreases quickly inside the concrete wall. Different from the DPA is the helium production. Fig. 2-d shows the helium production (in appm, atom-part-permillion, or 10 -6 ) from SS316L in one full-power-year. The boron impurity of 18 ppm (part-per-million in weight fraction, 10 -6 ) in the SS316L is the dominant source of producing helium. The cross-section of 10 B(n,t) 4 He reaction increase as the neutron energy decreases, hence helium production increase in the thin layer of concrete. One issue caused by the helium in SS316L is the impact on the re-weldability. So far no re-welding is foreseen for the HFTM, the TA and the QT. However, it could be an issue for liner in defining the maintenance scheme.

## 3.2 Nuclear response for the TC liner

TC liner is an important barrier for the TC in safety concern. It provides confinement of TC atmosphere and the accidental lithium leakage. As the liner is an 8 mm thin layer covering the whole inner TC surface, to obtain the nuclear responses distribution on the liner is not straightforward. In this paper, an unstructured mesh based interpolation approach has been employed with the following steps: firstly, the CAD model of the liner was re-converted from the MCNP geometry using ANSYS Workbench ® . Then, an unstructured mesh for the liner has been generated using the CAD model. At the end, the unstructured mesh is used to interpolate the nuclear responses from those mesh tally results shown in Fig. 2, using a volume-weight interpolation function of the McMeshTran code [7]. The interpolated results are shown in Fig. 3.

(a) Nuclear heating (W/cm 3 )

<!-- image -->

Fig. 3-a shows the nuclear heating distribution of the liner. The peak heating 0.07 W/cm 3 locates at the downstream. The liner is more critical in terms of cooling, since only one side is cooled by the atmosphere, and another side the temperature muss be less than 90 ° C, which is the maximum allowable temperature for the concrete [9]. A rough estimation for the liner indicates that the active cooling should be provided for the area with heating larger than 0.025 W/cm 3 . As shown in Fig .2a, large area of the downstream and side wall liner required cooling. Actually, the entire liner is cooled by water/helium in order to provide a heat sink for the inner TC components [10].

The DPA result is shown in Fig. 3-b. The peak value at the downstream is ~ 0.05 dpa/fpy. Considering the operation of DONES facility for 30 years, the cumulative DPA for the liner is 0.03 - 1.5 dpa, which is not critical. Helium production inside the liner is a concern when considering the re-welding process. The downstream liner has a range of 0.05 - 1 appm/fpy, correspondence of 1.5 - 30 appm in 30 years operation. Depending on the welding technology, limits for re-welding SS316L steel are up to 1 appm helium or even lower [11]. This limit has also been used for the thick SS316L plate in ITER [12]. For directly neutron exposed surfaces of the TC liner at downstream, the re-welding limit is reached within a few years. Nevertheless, re-welding remains possible at shielded locations during the foreseen lifetime, which enables the exchange of downstream part of the liner as a whole in case of damage.

(b) DPA (dpa/fpy)

<!-- image -->

<!-- image -->

(c) Helium production (appm/fpy)

Fig. 3. Nuclear responses calculated on the liner. Position of beam level and HFTM-BP mid-plate is indicated.

## 3.3 Impact of beam footprint size

DONES is possible to use normal beam footprint size of 20 × 5 cm 2 and reduced footprint size of 10 × 5 cm 2 for providing more flexibility in the irradiations. The use of

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

reduced footprint could have strong impact on the nuclear distributions comparing with the normal one. This impact has been studied in this paper. The reference deuteron beam profile (20 × 5 cm 2 ) from the IFMIF/EVEDA phase was used for the calculation in this paper. For the reduced footprint, the same beam profile and beam power (40 MeV and 125 mA) were used but the horizontal dimension is scaled by a factor of 0.5. Calculation setup and variance reduction approaches for calculating the TC global neutron flux has been used as discussed in [2].

The global neutron fluxes are shown in Fig. 4, presenting both results of normal and reduced footprint. It is found that the difference of these two figures is very small. Although the logarithmic legend might conceal difference of a few percent, it has no significant impact on the TC design. Therefore, the results and conclusions obtained using normal footprint are representative for that using reduced footprint. Conclusions are similar for other nuclear responses in the TC, although the results are not present in this paper due to the page limit.

## 4. Conclusions

The neutronics analyses of the IFMIF-DONES TC have been presented in this paper based on the updated design. The nuclear responses, e.g. nuclear heating, DPA, helium production has been calculated on the inner TC. The detail results on the TC liner have been obtained using an unstructured mesh based interpolation method. It is found that the neutron spectrum softening at the thin layer of inner TC wall increases the nuclear heating as well as the SS316L helium production. The helium production is a major concern when considering the rewelding of the liner. The impact on using reduced footprint has been studied. It is concluded that no significant difference is found between the neutron fluxes, thus the results calculated using normal footprint of 20 × 5 cm 2 is valid for IFMIF-DONES operating with reduced footprint of 10 × 5 cm 2 .

(a) 20 × 5 cm 2

<!-- image -->

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- image -->

(b) 10 × 5 cm 2

Fig. 4. Neutron flux (n/cm 2 /s) distribution at the horizontal cut-view using two beam footprint sizes.

## Acknowledgments

This work has been carried out within the framework of the EUROfusion Consortium and has received funding from the Euratom research and training programme 20142018 under grant agreement No 633053 The views and opinions expressed herein do not necessarily reflect those of the European Commission.

## References

- [1] A. Ibarra, F. Arbeiter, D. Bernardi, M. Capelli, A. Garcia et al, The IFMIF-DONES project: Preliminary Engineering Design, to appear in Nuclear Fusion (2018)
- [2] Y. Qiu, U. Fischer, Global flux calculation for IFMIFDONES Test Cell using Advanced Variance Reduction Technique, to appear in Fusion Science and Technology (2018)
- [3] S.P. Simakov, U. Fischer, K. Kondo, P. Pereslavtsev, The McDeLicious Approach for the D-Li Neutron Source Term Modeling in IFMIF Neutronics Calculations., Fusion Science and Technology, 62(2012), 233-39.
- [4] X-5 Monte Carlo Team, MCNP - A General Monte Carlo NParticle Transport Code, LANL, Report LA-UR-03-1987 (2003)
- [5] C.J. Werner(editor), MCNP Users Manual - Code Version 6.2, LANL, Report LA-UR-17-29981 (2017)
- [6] R.A. Forrest et al, FENDL-3 Library - Summary documentation, INDC(NDS)-0628, 2012; https://wwwnds.iaea.org/fendl/index.html
- [7] Y. Qiu, P. Lu, U. Fischer, P. Pereslavtsev, S. Kecskes, A generic data translation scheme for the coupling of highfidelity fusion neutronics and CFD calculations. In Fusion Engineering and Design, 89(2014), 1330-1335. https://doi.org/10.1016/j.fusengdes.2014.02.044
- [8] R. Pampin and M. H. O'Brien, "Analysis of near-term fusion power plant designs from the material management stance", Fusion Engineering and Design, 83 (10-12), pp. 1419-1423, 2008.
- [9] Tian, Kuo, et al. "Overview of the current status of IFMIFDONES test cell biological shielding design." Fusion Engineering and Design (2018).

- [10] Chen, Y., Arbeiter, F., Heinzel, V., Kondo, K., Mittwollen, M., &amp; Tian, K. (2014). Numerical simulations on natural convective heat transfer and active cooling of IFMIF Test Cell. Fusion Engineering and Design, 89(9-10), 22302234. https://doi.org/10.1016/j.fusengdes.2013.12.046
- [11] Y Morishima, M Koshiishi, K Kashiwakura, T Hashimoto, S Kawano, Re-weldability of neutron irradiated Type 304 and 316L stainless steels, In Journal of Nuclear Materials, Volumes 329-333, Part A, 2004, Pages 663-667, ISSN 0022-3115, https://doi.org/10.1016/j.jnucmat.2004.04.094.
- [12] H. Iida, V. Khripunov, L. Petrizzi, G. Federici, and Nuclear Analysis Group, "Nuclear Analysis Report (NAR)," ITER Naka &amp; Garching Joint Work Sites, ITER Internal Report G 73 DDD 2 W 0.2, July 2004.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_