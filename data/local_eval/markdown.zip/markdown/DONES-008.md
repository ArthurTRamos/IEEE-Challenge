<!-- image -->

WPENS-CPR(18) 20050

U Fischer et al.

## Neutronics of the IFMIF-DONES irradiation facility

Preprint of Paper to be submitted for publication in Proceeding of 30th Symposium on Fusion Technology (SOFT)

<!-- image -->

This work has been carried out within the framework of the EUROfusion Consortium and has received funding from the Euratom research and training programme 2014-2018 under grant agreement No 633053. The views and opinions expressed herein do not necessarily reflect those of the European Commission.

This document is intended for publication in the open literature. It is made available on the clear understanding that it may not be further circulated and extracts or references may not be published prior to publication of the original when applicable, or without the consent of the Publications Officer, EUROfusion Programme Management Unit, Culham Science Centre, Abingdon, Oxon, OX14 3DB, UK or e-mail Publications.Officer@euro-fusion.org

Enquiries about Copyright and reproduction should be addressed to the Publications Officer, EUROfusion Programme Management Unit, Culham Science Centre, Abingdon, Oxon, OX14 3DB, UK or e-mail Publications.Officer@euro-fusion.org

The contents of this preprint and all other EUROfusion Preprints, Reports and Conference Papers are available to view online free at http://www.euro-fusionscipub.org. This site has full search facilities and e-mail alert options. In the JET specific papers the diagrams contained within the PDFs on this site are hyperlinked

## Neutronics of the IFMIF-DONES irradiation facility

Ulrich Fischer (*)a , Barbara Bienkowska b , Krzysztof Drozdowicz c , Manuela Frisoni d , Fernando Mota e , Francisco Ogando f , Yuefeng Qiu a , Gediminas Stankunas g , Grzegorz Tracz c

a Karlsruhe Institute of Technology (KIT), Hermann-von-Helmholtz-Platz 1, 76344 Eggenstein-Leopoldshafen, Germany b Institute for Plasma Physics and Laser Microfusion (IPPLM), 23 Hery Str., 01-497 Warsaw, Poland

c Institute of Nuclear Physics - Polish Academy of Sciences (IFJ PAN), ul. Radzikowskiego 152, 31-342 Cracow, Poland d ENEA-Bologna, Via Martiri di Monte Sole, 4, 40129 Bologna - Italy

e CIEMAT, Fusion Technology Division, Avda. Complutense 40, 28040-Madrid, Spain

f Universidad Nacional de Educación a Distancia, C. Juan del Rosal, 12, 28040 Madrid, Spain

g Lithuanian Energy Institute, Laboratory of Nuclear Installation Safety, Breslaujos str, 44403 Kaunas, Lithuania

The methodological approach applied for the nuclear analyses of the IFMIF-DONES facility, developed within the Early Neutron Source (ENS) project of EUROfusion, is presented. It utilizes dedicated tools, developed and adapted to the specific needs and peculiarities of an accelerator based d-Li neutron source. Major elements relate to the simulation of deuteron interactions with the Li target and the accelerator structures, the generation and transport of neutrons and photons, and the production of radio-active nuclides with the subsequent emission and transport of decay gamma radiation. With such an approach, all neutronics data can be provided which are required to design, optimize and evaluate the systems/sub-systems of the facility with regard to their nuclear and shielding performance. This is shown on the example of nuclear analyses conducted for the latest design of IFMIF-DONES.

Keywords: Neutronics, D-Li neutron source, shielding, radiation doses

## 1. Introduction

IFMIF-DONES (International Fusion Material Irradiation Facility - DEMO Oriented NEutron Source) is an accelerator based irradiation facility which is under development within the Early Neutron Source (ENS) project of EUROfusion [1]. The main mission of IFMIFDONES is to provide the irradiation data which are needed for the construction of DEMO, developed by EUROfusion within the Power Plant Physics and Technology (PPPT) programme [2].

The IFMIF-DONES facility consists of a deuteron accelerator, a liquid lithium target and a Test Cell with irradiation test modules as main systems. Neutronics has to provide the data which are required to design and optimize these systems, evaluate and prove their nuclear performance, and ensure a sufficient radiation protection. A variety of neutronics simulations is thus needed to compute the nuclear responses for all systems/components and provide the radiation fields during beam-on and beam-off periods. Such simulations require dedicated computational tools adapted to the needs and peculiarities of IFMIF-DONES.

This paper provides an overview of the IFMIFDONES neutronics conducted in the ENS project. The methodological approach is presented with focus on the specific tools developed for the simulations of the accelerator and the irradiation test systems. The current state of the nuclear analyses is reported including latest results obtained for the assessment and optimization of accelerator, target and test system/components.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

* Corresponding author. Tel: +49 721 608 23407; Fax: +49 721 608 23718. E-mail address: ulrich.fischer@kit.edu (U. Fischer)

## 2. IFMIF-DONES main features

In the IFMIF-DONES facility (Fig. 1), high energy neutrons (up to 55 MeV neutron energy) are produced by a 125 mA beam of 40 MeV deuterons striking a liquid Li target. The deuterons are accelerated and bunched through a sequence of radiofrequency accelerator units and transport systems. The beam hits the Li target within a footprint area of up to 200 mm x 50 mm. The resulting 6,7 Li(d,xn) reactions produce neutrons at a rate of 5.510 16 n/s in the target. With the resulting neutron flux of up to  510 14 cm -2 s -1 , the High Flux Test Module (HFTM), housing the material specimens in specific irradiation capsules, will be irradiated to damage levels as anticipated for DEMO in the first wall.

Fig.1: Cut-away CAD model of the DONES facility with accelerator vault, Target and Test Cell, and surrounding rooms.

<!-- image -->

The HFTM, with dimensions of about 10 cm depth in beam direction, 45 cm lateral extension and 49 cm height, is placed in the Test Cell (TC) next to the target

(Fig. 2) The TC further houses the Li target with inlet and outlet loop and the quench tank. The remainder of the TC, with inner dimensions of 4m x 4m x 2.8 m is empty. The TC walls, made of heavy concrete, up to 4 m thick, serve as biological shield, designed to reduce the radiation to a level to allow man access to the neighbouring rooms during operation.

Fig.2: Cut-away CAD model of DONES Target and Test System.

<!-- image -->

## 3 Computational Approaches and Tools for ENS Neutronics Analyses

## 3.1 Required neutronics analyses

Neutronics analyses are required at all development stages for the lay-out and optimisation of the IFMIFDONES plant with all its systems including the Target Facility (TF) with Li loop, the TC with the Irradiation Test Modules (ITM), and the Accelerator Facilities (AF). This concerns first the nuclear performance of the HFTM with regard to the radiation damage relevant nuclear responses, the nuclear power and the neutron fluence, and, second, shielding issues affecting the layout of the TC and the AF with the adjacent rooms.

For safety assessments and the development of maintenance strategies, the activation of components in the TC, the Target, the Li loop, and the AF is required. Radiation dose fields (biological dose rates) need to be assessed for operation periods ("beam-on") throughout the facility building as well as during maintenance ("beam-off") periods in the TC, the Access Cell (AC) and the AF. For waste assessments and categorization, decommissioning and related analyses, the activity inventories, the decay heat and resulting radiation loads are required at all stages in the process.

The provision of the required data necessitates the availability of dedicated computational tools to model the plant with the relevant components/systems in sufficient detail, simulate the transport of deuterons, neutrons and photons in the AF, the Li target and the TC cell down to the neigbouring rooms, assess the activation of all materials/components subjected to the radiation and predict the resulting radiation dose fields. Suitable computational tools, based on the Monte Carlo transport technique and the coupling to nuclide inventory calculations, were developed to this end and are presented in the following.

## 3.2 Deuteron transport: MCUNED code

MCUNED [3] is as an extension to the MCNPX Monte Carlo code [4] with the capability of handling charged particle transport, in particular light ions such as deuterons, based on cross-section data provided on nuclear data files such as TENDL [5]. MCUNED also includes a dedicated variance reduction technique for the production of secondary particles which drastically reduces the computation time. MCUNED has been extensively benchmarked and applied for design analyses of the IFMIF accelerator and is the standard code for such applications in the ENS project. The MCUNED patch to MCNPX is available from the NEA Data Bank, Paris [6].

## 3.3 Neutron generation and transport: McDeLicious

McDeLicious [7] is an extension to the LANL Monte Carlo code MCNP [8, 9] with the capability to simulate the generation of (d, Li) source neutrons (and photons) based on the use of evaluated d + 6,7 Li cross-sections. McDeLicious has been thoroughly benchmarked and validated against thin and thick Li target neutron yield measurements. It can handle deuteron beam profiles described with an analytical representation and adjustable parameters, or by sampling from 2D tabular distributions as provided e. g. by beam dynamics simulations. The code is available in two versions, McDeLicious-11 and -17, compatible with MCNP versions 5 and 6, respectively, and it is the standard for IFMIF-DONES TTC neutronics calculations.

## 3.4 CAD to MC geometry conversion: McCad tool

McCad [10] is a software tool developed by KIT to enable the automatic conversion of CAD models into the semi-algebraic geometry representation as utilized in Monte Carlo particle transport simulations with MCNP/ McDeLicious. McCad is open source software, freely available at https:/github.com/inr-kit. It runs under Linux and Windows as implementation to the SALOME simulation platform [11]. Additional tools allow to process high resolution mesh tally data and visualize them on the CAD geometry. McCad is the main tool for generating the TTC simulation model of IFMIF-DONES starting from engineering CAD models.

## 3.5 Coupled transport and activation: FISPACT, ACAB and R2Smesh/R2SUNED

The nuclide inventory codes FISPACT [12], developed by CCFE, and ACAB [13], developed by UNED, are used for the activation calculations of the IFMIF-DONES TTC and the AF, respectively. To this end the codes are coupled with MCNP/McDeLicious or MCUNED thus enabling the calculation of the activity inventories in all components/materials under irradiation by neutrons and deuterons. The further extended coupling schemes R2Smesh [14] and R2SUNED [15], based on the "Rigorous 2-Step" approach [16], have the capability to simulate in sequential calculation steps both the material activation during operation and the decay photon transport after irradiation. They are used to provide 3D shut-down dose rate (SDR) distributions in the IFMIF-DONES facility.

## 3.7 Nuclear cross-section data

The Fusion Evaluated Nuclear Data Library (FENDL) [17], with the current version 3.1d, is the reference data library for IFMIF-DONES. FENDL is provided by the IAEA, Vienna, to satisfy the needs both for fusion technology and IFMIF-type applications. Thus the libraries cover the energy range above 20 MeV neutron energy. The FENDL-3.0/A neutron activation data library, identical to the European Activation File EAF-2010 [18], is the current reference for activation calculations. An advanced activation data library, based on TENDL-2017, is currently prepared within the PPPT programme [19].

For deuteron cross-section data, the TENDL data library is the reference. TENDL-2015 is the version mainly in use with MCUNED for deuteron transport simulations and with ACAB for activation calculations. (A specific ad-hoc data library based on TENDL-2015 can be actually used with MCUNED for representing the deuteron break-up process directly in the deuteron transport simulation. With this approach a much better agreement with experimental data has been obtained). The more recent TENDL-2017 deuteron data library is currently under investigation for use with MCUNED.

For displacement damage calculations of the Eurofer and SS-316 steels, dedicated dpa cross-section data were prepared [20]. These data serve as reference for DEMO and IFMIF-DONES in the PPPT programme. For individual elements, the recent JEFF-3.3 dpa crosssection sub-library [21] is the recommended reference.

## 3.8 Methodology for AF and TTC nuclear analyses

MC simulation models are developed for the AF and the TTC nuclear analyses based on the reference IFMIFDONES CAD model. Processing of the CAD model is performed with the SpaceClaim ® software, some manual corrections, and conversion into a MC model, see Fig. 3 and 4 for the AF and the TTC model, respectively

AF nuclear analyses: Deuteron transport simulations are performed with MCUNED to assess the interactions with materials facing the deuteron beam (beam guides, collimators, scrapers, beam dump, etc.), and providing the (prompt) neutron and photon sources, and the activation products (decay gamma source). The prompt radiation sources are used in subsequent MCNP calculations for assessing the dose rate distributions during operation ("beam-on" radiation maps). In these calculations, neutrons back-streaming from the Li target into the beam guides are taken into account through a simplified McDeLicious approach. Deuteron and neutron induced activation is calculated with ACAB using the fluxes provided by MCUNED at the relevant locations of the accelerator system. SDR distributions are calculated separately for neutron and deuteron induced activation reactions. For the first ones, the R2S-UNED code is applied with the neutron flux spectra provided by preceding MCUNED and McDeLicious calculations. For the latter ones, the decay gamma sources, generated with ACAB for specific components and materials, are used as input for MCNP simulations of the decay gammas.

Fig. 3: MCNP model of the AF (2d horizontal cut at accelerator level)

<!-- image -->

TTC nuclear analyses: Neutron and photon transport simulations are performed with McDeLicious using the d-Li neutron source developed for IFMIF-DONES, and the TTC model with all components/systems and neighbouring rooms. Such calculations provide the flux distributions in the Target, the TC with all test systems, the Li loop components and the TC surrounding. The nuclear responses, required for the layout of the components, in particular the nuclear heating, damage and gas production, are also provided with such calculations, as well as radiation dose rate distributions during beam-on operation. Dedicated variance reduction techniques are applied to provide the distributions across the TC walls into the neighbouring rooms. The activation of materials/components in the TTC area is calculated with FISPACT coupled to McDeLicious. The R2Smesh approach is used for calculating the SDR distributions due to the neutron induced activations. Shielding analyses of activated components, in particular the activated HFTM, are also performed on such a basis.

Fig. 4: MCNP model of DONES TTC (2d vertical cut)

<!-- image -->

## 4. Overview of major nuclear analyses results 4.1 AF shielding analyses

Following the approach outlined above, shielding analyses were performed for the AF to assess the radiation dose field during operation due to neutrons generated by (d,xn) reactions and neutrons backscattered from the target. The resulting radiation fields during operation are dominated by the neutron radiation and are highest in the Target Interface Room (TIR), the Radiation Isolation Room (RIR) and the Beam Transport Room (BTR), see Fig. 5 for a map of the biological dose rate distribution. Dose rate levels of up to  10 Sv/h can be reached inside these rooms which are classified as prohibited ("red zone") areas.

Outside the accelerator rooms (vault, BTR, RIR, TIR) the dose rate level is less than  1 to 2Sv/h, thus allowing work personnel access during operation of the accelerator ("blue zone" according to the radiological classification scheme).

Fig. 5: Biological dose rate distribution in AF rooms at accelerator level during operation (labels to be added:).

<!-- image -->

Local shields were proposed and analysed for the RIR collimator and the beam guide in the TIR. With such measures the thickness of the concrete walls can be significantly reduced. Fig. 6 shows the dose rate distribution across the TIR with 1.2 to 1.5 m thick concrete walls and a local shield consisting of a 50 cm thick polyethylene layer surrounded by a 10 cm iron layer. As a result, the concrete walls can be reduced to thicknesses of 50 - 60 cm.

Fig. 6: Biological dose rate distribution in the TIR with (right) and without (left) local shield around beam guide.

<!-- image -->

As result of the activation during operation, there will be a significant radiation level inside the accelerator rooms during beam-off periods. The resulting biological dose rates are in the range up to 2000 Sv/h after 1 day, see Figs. 7 and 8. Thus no access is allowed after short waiting times, instead remote maintenance is required.

Fig. 7: SDR distribution in AF rooms due to deuteron activation of accelerator materials, 1day after shut-down.

<!-- image -->

Fig. 8: SDR distribution in AF rooms due to neutron activation of accelerator materials, 1day after shut-down.

<!-- image -->

## 4.2 HFTM design optimisation analyses

A variety of design analyses has been conducted on the optimisation of the HFTM lay-out for IFMIFDONES ranging from previous parametric studies [22, 23] to the recent analyses on the new reference design with four rows and eight compartments into which the irradiation capsules with the specimen stacks are inserted [24]. The analyses include beam foot print variations from the nominal area 20 cm (horizontal) x 5 cm (vertical) to a reduced one of 10 cm x 5 cm. Fig. 9 shows the DPA rate distribution for the considered two cases. It is noted that higher dpa rates can be achieved with the reduced beam footprint area at the expense of the available irradiation volume.

Fig. 9: DPA rate (dpa/fpy) distribution across the HFTM for beam footprints of 20cm x 5 cm and 10 cm x 5 cm (horizontal cut, left; vertical cut, right).

<!-- image -->

A genetic algorithm was applied to further optimize the deuteron beam profile for a maximum displacement damage volume in the HFTM [22]. The analyses showed that the irradiation volume can be significantly increased for damage rates larger than 10 dpa/fpy with a beam profile showing a central peak, while for damage rates 10 to 20 dpa/fpy the optimized shape is similar to the reference profile with two lateral peaks and a central one. These results indicate enhanced flexibilities in shaping the deuteron beam for an optimal nuclear performance of the HFTM during operation.

## 4.3 TTC shielding analyses

A variety of analyses, based on McDeLicious neutron/photon transport calculations, was performed for the IFMIF-DONES TTC to assess the radiation level inside the TC including the loads to the TC liner, and to evaluate and optimise the shielding performance of the TC concrete walls, serving as biological shield. Fig. 10 shows typical neutron/photon flux distributions in the TTC around the HFTM.

Fig. 10: Spatial distributions of the neutron (left) and photon (right) flux density in the HFTM and the TTC.

<!-- image -->

For transporting the particles through the thick TTC concrete walls, suitable variance reduction techniques need to be applied. These include an ad-hoc improved approach utilizing the ADVANTG code [26] for the generation weight windows meshes which can be used with McDeLicious [27]. Fig. 11 and 12 show distributions of the neutron and the biological dose rate, respectively, calculated with this approach for the TTC and the surrounding.

Fig. 11: Neutron flux distribution in and around the TTC (left: horizontal cut, right: vertical cut).

<!-- image -->

Fig. 12: Neutron dose rate [Sv/h] distribution around the TC during operation (left: horizontal cut, right: vertical cut). The applied color map corresponds to the radiological classification scheme adopted for IFMIF-DONES, based on the EC council directive 2013/59/EURATOM and an exposure time of 2000h/year. (White: &lt; 0.5 Sv/h, unrestricted; blue: &lt; 3 Sv/h, supervised; Controlled areas: green: &lt; 10Sv/h, free permanence, yellow: &lt; 1 mSv/h, limited permanence, orange: &lt; 100 mSv/h, specially regulated, and &gt; 100 mSv/h, red, prohibited).

<!-- image -->

Such analyses have shown that the lateral TC walls, made of heavy concrete, can be reduced to a thickness of 300 cm for keeping the adjacent rooms in the green radiation zone, thus allowing personnel access during operation. The thickness of the concrete wall downstream the TC has to be kept at 400 cm, the floor and the ceiling at 200 cm and 250 cm, respectively. The radiation level in the AC above the TC was shown to be low enough to allow man access during operation. This is due to the design of the Pipe and Cabling Plug (PCP) with dog-leg type steps reducing the radiation streaming through the pipes very efficiently.

## 4.4 Activation of TTC components/systems and resulting radiation loads

A series of coupled radiation transport and activation calculations has been performed to assess the activity inventories of the Target Assembly, the Li loop, the HFTM, TC liner, the TC concrete walls and the water coolant. This is important to assess the potential radiation loads during maintenance at locations where personnel access is considered. Such areas include e. g. the Lithium Loop Cell (LLC) below the TC or the AC

above the TC when activated components such as the HFTM are placed there.

In the LLC, the decay gamma dose rate is below 0.5 Sv/h one day after shut-down radiation (with no activated corrosion products considered). The radiation dose is dominated by the decay gammas from the activated TC liner streaming through the Li outlet pipe into the LLC. Higher dose rate levels have to be expected after draining of the Li and the removal of the polyethylene shield assumed around the Test cell - Li Interface Cell (TLIC). The effect of activated corrosion products, Li reaction products ( 7 Be), and impurities on the radiation dose loads during maintenance was estimated with very conservative assumptions resulting in quite high gamma radiation dose rates. The application of local shields, such as 8 cm Pb layers around the heat exchanger, are required to keep the dose rates below the green zone level of 10 Sv/h.

For assessing the radiation loads during maintenance of the activated HFTM in the AC, an irradiation simulation was first performed for the HFTM in the TC. The activated HFTM was then moved to the AC. The subsequent decay gamma transport simulation, utilizing the decay gamma source distribution generated with the R2Smesh approach, provided the resulting dose rate distribution across the AC. The AC walls, made of 100 cm ordinary concrete, are designed to reduce the radiation penetrating to the adjacent rooms below the blue zone limit. Fig. 13 shows the calculated SDR distributions for the AC cell in two cuts. Further analyses are underway to assess the shielding requirements for the HFTM and other activated TTC components during maintenance in the AC.

Fig. 13: SDR distributions in the AC with activated HFTM, 5 hours after irradiation (left: horizontal cut, right: vertical cut).

<!-- image -->

## 5. Conclusions

The methodological approach applied for the nuclear analyses of the IFMIF-DONES irradiation facility has been presented. It utilizes dedicated tools, developed and adapted to the specific needs and peculiarities of an accelerator based d-Li neutron source. Major elements relate to the simulation of deuteron interactions with the lithium target and the accelerator structures, the generation and transport of neutrons and photons, and the production of radio-active nuclides with the subsequent emission and transport of decay gamma radiation. With such an approach, all neutronics data can be provided which are required to design, optimize and evaluate the systems/sub-systems of the facility with regard to their nuclear and shielding performance. This includes, among others, nuclear responses and radiation fields for the accelerator, the Li target and loop, and the test cell with the irradiation test system and its surrounding, both during operation ("beam-on") and post irradiation ("beam-off"). The suitability of the approach was shown on the example of nuclear analyses conducted for the latest design of IFMIF-DONES.

## Acknowledgement

This work has been carried out within the framework of the EUROfusion Consortium and has received funding from the Euratom research and training programme 2014-2018 under grant agreement No 633053. The views and opinions expressed herein do not necessarily reflect those of the European Commission.

The work contributed by IFJ PAN, Cracow, has been partly sponsored by the Polish Ministry of Science and Higher Education. Support was also provided by computing resources of ACC Cyfronet AGH in Cracow, Poland.

## References

- [1] A. Ibarra, F. Arbeiter, D. Bernardi, M. Capelli, A. Garcia et al, The IFMIF-DONES project: Preliminary Engineering Design, to appear in Nuclear Fusion (2018)
- [2] G. Federici, C. Bachmann, L. Barucca, W. Biel, L. Boccaccini et al, DEMO design activity in Europe: Progress and updates, Fus. Eng. Des. (2018), doi:10.1016/j.fusengdes.2018.04.001
- [3] P. Sauvan, J.Sanz, F.Ogando, New capabilities for Monte Carlo simulation of deuteron transport and secondary products generation, Nuclear Instruments and Methods in Physics Research A, Vol. 614 (2010), 323-330.
- [4] J.S. Hendricks et al., MCNPX 2.6.0 Extensions, LANL, Report LA-UR-08-2216 (2008).
- [5] D. Rochman, A.J. Koning, J.Ch. Sublet, M. Fleming, et al, The TENDL library: hope, reality and future, EPJ Web of Conferences 146, 02006 (2017), doi.org/10.1051/epjconf/201714602006
- [6] P. Sauvan, J. Sanz, F. Ogando, MCUNED - MCNPX Extension for Using light Ion Evaluated Nuclear Data library, NEA Data Bank, Paris, NEA-1859/1 (2013).
- [7] S.P. Simakov, U. Fischer, K. Kondo, P. Pereslavtsev, The McDeLicious Approach for the D-Li Neutron Source Term Modeling in IFMIF Neutronics Calculations., Fusion Science and Technology, 62(2012), 233-39.
- [8] X-5 Monte Carlo Team, MCNP - A General Monte Carlo N-Particle Transport Code, LANL, Report LA-UR-031987 (2003)
- [9] C.J. Werner(editor), MCNP Users Manual - Code Version 6.2, LANL, Report LA-UR-17-29981 (2017)
- [10] L. Lu, Y. Qiu, U. Fischer, Improved solid decomposition algorithms for the CAD-to-MC conversion tool McCad, Fus. Eng. Des. 124 (2017),1269-1272.
- [11] [http://www.salome-platform.org.](http://www.salome-platform.org/)
- [12] R.A. Forrest, FISPACT 2007: User Manual, UKAEA FUS 534, 2007, and J.-Ch. Sublet et al, The FISPACT-II User Manual, CCFE-R(11) 11 Issue 7, 2015
- [13] J. Sanz, O. Cabellos, N. Garcia-Herranz, "ACAB Inventory code for nuclear applications: User's manual V. 2008", NEA-1839/02 (2011)
- [14] P. Pereslavtsev et al, , Novel approach for efficient mesh based MC shutdown dose rate calculations and related V&amp;V analyses, Fus. Eng. and Des. 88 (2013), 2719-2722.
- [15] P. Sauvan et al, Development of the R2SUNED Code System for Shutdown Dose Rate Calculations, IEEE Transactions of Nuclear Science 63 (2016), 375-384
- [16] Y. Chen, U. Fischer, MCNP Based Shutdown Dose Rate Calculations: Computational Scheme, Verification and Applications, Fus. Eng. Des. 63-64, 107-114 (2002).
- [17] R.A. Forrest et al, FENDL-3 Library - Summary documentation, INDC(NDS)-0628, 2012; FENDL-3.1d is available at https://www-nds.iaea.org/fendl/index.html
- [18] J.-Ch. Sublet et al, The European Activation File: EAF2010 neutron cross section library, CCFE-R(10)05, 2010.
- [19] U. Fischer et al, The role of nuclear data for fusion nuclear technology, Fusion Engineering and Design (2018), doi.org/10.1016/j.fusengdes.2018.01.036
- [20] A. Konobeyev, U. Fischer, P. Pereslavtsev, Evaluation of advanced displacement cross-sections for EUROFER constituents, Kerntechnik, 80 (2015), 7-12; data available at https://www-nds.iaea.org/public/download-endf/DXS/
- [21] JEFF-3.3, NEA Data Bank, dpa data sub-library: http://www.oecd-nea.org/dbdata/jeff/jeff33/#dpa
- [22] F. Mota, Á. Ibarra, Á. García, J Molla, Sensitivity of IFMIF-DONES irradiation characteristics to different design parameters, Nuclear Fusion 55 (2015),123024
- [23] F. Mota, J. Molla, Neutronic study of extended DONES irradiation module, Fusion Engineering and Design 109111 (2016), 1212-1216
- [24] Y. Qiu, F. Arbeiter, U. Fischer, F. Schwab, IFMIFDONES HFTM neutronics modelling and nuclear response analyses, Nucl. Materials and Energy 15 (2018), 185-189.
- [25] Y. Qiu, Y F. Arbeiter, U. Fischer, C. Oliver, Optimization of the beam profile for IFMIF-DONES, 18th Int. Conf. on Fusion Reactor Materials, Aomori, Japan, Nov. 5-10, 2017
- [26] S. W. Mosher et al; ADVANTG - An Automated Variance Reduction Parameter Generator, ORNL/TM 2013/416 Rev. 1, Oak Ridge National Laboratory (2015).
- [27] Y. Qiu, U. Fischer, Global flux calculation for IFMIFDONES Test Cell using Advanced Variance Reduction Technique, to appear in Fusion Science and Technology (2018)