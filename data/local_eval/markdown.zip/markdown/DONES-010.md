<!-- image -->

WPENS-CPR(18) 20307

S Coloma et al.

## Methodology for Remote Handling Operations in IFMIF-DONES

Preprint of Paper to be submitted for publication in Proceeding of 30th Symposium on Fusion Technology (SOFT)

<!-- image -->

This work has been carried out within the framework of the EUROfusion Consortium and has received funding from the Euratom research and training programme 2014-2018 under grant agreement No 633053. The views and opinions expressed herein do not necessarily reflect those of the European Commission.

This document is intended for publication in the open literature. It is made available on the clear understanding that it may not be further circulated and extracts or references may not be published prior to publication of the original when applicable, or without the consent of the Publications Officer, EUROfusion Programme Management Unit, Culham Science Centre, Abingdon, Oxon, OX14 3DB, UK or e-mail Publications.Officer@euro-fusion.org

Enquiries about Copyright and reproduction should be addressed to the Publications Officer, EUROfusion Programme Management Unit, Culham Science Centre, Abingdon, Oxon, OX14 3DB, UK or e-mail Publications.Officer@euro-fusion.org

The contents of this preprint and all other EUROfusion Preprints, Reports and Conference Papers are available to view online free at http://www.euro-fusionscipub.org. This site has full search facilities and e-mail alert options. In the JET specific papers the diagrams contained within the PDFs on this site are hyperlinked

## New Methodology to Improve Execution, Efficiency and Safety in Remote Maintenance Tasks

Sofia Coloma a , Manuel Ferre a , José M. Cogollor a , Gioacchino Miccichè b

a Universidad Politécnica de Madrid, CAR UPM-CSIC, Madrid, Spain b ENEA C. R. Brasimone, 40032 Camugnano, Bologna, Italy

Remote Handling (RH) operations in hazardous environments are challenging tasks and have to be carried out with the safety measures required. Moreover, systems and components located at remote environments must be designed to properly comply with remote operation constraints. This approach has led to a process of improvement and efficiency, which reduces time and operational costs. Over time, guidelines and methodologies have been developed focusing on design, operation and dismantling. Nonetheless, these concepts do not cover all the necessary aspects for the implementation and execution of remote handling.

In this article, a proposal for a new methodology is presented with the aim to improve execution, efficiency and security of remote tasks. The methodology, which is composed of a set of different rules, is based on the initial cooperation among different teams involved in the remote operation cycle. This approach leads to an iterative process that allows optimization, design and improvement. The result has led to the acceleration of the process with a more robust concept of maintenance, simplification of procedures, reduced breakdowns and less cost and time.

Keywords: Remote handling, Maintenance, Inspection, Radiation, Methodology

## 1. Introduction

Telerobotics is one of the oldest fields in robotics, which have been included in our day-to-day lives during the last 50 years. The use of telerobotics is essential in those cases when the interaction between the user and the environment becomes risky, dangerous or not fit to be performed by a human being. That is why, many applications of this technology can be found in nuclear or radiation environments [1] as well as space [2], defense [3] and underwater [4].

Radiation environments is one of the most important fields of RH applications [5, 6, 7, 8], since it is necessary to guarantee the safety of the operators and the nuclear plant taking into account ALARA protection principle. That is how RH tasks such as maintenance, disassembly and diagnosis in radiation environments have to be carried out remotely by implementing RH systems with very complex and advanced architectures, and high technology to withstand harsh environment. Being that way, the definition, development and implementation of all process of remote interventions in such environments have to be paid with special attention due to their high level of difficulty. For this reason, it has been necessary to develop and implement some guidelines for telerobotic interventions to be followed by the different teams involved. It will be able to deeply cover different areas such as electrical and electronic engineering, control, software development, hydraulics, welding and cutting, ergonomics and mechanical design [9].

The aim of this paper is to present an overview of a new methodology that acts as a guide to ensuring and improving remote operation in harsh environments such as radioactive areas. In detail: Section 2 highlights the importance of designing and implementing a methodology for RH maintenance. Section 3 presents the methodology

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

as well as the main objectives, rules, recommendations, models and examples. Finally, in the Section 4 a summary of general conclusion is provided.

## 2. The importance of RH in hazardous environments

Telerobotics allows solving and simplifying problems or difficulties for humans. RH technology becomes advantageous since it avoids or reduces the presence of humans to execute certain tasks at complicated or undesired environments and moreover, it increases human skills in some circumstances. For example, some of these situations correspond to:

- Manipulation of radioactive components, substances or waste.
- Restricted or forbidden access in the working area.
- Contaminated environment.
- Extreme conditions for humans compared to other industry areas such as the temperature, radiation, vacuum and pressure.

In this manner, the use of robots instead of humans is justified from a safety and comfortable point of view. Nevertheless, the use of RH technology implies engineering challenges in most cases and requires special attention during the definition, development and implementation of the entire remote operation process with the purpose of achieving successful results. However, there is no standard guidelines that define all the steps and procedures needed to perform the entire operation process from beginning to end. For this reason, a set of procedures and information needed before, during and after the execution of a real remote operation is proposed in this article. The goals of the remote operation guide are:

- To guarantee the success of remote interventions.
- To encourage the communication among different users involved in the task.
- To define and describe the purpose in each procedure so as to complete the sequence correctly.
- To avoid redundant information, loss of information and misunderstandings.
- To streamline the process of definition, development and implementation.
- To generate documentation of all the information.

The guide presented in the following section aims to establish a set of iterative procedures that encourage communication among all teams involved in the remote task to be carried out. The guide contains ten steps to be considered for the correct execution of the remote operation. The following topics to be taken into account before the real remote operation is carried out are: description of the operation, specifications, procedures, required equipment, simulation and training. These procedures allow checking whether the execution of the task has been correctly executed or a subsequent step has to be done again in order to improve the process. Finally, once the remote intervention is done, dismantling the equipment, operation analysis and tune-up of the equipment could be required for future operations.

Fig. 1. A new methodology for the efficient execution of remote tasks.

<!-- image -->

## 3. Definition and structure of the methodology

The present guidelines determine a course of robotic interventions, along with a set of steps, which include recommendations to properly complete each phase.

These steps are related to different aspects of telerobotics interventions such as the definition of specifications and requirements, mechanics, design, manipulation analysis, control, integration, simulation, validation and evaluation. The mentioned steps are presented in Figure 1. The first six steps are focused on preparing and guaranteeing the success of the task with a feedback of information. Steps 7 is related to RH execution and the steps 8 to 10 explain the process needed after the RH operation.

On the other hand, communication among different teams (designers, engineers, operators, …) is vital since otherwise, development time could be jeopardized due to misunderstandings. Besides, the information should be provided to the rest of the members and has to be available throughout the entire processes. Along the next subsections, each step will be explained in detail.

## 3.1 Step1: operation description

Firstly, the future remote operation must be notified and preliminary described by the responsible personnel. The description of the remote operation has to be defined by including, at least, the following information: (a) title, (b) description of the task, (c) location, (d) responsible staff and (e) dates/time.

It allows an initial analysis of the requirements of the operation and determines its feasibility via RH. In case it could be performed accordingly, step 2 requires more specific information for the robotic team to develop and implement the operation.

## 3.2 Step 2: specification of the intervention

The requirements and specific information regarding the component(s) and work area must be defined in this step. For each component, it is necessary to indicate and provide the information cited in Table 1, which shows the information related to the components, area, design, mechanical specifications, environment data, responsible team and maintenance time. Depending on this information and other factors such as the availability of equipment, area and staff. It is possible to determine if the operation will be carried out.

Table 1. Example specifications of the RH intervention.

| Work Area  Component  Location  Accelerator area Beam Dump  Description  Part of the  accelerator  Absorb energy  Subcomponent  -  Cartridge and  Shields  Interface  -  Hole, bolt …  Design  D1.CAD  D2.CAD  Material  -  Steel and water   |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Specification  -  3 ton shield  Dis/assembly  description  -  1. Remove shield  2. Remove  cartridge  Photos  P1.jpg  P2.jpg  Constrains  Radiation  (&lt;1Gy/h)  Heavy Shields  Operation time  10 hours  Responsible  team  Team 1  Team 2   |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

## 3.3 Step 3: procedures of the operation

Based on the information provided, this section specifies the steps and actions, specifications and parameters (i.e.: force, torque) necessary to carry out an intervention. These are defined sequentially in Table 2 for each needed RH operation. The procedure represents a state machine (Figure 2) where all steps of the task and their corresponding conditions and/or status are defined.

Fig. 2. State machine example of procedures defined

<!-- image -->

Table 2. Example of the procedures description.

| Operation 1. Remove bolt  No. Proce-  dure  Specifica-  tion  Other  Param.  Conditions  Pre Post  1.1 Unbolt  -  100  kg m 2 /  s 2  Status  0  Status2  1.2 Trans-  port &amp;  Store  Screw  container  Status  1  Status  s0   |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

Procedures must also take into account those tasks that are required before and after the real intervention, which are cited in subsections 3.7 and 3.9.

## 3.4 Step 4: required equipment and tools

In this stage, the operational devices to perform RH task are described and analyzed. The selection for each device is decided based on the information obtained in previous steps 1, 2 and 3. Table 3 shows the required information for each task.

Table 3. Example of the required devices.

| Task Equipment Tool/  Interfa  ce  Sensor Camera  1.1 Robot Kuka Screw  driver  Force  Yes  1.2 Robot Kuka Grip  Force  Yes   |
|-------------------------------------------------------------------------------------------------------------------------------|

The most relevant factors for selecting equipment are: dimensions of the work area, mechanical interface, level of radiation, access, weight of components, environmental conditions, material contraints, etc.

## 3.5 Step 5: integration and simulation

The simulation allows the use of objects and environments to create immersive and engaging learning experiences both in 2D or 3D. Delmia, gazebo and Unity are examples of graphic computer for simulators. Where all the information provided in previous subsections are integrated and programed in a simulator. It is then possible to observe and previously verify if the specifications, procedures and equipment are compatible. In order to integrate all the information through the simulation, the following steps must be carried out:

1. Check if the information and requirements provided in previous steps are available and correct for the simulation.
2. Integrate the corresponding design models of the area, components, equipment and tools in the simulation (i.e.: Computer Assisted Design (CAD) models into a simulator).
3. Carry out deep analysis of the main topics:
- Integration of the remote equipment and tools.
- Feasibility of maintenance operation.
- Path optimization.
- Risk analysis.
4. Check the complete remote operation in the simulation.

The simulation verifies whether it is ready or it is necessary to go back to a previous step.

## 3.6 Step 6: human operator training

Before the operations are executed in the real scenario, training of the operators with the procedures stablished and the selected equipment and tools has to be carried out. The environment for the training has to be similar to the real scenario using a virtual simulator (i.e: graphic simulator with VR glasses and control robotic panel), a mock-up or simulating the operation in the real environment (if possible).

The training allows the operator to obtain the sufficient skills so as to obtain deeper knowledge about the environment and of the procedures for the implementation of the tasks.

## 3.7 Step 7: execution of RH operation

After successfully passing the training stage, the intervention must be performed at the specified day, time and place by the expert (s) operator (s). For this purpose, different factors such as transportation, preparation and installation of robotic equipment must be taken into consideration before the operator performs the operation remotely.

Once everything is ready, the operator performs the planned RH task until it is successfully completed. However, there are times that unforeseen events happen and some changes may be necessary to be undertaken. In worse case scenarios, the operation may be even required to be aborted.

## 3.8 Step 8: work station dismantling

According to the conditions of the environment, materials and tools used during the operation could be contaminated. If so, once the RH operation intervention is finished, the equipment, tools and components with a subsequent human contact must be analyzed and properly cleaned by the responsible team. Therefore, all non-fixed equipment and tools must be dismantled, packed (once cleaned) and transported to the proper storage area. On the other hand, permanent equipment usually does not need to be dismantled. It requires to be transported to its position in the work area.

## 3.9 Step 9: intervention analysis

When the operation is finished, the overall intervention must be analyzed in order to evaluate possible breakdowns, weak points, and quality of the intervention, results and efficiency.

The team in charge may propose future improvements if necessary because it can determine a better manner on how to proceed in the future RH operations. Tables 1 to 3 are the proper places to insert the decided modifications. These changes will affect to the rest of procedures and simulations.

## 3.10 Step 10: tune-up

The responsible team of equipment and devices should tune up all as soon as possible in order to ensure readiness for future remote interventions (if required). The tune-up may include some modifications, repair and incorporation of new equipment and/or tools. It allows improving RH work system of the robotic team.

## 4 Conclusions

The work presented in this article has shown the importance and the need of applying a methodology to implement the entire process of RH operation in radiated and harsh environments. It considers the impact factors and boundary conditions for this kind of operations.

Handling is usually required to perform dexterity operations such as assembly/disassembly, connection/disconnection, cutting/welding, etc. Many aspects have to be verified in several steps. For this reason, this methodology allows an iterative approach in order to be opened to modifications.

Implementing the proposed methodology aims to define different actions that will be systematically executed in order to ensure correct execution of a real remote task. Current realization of RH maintenance turns out to be faster, more robust, simpler and more efficient in terms of costs and time.

## Acknowledgments

This work has been carried out within the framework of the EUROfusion Consortium and has received funding from the Euratom research and training programme 20142018 under grant agreement No 633053. The views and opinions expressed herein do not necessarily reflect those of the European Commission

## References

- [1] Friconneau, J. P., et al. "ITER hot Cell-Remote handling system maintenance overview." Fusion Engineering and Design (2017).
- [2] Kulakov, Felix, Gennadiy Alferov, and Polina Efimova. "Methods of remote control over space robots." MechanicsSeventh Polyakhov's Reading, 2015 International Conference on. IEEE, 2015.
- [3] Khurshid, Javed, and Hong Bing-Rong. "Military robots-a glimpse from today and tomorrow." Control, Automation, Robotics and Vision Conference, 2004. ICARCV 2004 8th. Vol. 1. IEEE, 2004.
- [4] Lin, Qingping, and Chengi Kuo. "Virtual tele-operation of underwater robots." Robotics and Automation, 1997.
- [5] Dutta, Pramit, Naveen Rastogi, and Krishan Kumar Gotewal. "Virtual reality applications in remote handling development for tokamaks in India." Fusion Engineering and Design 118 (2017): 73-80.
- [6] Shimomura, Y., et al. N"Iter-feat operation." Nuclear Fusion 41.3 (2001): 309.
- [7] Thomas, Justin, et al. "DEMO hot cell and ex-vessel remote handling." Fusion Engineering 8and Design 88.9 (2013): 2123-2127.
- [8] Garin, Pascal, and Masayoshi Sugimoto. "Main baseline of IFMIF/EVEDA project." Fusion Engineering and Design 84.2 (2009): 259-264.
- [9] David, O., Loving, A. B., Palmer, J. D., Ciattaglia, S., &amp; Friconneau, J. P. (2005). Operational experience feedback in JET Remote Handling, Fusion engineering and design