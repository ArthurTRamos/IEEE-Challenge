## CHALLENGES OF TARGET AND IRRADIATION DIAGNOSTICS OF THE IFMIF-DONES FACILITY

C. Torregrosa-Martin∗ , J. Maestre, I. Alvarez, A. Roldan, J. Valenzuela

Universidad de Granada, Granada, Spain

A. Ibarra, S. Becerril, I. Podadera, Consorcio IFMIF-DONES España, Granada, España

F.S. Nitti, ENEA, Brasimone, Italy

S. Fiore, CERN, Geneva, Switzerland

J. Castellanos, Universidad de Castilla la Mancha, Ciudad Real, Spain

C. De la Morena, D. Regidor, F. Mota, D. Jimenez-Rey, C. Oliver, CIEMAT, Madrid, Spain

F. Arbeiter, B. Brenneis, Y. Qiu, KIT, Karlsruhe, Germany

T. Tadic, Ruder Boskovic Institute, Zagreb, Croatia

L. Buligins, Institute of Physics, University of Latvia, Latvia

N. Chauvin, CEA, Saclay, France, U. Wiacek, IFJ PAN, Krakow, Poland

P. Matia-Hernando, J. Martínez, T. Siegel, ASE Optics Europe, Barcelona, Spain

Figure 1: Image showing the arrangement of the Target and Irradiation Modules inside the Test Cell, the Target Interface Room (TIR) upstream, and the Li Loop Cell (underneath).

<!-- image -->

length 40MeV LINAC operating in continuous wave (CW) with a nominal average intensity of 125mA and an output power of 5MW [2]. The Target will consist of a 25mm thick liquid Li curtain, circulating at 15m/s inside the Target Vacuum Chamber (TVC), which is directly connected to the accelerator vacuum chamber. For providing such curtain, a closed loop of liquid Li with a flow of 100 l/s is required. The Target accomplishes a double function; (i) it produces the required neutron field for samples irradiation and (ii) it evacuates the 5MW power deposited by the incident beam via heat exchangers and secondary cooling loops [3, 4].

Figure 1 shows the arrangement of the IFMIF-DONES Target (yellow), and the Irradiation Module, which is placed a few millimeters downstream the Target. The first two types of exchangeable Irradiation Modules foreseen are; (i) the so-called High Flux Test Module (HFTM) and (ii) the StartUp Monitoring Module (STUMM). The STUMM will be

## Abstract

IFMIF-DONES will be a first-class scientific infrastructure consisting of an accelerator-driven neutron source delivering around 1017 n/s with a broad peak at 14MeV. Such neutron flux will be created by impinging a continuous wave 125mA, 40MeV, 5MW deuteron beam onto a liquid Li jet target, circulating at 15m/s. Material specimens subjected to neutron irradiation will be placed a few millimeters downstream. Some of the most challenging technological aspects of the facility are the Diagnostics to monitor the Li jet, beam parameters on target, and characterization of the neutron irradiation field, with transversal implications in the scientific exploitation, machine protection and safety. Multiple solutions are foreseen, considering among others, Li jet thickness measurement methods based on laser measurement and millimeter-wave radar techniques, Li electromagnetic flowmeters, beam footprint measurements based on residual gas excitation, online neutron detectors such as SPNDs and micro-fission chambers, as well as offline neutron fluence measurements by activation foils or spheres. This contribution provides an overview of these aspects and the associated R&amp;D activities.

## INTRODUCTION

The International Fusion Materials Irradiation FacilityDEMO Oriented Neutron Source (IFMIF-DONES) is a scientific infrastructure whose objective is to provide an intense neutron source (in the order of 1017 n/s) for the qualification of materials to be used in future fusion power reactors [1].

IFMIF-DONES will be an accelerator-driven neutron source, where a 40MeV deuteron beam produced by a superconducting LINAC is directed towards a liquid lithium target to produce neutrons by stripping nuclear reactions [1]. The deuteron accelerator consists in a 100m used during the commissioning phases to characterize the generated neutron field, both by active detectors for online measurement and passive detectors for offline means. The HFTMwill house the material samples and specimens for irradiation during the campaigns, which will take one to two years of operation [1]. The specimens shall be kept in a controlled temperature range within 250-550 ∘C [5] while the received neutron flux will be continuously monitored. As shown in the image, both the TVC and HFTM are placed inside a leak-tight bunker, called the Test Cell (TC), which is filled by He at a pressure of about 90 mbar to provide inertization as well as nuclear shielding and confinement [6]. Two vacuum lines connect to the target; (i) the Primary Line, through which the deuteron beam circulates, and (ii) the Secondary Line, which is reserved for an eventual second accelerator (IFMIF updgrade) and it is currently dedicated to a diagnostics port for Target monitoring. These lines cross through the TC concrete shielding from the Target Interface Room (TIR), located upstream. The Li Loop components are placed underneath the TC, in the so-called Lithium Loop Cell (LLC), which will operate in Ar atmosphere to provide inertization and minimize the risk of fires due to air-lithium reaction [3, 4, 7].

∗ cltorregrosa@ugr.es

Strong integration efforts are being made at the current project phase aiming at harmonizing the ongoing diagnostics requirements and designs [8]. This paper provides an overview of the most relevant Diagnostics that are foreseen to monitor the Li liquid Target, beam parameters on Target, and characterization of the neutron irradiation field.

## DIAGNOSTICS OF THE LITHIUM LOOP AND TARGET

## Requirements and Challenges

Figure 2 shows an image of the Li Target and the liquid Li closed loop, whose function is to feed the former with a stable flow of 100 l/s as well as removing the 5MW power deposited by means of heat ex-changers with secondary oil loops. This flow is provided by a permanent magnets electromagnetic pump (EMP) driven by a 160 kW electric motor operating at 480 rpm and situated 10m below the Target, delivering an outlet head pressure up to 6bars. In addition, this pump will be equipped with a flying wheel to provide long coast down times in case of power cutoff. The nominal Li operating temperature will be 300 ∘C (with an averaged increase of 18 ∘C as it passes through the Target and evacuates the 5MW). Around 2 l/s (2% of the main lithium flow) will be continuously deviated from the main loop to the Impurity Control System (ICS), a parallel branch equipped with cold traps (precipitation of low solubility compounds and activated corrosion products) and hydrogen traps (absorption of hydrogen/tritium). The most relevant and challenging requirements of all these systems in terms of Diagnostics are the following:

- Monitoring the Li Target curtain thickness, which has to be within 25 mm with a maximum allowable reduction

Figure 2: Image showing the Li Target inside the TVC, the Li Heat Removal System and the Impurity Control System.

<!-- image -->

margin along the beam direction set only in 1mm. A local reduction above 2mm could induce excessive beam power deposition on the TVC back-plate behind the Li curtain, leading to its rupture.

- Monitoring the beam position on target and its footprint shape, which largest possible size is approximately 50(V) × 200(H) mm with an horizontal extension up to 250mm counting with the tails. The Li jet is 260mm wide, leading to a 5mmmargin at both sides to avoid beam impact onto the Li channel walls.
- Monitoring the vacuum pressure in the TVC, which has to be in the range ∼10-5-10-4 mbar to avoid Li evaporation and high beam loses.
- Monitoring the Li mass flow and pressure in the inlet and outlet ducts of the Li loop towards the target. These diagnostics shall precisely detect minor variations in the Li flow to trigger Safety Interlocks.
- Monitoring the operation of the EMP, including aspects of predictive failure diagnostics.
- Detect the eventual presence of Li leaks in the connecting flanges of the target and along the loops.
- Monitoring the impurity content in the liquid Li loop, especially the oxygen, nitrogen and hydrogen contents which are key for the corrosion and compounds formation.

These diagnostics shall be compliant with the harsh operation conditions present where they will be located, in addition to provide high reliability due to the limited maintenance times and access in some of these areas. In particular:

- Close to the Target Vacuum Chamber (inside the Test Cell): Absorbed doses in the order of 100MGy/fpy (Siequivalent). Only Remote handling access is possible within 15-20 days per year. The target is replaced in a yearly basis.

- At the Target Interface Room (TIR), 8-10 meters upstream the target: Absorbed doses in the order of 1-2MGy/fpy (Si-eq). Only Remote handling access is possible within 15-20 days per year.
- In the Li Loop Cell: Absorbed doses in the order of kilo-greys (Si-equivalent). Rooms operating in Ar atmosphere, hands-on/off access is possible within 15-20 days per year.

## Proposed Solutions

The technical solutions under investigation for accomplishing with the requirements and overcoming the challenges are the following:

MonitoringLi CurtainThickness Theses systemswill be part of the Machine Protection System and trigger a beam interlock shutdown if a &gt;1mm reduction over the 25mm Li jet thickness takes place. Two types of technologies are under investigation.

- Optical metrology measurement: This diagnostic would follow a similar approach as the one proposed of the In-Vessel Viewing System (IVVS) in ITER [9]. It would profit from the diagnostics port in the secondary line from the Target Interface Room to the TVC, from which it is possible to have a direct line of sight to the Li through a mirror and optical fibers [10] (around 8m distance). The most promising solution seems to be Amplitude-modulated Continuous-wave Light Detection and Ranging (AMCW LiDAR), which could provide measurement accuracy in the order of 100 µm using high-frequency modulation of 550MHz [11]. The expected acquisition times are within 1ms per point and &lt;100ms per line. This solution would be compatible with the 1-2MGy/fpy expected at the secondary line diagnostics port, where the mirror and optic fibers will be present. Sensitive electronics would be placed and shielded in another room around 20m away. Experimental campaigns using GaInSn as liquid metal are currently forseen to validate this system.
- LiRADAR (Lithium target RADAR diagnostic): This diagnostic currently under study would be based on mmWave radar techniques pointing towards the Li Target by two antennas inserted in the TVC. These passive antennas could be a compact and resistant solution for the extremely harsh environmental conditions present there (100MGy/fpy). The radar transceiver and the rest of electronic devices could be placed separated from the antennas by means of waveguides [12].

Monitoring Li FlowCharacteristics Different types of instruments are foreseen for this:

- Electromagnetic flowmeters: This is a promising solution for detecting minor variations and instabilities on the Li flow with a fast response time. They would be installed in the inlet/outlet target pipes in the LLC, where radiation levels are significantly lower. The goal is to have some of these flow-meters as Safety-credited

Figure 3: Sketch of the two possible irradiation modules (HFTM/STUMM) to be installed inside the TC.

<!-- image -->

instruments to send a Safety Interlock and stop the beam within a few milliseconds in case of flow instabilities.

- Venturi flowmeters: These are foreseen for redundant Li flow measurement, although considerably longer time responses with respect to EM flowmeters are excepted.
- Pressure transmitters: Installed along the Li loop piping within the LLC to provide additional information on Li flow characteristics and EMP performance.

Monitoring BeamFootprint on Target The solution currently under study is the use of a camera pointing to the jet through an optical path from the TIR diagnostic port. This camera would monitor the beam position and footprint shape by recording the interaction between the beam and the lithium surface. A conceptual proposal already exists and experimental campaigns are foreseen in order to help selecting the best candidate to monitor (d-Ar interaction, d-Li interaction, Optical Transmission Radiation (OTR), etc.) [13].

EMP Diagnostics Several instruments are foreseen to monitor a proper operation of the EMP, such as power control, optical encoders for direct measurement of rotation speed, as well as accelerometers to detect well in advance potential breakdowns.

Monitoring Vacuum in the TVC This is one of the most challenging aspects since the expected radiation of 100 MGy/fpy around the TVC and the lack of vacuum gauges technologies that provide high accuracy measurements within this pressure range make difficult the success of solutions based on cold cathode gauges or pirani. Current approach foresees to indirectly derive the TVC pressure by measuring the vacuum in the TIR sector of the beam line. Other technique under investigation is to use instruments based on Cavity Ring-down Spectroscopy (CRDS) to detect eventual Li evaporation.

Monitoring Li Leaks Li leak detectors based on electric contact are foreseen at the connection flanges of the Li piping, both around the Target and in the LLC. The concept is to use a similar technology as the one employed at SNS neutron source for mercury leaks in ORNL [14].

Monitoring Impurity Due to the low concentrations involved, the baseline scenario considers the characterization of these impurities via offline analysis by periodical extraction of Li samples from the Impurity control loop. Other proposed online methods under consideration include a Resistivity Meter for online N monitoring [15] and a Electro-Chemically based H sensor [16].

## DIAGNOSTICS IN THE IRRADIATION MODULES

## Requirements

Figure 3 shows a sketch of the two main types of Irradiation Modules, the HFTM and the STUMM, foreseen to be installed behind the target, inside the TC. The most relevant and challenging requirements of these systems, in terms of Diagnostics, are the following:

- Monitoring and characterizing the radiation field with high spatial and time resolution: A total expected neutron flux in the order 1017 n/s shall be monitored with a spatial resolution in the order of 10mm and time resolution within 10 µs, while maintaining the neutron field calibration along the irradiation campaigns (1-2 years operation and commissioning).
- Monitoring the irradiation capsule conditions: This is relevant for the HFTM, in which the material samples will be inserted. Irradiation temperatures shall be controlled within 250--550 ∘C. In addition, it is necessary to know accurately the integral radiation to which the specimens have been subjected during the irradiation campaigns.

In addition, these diagnostics shall be compliant with some of the following constraints:

- Radiation levels as high as 104 MGy/fpy behind the target and 30MGy/fpy at the position of the cable connectors.
- Temperatures up to 550 ∘C for the HFTM.
- A surface of only 50×40 cm in the module connection bridge for integrating remote handling connectors for more than 330 different signals.
- Very low current signals (within nanoamperes), long cables to the data acquisition electronics (&gt;20m), and EMC sensibility due to the high density of signal cables.

## Proposed Solutions

Some of the technical solutions under investigation for accomplishing with the requirements and constraints of the HFTM/STUMM diagnostics are the following:

IrradiationFieldsCharacterization The radiationmonitors considered for the HFTM/STUMM are the following:

- Self-Powered Neutron Detectors (SPND): Their use is considered for both the HFTM and STUMM. In

principle, they should be compatible with the high operational temperatures of the HFTM (250--550 ∘C). In addition, one of the main challenges is the low expected signals in the order of nanoamperes, and their low sensitivity for fast neutrons due to limited cross section of the emitter elements. R&amp;D Activities using the GELINA source and CERN's nTOF have been carried out and more will follow [17, 18].

- µFission Chambers (U238/U235) coupled with Ionization Chambers (ICs): This are miniaturized gas ionization chambers coated by U238 or U235 (FCs) proposed to characterize fast and thermal neutron spectrum respectively during the STUMM operation (they are disregarded, at the moment, for the HFTM due their incompatibility with high temperatures). These chambers will be used in combination with ICs of the same geometry to discriminate the electric signal produced by gammas. Irradiation, calibration and validation campaigns with these setups for IFMIFDONES were performed in the BR2 reactor [19, 20]. More irradiation campaigns are foreseen in the context of the prototype STUMM-PROTO, currently under construction in the University of Granada.
- 𝛾-Thermocouples (GTs): Under study in the STUMM from providing the integral energy deposited.
- Activation foils and Rabbit-Activation balls: These offline techniques are under study for the STUMM and HFTM. In the HFTM, activation foils would be included in several parts of the irradiation capsules for providing a most accurate mean of measuring the integral neutron fluence received by the specimens [21]. In the STUMM, the use of activation-balls to be retrieved during operation by a pneumatic rabbit is also under study. These technique would also allow a characterization of the radiation energetic spectrum, which cannot be easily done by FC and IC.

MonitoringHFTM/STUMMTemperatures A temperature control of the irradiation capsules in the range within within 250-550 ∘C is envisaged by means of heaters and type-K thermocouples.

## CONCLUSIONS

This work presents an overview of the most relevant requirements and challenges of the Li Target and Irradiation modules Diagnostics of IFMIF-DONES, as well as some of the proposed solutions under investigation. Some of these diagnostics are currently beyond the state-of-the-art due to the functional needs (high accuracy, acquisition times, reliability) as well as constraints associated to harsh operation environment (radiation, high temperatures, limited maintenance) and integration aspects (EMC, cable routing, space limitation). Extensive R&amp;D programs are ongoing to consolidate the technical solutions including execution of validation campaigns in close collaboration with other facilities.

## ACKNOWLEDGMENTS

This work has been carried out within the framework of the EUROfusion Consortium, funded by the European Union via the Euratom Research and Training Programme (Grant Agreement No. 101052200 - EUROfusion). In addition, it has been financed by the Junta de Andalucia through the project "SE2021 UGR IFMIF-DONES" co-financed by the European Regional Development Fund ERDF "A way to make Europe"/"Andalusia moves with Europe". Views and opinions expressed are however those of the author(s) only and do not necessarily reflect those of the European Union or the European Commission. Neither the European Union nor the European Commission can be held responsible for them. Works have been also funded by DONES-FLUX project (Misiones CDTI MIP-20221017), subsidized by the Spanish Centre for the Development of Industrial Technology, and supported by the Ministry of Science and Innovation under the Recovery, Transformation and Resilience Plan from Next Generation EU funds.

## REFERENCES

- [1] A. Ibarra et al., "The European approach to the fusion-like neutron source: The IFMIF-DONES project," Nucl. Fusion, vol. 59, no. 6, p. 065002, 2019. doi:10.1088/1741-4326/ab0d57
- [2] I. Podadera et al., "The accelerator systemof IFMIF-DONES multi-MW facility," in Proc. IPAC'21, Campinas, SP, Brazil, May 2021, pp. 1910-1913.
3. doi:10.18429/JACoW-IPAC2021-TUPAB211
- [3] P. Arena et al., "The design of the DONES lithium target system," Fusion Eng. Des., vol. 146, pp. 1135-1139, 2019. doi:10.1016/j.fusengdes.2019.02.024
- [4] T. Dézsi, F. Nitti, M. Tóth, S. Pásti, B. Balogh, and A. Ibarra, "Overview of the current status of IFMIF-DONES secondary heat removal system design," Fusion Eng. Des., vol. 146, pp. 430-432, 2019.
6. doi:10.1016/j.fusengdes.2018.12.084
- [5] F. Schwab et al., "Thermomechanical analysis and design optimisations of the IFMIF-DONES HFTM," in Proc. SOFT'18, Giardini Naxos, Italy, Sep. 2018.
- [6] T. Kuo et al., "Overview of the current status of IFMIFDONES test cell biological shielding design," Fusion Eng. Des., vol. 136, pp. 628-632, 2018.
9. doi:10.1016/j.fusengdes.2018.03.043
- [7] F. Martin-Fuertes et al., "Integration of safety in IFMIFDONES design," Safety, vol. 5, p. 74, 2019. doi:10.3390/safety5040074
- [8] C. Torregrosa-Martin et al., "Overview of IFMIF-DONES diagnostics: Requirements and techniques," Fusion Eng. Des., vol. 191, p. 113556, 2023.
12. doi:10.1016/j.fusengdes.2023.113556
- [9] C. Neri et al., "The laser in vessel viewing system (IVVS) for ITER: Test results on first wall and divertor samples and new developments," Fusion Eng. Des., vol. 82, no. 15, pp. 20212028, 2007. doi:10.1016/j.fusengdes.2006.12.006
- [10] B. Brenneis, S. Gordeev, S. Ruck, L. Stoppel, and W. Hering, "Wake shape and height profile measurements in a concave open channel flow regarding the target in DONES," Energies, vol. 14, no. 20, 2021. doi:10.3390/en14206506
- [11] P. Matia-Hernando et al., "Technology trade-off for a remote lithium jet thickness monitoring system for IFMIF-DONES," presented at the International Symposium on Fusion Nuclear Technology, Las Palmas de Gran Canaria, Spain, Sep. 2023.
- [12] C. de la Morena et al., "Assessment of a millimeter-wave radar system for real-time diagnosis of the IFMIF-DONES lithium target," presented at the International Symposium on Fusion Nuclear Technology, Las Palmas de Gran Canaria, Spain, Sep. 2023.
- [13] R.V. Alonso, "New developments of high current beam profile monitors for ion accelerators applied to fusion material research," Ph.D. dissertation, Universidad Complutense de Madrid, Madrid, Spain, 2020.
- [14] D. Winder, "Evolution of the high-power spallation neutron mercury target at the SNS," in Proc. IPAC'21, Campinas, SP, Brazil, May 2021, pp. 3735-3739.

doi:10.18429/JACoW-IPAC2021-THXC03

- [15] G. K. Creffield, M. G. Down, and R. J. Pulham, "Electrical resistivity of liquid and solid lithium," J. Chem. Soc., Dalton Trans., pp. 2325-2329, 1974. doi:10.1039/DT9740002325
- [16] N. Holstein, W. Krauss, J. Konys, and F. S. Nitti, "Development of an electrochemical sensor for hydrogen detection in liquid lithium for ifmif-dones," Fusion Eng. Des., vol. 146, pp. 1441-1445, 2019. doi:10.1016/j.fusengdes.2019.02.100
- [17] S. Fiore, Characterization of self-powered neutron detectors in the nTOF target pit and outlook for the future, nTOF Collaboration Meeting, 2018. https://indico.cern.ch/ event/767271/
- [18] S. Fiore, "On-target neutron flux monitoring with self powered neutron detectors at nTOF," presented at ENS'19, Villigen, Switzerland, 2019. https://indico.psi.ch/ event/7274/contributions/18800
- [19] D. Rapisarda et al., "Feasibility of fission chambers as a neutron diagnostic in the IFMIF-test cell," Fusion Eng. Des., vol. 84, no. 7, pp. 1570-1574, 2009. doi:10.1016/j.fusengdes.2009.02.004
- [20] D. Rapisarda et al., "Study on the response of IFMIF fission chambers to mixed neutron-gamma fields: Ph-2 experimental tests," Fusion Eng. Des., vol. 86, no. 6, pp. 1232-1235, 2011. doi:10.1016/j.fusengdes.2011.03.079
- [21] A. Klix, F. Arbeiter, M. Majerle, Y. Qiu, and M. Štefánik, "Measurement of neutron fluence in the high-flux test module of the early neutron source by neutron activation," Fusion Eng. Des., vol. 146, pp. 1258-1261, 2019. doi:10.1016/j.fusengdes.2019.02.053