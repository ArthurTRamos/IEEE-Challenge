## TRANSVERSE PROFILE MONITORS BASED ON FLUORESCENCE FOR IFMIF-EVEDA ACCELERATOR

J.M. Carmona*, B. Brañas, A. Ibarra, I. Podadera, CIEMAT, Madrid, Spain

## Abstract

IFMIF-EVEDA prototype accelerator will be a 9 MeV, 125 mA continuous wave (CW) deuteron accelerator, focused on validating the technology that will be used in the future IFMIF facility [1]. In such a high current low energy deuteron accelerator, any interceptive diagnostic could be destroyed. In the quest of non interceptive beam transverse profilers required for IFMIF-EVEDA, two different options are considered: A monitor based on the fluorescence of residual gas developed by CIEMAT and another based on ionization developed by CEA [2]. In this contribution, a description of the beam transverse profile monitor prototype based on fluorescence, together with a brief analysis of the reliability of the profiles captured with this monitor will be presented.

## INTRODUCTION

The International Fusion Materials Irradiation Facility (IFMIF) aim is to provide a materials irradiation database for the design, construction, licensing and safe operation of the future Fusion Demonstration Reactor (DEMO) [2]. In such a reactor, high neutron fluxes may generate up to 30 dpa/fpy (displacements per atom/full power year). IFMIF facility will be a dual 40 MeV deuteron accelerator (2 x 125 mA operating in continuous wave), colliding with a liquid lithium target with the aim to produce high neutron fluxes to test new materials.

In the framework of the "Broader Approach", the IFMIF-EVEDA (Engineering Validation and Engineering Design Activities) project includes the construction of an 9 MeV and 125 mA (CW) deuteron accelerator prototype. Most of the components of the accelerator are being developed by France, Italy and Spain [3].

In such high current accelerator, non-interceptive diagnostics are required. Hence, in the following sections, a brief description of the first prototype for the EVEDA fluorescence profile monitor will be provided. Such monitor is actually in design and prototyping phases.

## PROTOTYPE PROFILE MONITORS

As part of the diagnostics package, non interceptive profile monitors will be installed along the line of the EVEDA accelerator with the aim to measure and characterize the beam. A fluorescence profile monitor is based on the interaction between the beam particles and the residual (or injected) gas inside the vacuum chamber of the accelerator. Photons are produced due to the excitation and de-excitation of the gas molecules or atoms (in the case of injected atomic gas). This technique has been tested already at different accelerator e.g. CERN-

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

*jm.carmona@ciemat.es PSB [4] and GSI-UNILAC [5].

The light emitted, can be collected and used for the determination of the beam profiles. The low cross sections between the beam and the gas at those energies (9 MeV), can be counteract by increasing the integration time (taking advantage of CW operation) and optics optimization.

A set of collection optics will be installed to obtain horizontal and vertical projections of the beam at the same position. Briefly it consists of a special optical window and a set of optics plus a detector. Depending on the results of the first prototype, the detector could be finally located in front of the viewport or installed in a safety place inside of a shielded box, using a coherent fibre bundle to transport the image from the viewport to the camera. A movable calibration system and a gas valve will be installed in order to provide spatial calibration and to increase the pressure locally, respectively. Finally, a filter wheel could be installed to select different line transitions.

Gas inlet Calibration system

Horizontal &amp; vertical camera optics

<!-- image -->

Figure 1: Illustration of the prototype vacuum chamber for the fluorescence profile monitor, showing the vertical and horizontal viewports, as well as those for gas injection and calibration.

## Challenges for IFMIF-EVEDA Profile Monitors

The high neutron and gamma fluxes can lead into a permanent damage for electronic devices like detectors or standard fibres. Detectors usually loose dynamic range and contrast with radiation and can become inoperative even at low dose rates [6]. The detector which suits better our requirements must be chosen carefully, taking into account quantum efficiencies, readout times, spatial resolution, dynamic range and rad-hard operation. CCD's and CID cameras from several companies have been considered. To date, the most promising candidate for EVEDA are CID rad-hard cameras because of its dynamic range and rad-hard resistance operation of some models (up to 3 Mrad). Other detectors like PMT's or APD's have been discarded due to lack in spatial resolution.

A widely known problem is that transmission of optical windows falls with radiation, resulting in decreasing photon counts with time. In order to avoid this setback, the construction of optical windows based on with KU1 and KS-4V quartz glasses are proposed. Transmission for these quartz glasses is ~100% and remains constant for wavelengths above 380 nm at high gamma and neutron flux rates [7, 8].

## SHIELD CONCEPT AND IMAGE BUNDLE OPTIONS

High neutron and gamma fluxes are expected during operation of the accelerator inside the vault. In such hostile environment, is essential to design a local shield in case of using sensitive elements. Looking for a optimization of the shield estimations of the neutron and gamma spectra are being made (see Fig. 2). For the monitors that will be located along the HEBT, a dual head and single output coherent fibre bundle are being considered. For the EVEDA prototype monitor, a radiation tolerant CID camera has been selected (see below). Since every pixel in CID cameras is addressable individually, it could be possible to obtain both profile projections with a single camera using the proposed bundle. If this capability is tested successfully, it will cause a cost reduction of the rents.

Figure 2: Preliminary estimation of total gamma and neutron fluxes versus the distance from the beam axis (top) and neutron spectra at 3 different distances from the beam axis (bottom) near the beam dump [9].

<!-- image -->

## Coherent Image Bundles Options

A coherent image fibre bundles opens the possibility to move the diagnostic set to a safety shielded location. The image bundle should withstand high gamma and neutron fluxes without darkening (loss transmission).

Nowadays, Fujikura LTD [10] and SCHOTT [11] are suppliers with images bundles in their catalogues. SCHOTT provides good quality large image bundles but no radiation resistant (unless they are shielded). Fujikura LTD has radiation resistant image bundles (FIGR series), but they have a maximum diameter of 3 mm leading into a decrease in spatial resolution.

In order to overcome this drawback, an array of FIGR image bundles can be grouped into a larger one, although spatial resolution of SCHOTT bundles will be still larger.

With the purpose of evaluate the viability of this approach, a Fujikura image fibre bundle will be tested together with the fluorescence profile monitor with a deuteron beam in the next months.

## RAD-HARD CID CAMERA

A Thermo Scientific radiation hard CID8726DX6 monochrome camera has been selected for the BTPM prototype. This charge injection device based camera can withstand more radiation levels than standards CCD cameras with relatively low noise in such hostile environments. See table 1 for specifications.

Table 1: CID camera main characteristics

| Pixels  786 x 603  Pixel size  17.3 μm x 17.3 μm  Full well capacity  &gt; 100000 electrons  Remote head controller Up to 50 m  Rad - Hard (at least)  3 Mrad  Outputs  USB 2.0, J2, J1002,…  Gain  x2, x4  Geometric distortion  0 %   |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

The CID8726 camera is cooled down to keep a good S/N ratio even at high gamma fluxes. This camera has lower performances than the best scientific CCD's available, but suitable for profile measurements in hostile environments.

## PROFILE RELIABILITY AND GASES

Typically, molecular nitrogen and hydrogen are the main components of the residual gas present inside a beam pipe. The most intense lines come mainly from N2 and N2 + with wavelengths between 385-430 nm and lifetimes about 60 ns [3].

## Electric Field Interaction

In high current accelerators (and especially in low beta beams) the interaction between the electric field and the excited charged particles of the residual gas could lead into a profile falsification.

For instance, in case of large transition lifetimes, the distance between the points where the excitation and deexcitation of a particle occurs can be non negligible. In order to avoid the contribution of electric field to beam profiles, transitions coming from non ionized atoms or molecules can be selected like e.g.. Ne I, Ar I, Kr I or Xe I lines, depending on their lifetimes and intensities.

Table 2: Velocities due to thermal motion for different candidate gases

| vth(N2)  4.15 x10 -4 mm/ns  vth(Ne)  4.92 x10 -4 mm/ns  vth(Ar)  3.48 x10 -4 mm/ns  vth(Kr)  2.39 x10 -4 mm/ns  vth(Xe)  1.92 x10 -4 mm/ns   |
|----------------------------------------------------------------------------------------------------------------------------------------------|

Unlike other accelerators, hydrogen is expected to be the dominant residual gas in EVEDA due to superconducting cavities (at least near them). There are several processes which could turn into emission of photons (with different cross sections) like e.g.

<!-- formula-not-decoded -->

<!-- formula-not-decoded -->

+ Electron impact excitation processes

Thus, injection of another gas could be desirable because of hydrogen low mass and weak transitions in the region of interest among other effects. In the quest of the best gas, high mass, high cross section, a short lifetime and transitions in the visible region are desirable. Neon, Argon, Krypton and Xenon are gases with similar cross sections, with several transitions in the visible region and in the case of Xe, a large mass (131 amu) and some Xe II line transitions with short lifetimes (~6 ns) [5, 12]. Hence, a filter wheel in the design could assure the reliability of the profiles.

## Thermal Motion

Thermal motion could be also a source of profile widening also, but even for long lifetimes (~60 ns), the distance between excitation and de-excitation (photon emission) due to this effect is negligible (e.g. 2.5E-3 mm for N2 + ). See table 2.

## Estimation of Photons and Resolution

A numerical code has been developed to optimize the design of the monitors along the line. With this tool, beam-gas interaction emissivity, number of photons reaching the detector and the final resolution achievable can be estimated e.g. using the present CID camera, cross section σ~1e-18 cm 2 , tube radius ~ 30 mm, distance beam-lens ~200 mm, pressure ~ 3e-6 mbar, lens F/ number ~1.4, efficiency ~ 1%, integration time ~ 100 ms, 125 mA, σrms ~2.5 mm, the expected photons are ~1.57e+7, beam size in front of detector ~0.36 mm being ~21 in detector pixels. As the beam size will change along the HEBT (i.e. from ~2 mm to ~20 mm), an optimization of the monitors should be made. The optics can be selected to obtain a required resolution, e.g. to obtain the same spatial resolution for σrms ~20 mm beam, a 12 mm lens and a distance beam-lens of ~650 mm should be chosen.

## ACKNOWLEDGEMENTS

We would like to acknowledge P. Forck and F. Becker from GSI and E. Bravin from CERN for his comments and fruitful discussions.

## CONCLUSIONS

IFMIF-EVEDA prototype profile monitor based on fluorescence of residual gas have been presented. At the present design status, this technique looks very promising to characterize the beam transverse profile at such low energies and high deuteron current. Therefore, they could be a key device to carry out non-interceptive transverse emittance measurements by doing quadrupoles scans.

## REFERENCES

- [1] P. Garin et al., EPAC08 conference proceedings, TUZG01, (2008).
- [2] J. Marroncle et al., see this proceedings.
- [3] IFMIF Comprehensive Design Report, January 2004.
- [4] M.A. Plum et al., Nucl. Instr. And Meth. A 492 (2002) 74-90
- [5] F. Becker et al,. "Beam induced Fluorescence (BIF) Monitor for Heavy Ion Beams", BIW 2008, Lake Tahoe, May 2008
- [6] S. Hutchins et al., "Radiation tests on solid state cameras for instrumentation", Proceedings of DIPAC 2005, CTWA02.
- [7] A. Moroño et al,. Journal of Nuclear Materials 329333 (2004) 1438
- [8] D.V. Orlinski et al., Problems of Atomic Science and Technology, N 3. Plasma Physics (5), (2000) p. 6063
- [9] F. Ogando et al., UNED, private comunication
- [10] www.fujikura.co.uk
- [11] www.schott.com
- [12] NIST Atomic Spectra Database Lines Form. http://physics.nist.gov/PhysRefData/ASD